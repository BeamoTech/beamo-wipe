[ -f ~/.profile ] && . ~/.profile

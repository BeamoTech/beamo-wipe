# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path

import pytest

from beamo_wipe.discover import discover, load_lsblk_json_text
from beamo_wipe.methods import DEFAULT_METHOD, METHODS
from beamo_wipe.models import MethodId, WipeRequest
from beamo_wipe.nwipe_runner import DryRunRunner, build_nwipe_argv, parse_percent, validate_argv
from beamo_wipe.safety import SafetyError, selectable_disks

FIXTURES = Path(__file__).parent / "fixtures"
DRIVE_STATUS_HEADER = (
    "********************************* Drive Status "
    "*********************************\n"
)


def _request(method=MethodId.EVERYDAY) -> WipeRequest:
    payload = load_lsblk_json_text((FIXTURES / "lsblk_vm_iso.json").read_text(encoding="utf-8"))
    d = discover(
        lsblk_payload=payload,
        boot_path="/dev/sr0",
        env={"BEAMO_WIPE_DRY_RUN": "1"},
        mount_sources=[],
        cmdline="",
    )
    disk = selectable_disks(d)[0]
    return WipeRequest(
        device=disk.path,
        method=method,
        boot_device="/dev/sr0",
        logfile="/tmp/beamo-wipe/nwipe-vda.log",
    )


def test_argv_is_single_device_noninteractive():
    req = _request()
    argv = build_nwipe_argv(req)
    validate_argv(argv, req)
    assert argv[0] == "nwipe"
    assert "--autonuke" in argv
    assert "--nogui" in argv
    assert "--quiet" in argv
    assert "--force" not in argv
    assert argv[-1] == "/dev/vda"
    assert argv.count("/dev/vda") == 1
    assert "--exclude=/dev/sr0" in argv
    assert "--PDFreportpath=noPDF" in argv
    spec = METHODS[DEFAULT_METHOD]
    assert f"--method={spec.nwipe_method}" in argv


def test_extra_and_zero_methods():
    extra = build_nwipe_argv(_request(MethodId.EXTRA))
    assert "--method=dodshort" in extra
    zero = build_nwipe_argv(_request(MethodId.QUICK_ZERO))
    assert "--method=zero" in zero
    assert "--verify=off" in zero


def test_rejects_missing_device():
    req = _request()
    argv = build_nwipe_argv(req)
    argv[-1] = "--bogus"
    with pytest.raises(SafetyError):
        validate_argv(argv, req)


def test_validate_rejects_extra_positional():
    req = _request()
    argv = build_nwipe_argv(req)
    argv.insert(-1, "/etc/passwd")
    with pytest.raises(SafetyError):
        validate_argv(argv, req)


def test_parse_percent():
    assert parse_percent("progress 12.5% remaining") == 12.5
    assert parse_percent("no numbers") is None
    assert parse_percent("101%") is None


def test_dry_run_never_calls_binary():
    runner = DryRunRunner(duration_s=0.01)
    req = _request()
    runner.start(req)
    assert runner.started
    # Immediate poll may still be running; that's fine.
    assert runner.result is None or runner.result.ok


def test_nwipe_runner_does_not_deadlock_on_stdout(tmp_path, monkeypatch):
    """A child that writes more than a pipe buffer must still be able to exit."""
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "dd if=/dev/zero bs=1024 count=256 2>/dev/null\n"
        "for arg in \"$@\"; do\n"
        "  case \"$arg\" in --logfile=*) echo '12.5%' >> \"${arg#--logfile=}\" ;; esac\n"
        "done\n"
        "exit 0\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    deadline = time.monotonic() + 3.0
    result = None
    while time.monotonic() < deadline:
        result = runner.poll(req)
        if result is not None:
            break
        time.sleep(0.05)
    if runner._proc is not None:
        runner._proc.kill()
    assert result is not None
    assert result.exit_code == 0


def test_nwipe_runner_cancel_allows_start_again(tmp_path, monkeypatch):
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_sleep"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "sleep 30\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    runner.cancel()
    time.sleep(0.05)
    runner.start(req)
    runner.cancel()


def test_stale_logfile_does_not_show_100_percent(tmp_path, monkeypatch):
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    stale = tmp_path / "nwipe-vda.log"
    stale.write_text("/dev/vda: 100.00%, round 1 of 1\n", encoding="utf-8")
    script = tmp_path / "fake_nwipe_hang"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "sleep 30\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(stale),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    time.sleep(0.05)
    assert runner.poll(req) is None
    assert runner.progress != 100.0
    runner.cancel()


def test_rejects_logfile_on_block_device():
    req = _request()
    bad = WipeRequest(
        device=req.device,
        method=req.method,
        boot_device=req.boot_device,
        logfile="/dev/sda",
    )
    with pytest.raises(SafetyError):
        build_nwipe_argv(bad)


def test_rejects_force_flag():
    req = _request()
    argv = build_nwipe_argv(req)
    argv.insert(-1, "--force")
    with pytest.raises(SafetyError, match="force"):
        validate_argv(argv, req)


def test_rejects_missing_anonymized_logging_flag():
    req = _request()
    argv = build_nwipe_argv(req)
    argv.remove("--quiet")
    with pytest.raises(SafetyError, match="quiet"):
        validate_argv(argv, req)


def test_rejects_pdf_path_on_device():
    req = _request()
    argv = build_nwipe_argv(req)
    idx = argv.index("--PDFreportpath=noPDF")
    argv[idx] = "--PDFreportpath=/tmp/report.pdf"
    with pytest.raises(SafetyError):
        validate_argv(argv, req)


def test_rejects_partition_target():
    req = WipeRequest(
        device="/dev/vda1",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile="/tmp/beamo-wipe/nwipe-vda.log",
    )
    with pytest.raises(SafetyError):
        build_nwipe_argv(req)


def test_real_nwipe_binary_refuses_dry_run(monkeypatch, tmp_path):
    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setenv("BEAMO_WIPE_DRY_RUN", "1")
    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    runner = NwipeRunner(binary="nwipe")
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    with pytest.raises(SafetyError, match="dry-run"):
        runner.start(req)


def test_zero_confirm_rdev_is_fail_closed_for_real_engine(tmp_path, monkeypatch):
    import subprocess

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.nwipe_runner.require_real_live_for_nwipe", lambda: None)
    monkeypatch.setattr(
        "beamo_wipe.nwipe_runner.pinned_nwipe_already_running", lambda **_k: False
    )
    monkeypatch.setattr("beamo_wipe.nwipe_runner._verify_pinned_nwipe", lambda _p: None)
    monkeypatch.setattr(
        "beamo_wipe.nwipe_runner.assert_existing_is_block_device", lambda *_a, **_k: None
    )
    monkeypatch.setattr(
        "beamo_wipe.nwipe_runner.assert_size_unchanged", lambda *_a, **_k: None
    )
    monkeypatch.setattr("beamo_wipe.nwipe_runner.block_rdev", lambda _p: 0x800)
    monkeypatch.setattr(
        "beamo_wipe.nwipe_runner.resolve_nwipe_binary",
        lambda _b: "/usr/lib/beamo-wipe/nwipe",
    )
    called = []

    def fake_popen(*_a, **_k):
        called.append(True)
        raise AssertionError("nwipe must not start when confirm-time rdev is unknown")

    monkeypatch.setattr(subprocess, "Popen", fake_popen)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
        device_rdev=0,
        device_size_bytes=10_000_000_000,
    )
    runner = NwipeRunner(binary="/usr/lib/beamo-wipe/nwipe")
    with pytest.raises(SafetyError, match="identity"):
        runner.start(req)
    assert called == []


def test_nwipe_start_leaves_progress_unknown_until_log_reports(tmp_path, monkeypatch):
    import stat

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_hang"
    script.write_text(
        "#!/bin/sh\ntrap '' USR1\nsleep 30\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    assert runner.progress is None
    assert runner.poll(req) is None
    assert runner.progress is None
    runner.cancel()


def test_evaluate_nwipe_busy_skip_is_not_success():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda is reported as IN USE (it could be mounted)\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "in use" in summary.lower()


def test_evaluate_nwipe_busy_on_boot_usb_does_not_fail_target():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/sdb is reported as IN USE (it could be mounted)\n"
        "/dev/vda: 100.00%, round 1 of 1, pass 1 of 1, eta 00:00:00, [writing]\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_evaluate_nwipe_truncated_round_line_is_not_success():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 100.00%, round 1 of 1\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "without wiping" in summary


def test_evaluate_nwipe_exit_zero_with_empty_log_is_not_success():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    ok, summary = evaluate_nwipe_completion(0, "", "/dev/vda")
    assert ok is False
    assert "without wiping" in summary


def test_evaluate_nwipe_abort_with_progress_is_not_finished():
    """nwipe 0.42 logs a percent from SIGUSR1, then abort, and still exits 0."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 45.00%, round 1 of 1, pass 1 of 1, eta 00:10:00, [writing]\n"
        "Nwipe was aborted by the user. Check the summary table for the drive status.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "abort" in summary.lower()


def test_evaluate_nwipe_zero_percent_summary_is_not_finished():
    """Erasure summary 0.00% plus the success banner is not a completed wipe."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        " ! vda |                 0 |        10000000000 |             0.00%\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False


def test_evaluate_nwipe_unable_to_open_is_not_finished():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "Unable to open device '/dev/vda'.\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "open" in summary.lower()


def test_evaluate_nwipe_serial_probe_warning_is_not_open_failure():
    """device.c logs this when HDIO_GET_IDENTITY open() fails, then continues."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "Unable to open device /dev/vda to obtain serial number\n"
        + DRIVE_STATUS_HEADER
        + "      vda | Erased |  120MB/s | 01:25:04 | QEMU/HARDDISK\n"
        + "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_evaluate_nwipe_model_insanity_is_not_drive_status_failure():
    """Drive Status tokens are 8 chars between pipes; model/serial may contain them."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        DRIVE_STATUS_HEADER
        + "      vda | Erased |  120MB/s | 01:25:04 | QEMU/INSANITYBOX\n"
        + "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_evaluate_nwipe_one_hundred_percent_on_target_is_finished():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 100.00%, round 1 of 1, pass 1 of 1, eta 00:00:00, [verifying]\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_evaluate_nwipe_one_hundred_percent_mid_method_is_not_finished():
    """dodshort (Extra thorough) is 3 passes in one round. 100% of pass 1 of 3
    plus nwipe's exit-0 success banner is not a completed wipe."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 100.00%, round 1 of 1, pass 1 of 3, eta 00:10:00, [writing]\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "without wiping" in summary


def test_evaluate_nwipe_one_hundred_percent_mid_rounds_is_not_finished():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 100.00%, round 1 of 2, pass 1 of 1, eta 00:10:00, [writing]\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "without wiping" in summary


def test_evaluate_nwipe_one_hundred_percent_last_pass_is_finished():
    """100% of pass 3 of 3 (last pass) is the same fallback as pass 1 of 1."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "/dev/vda: 100.00%, round 1 of 1, pass 3 of 3, eta 00:00:00, [verifying]\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_one_pass_log_does_not_verify_three_overwrites():
    from beamo_wipe.evidence import OUTCOME_FAILED, OUTCOME_VERIFIED, _outcome_for
    from beamo_wipe.models import MethodId, WipeResult
    from beamo_wipe.nwipe_runner import completion_for_method

    one_pass = (
        "/dev/nvme0n1: 100.00%, round 1 of 1, pass 1 of 1, "
        "eta 00:00:00, [writing]>\n"
    )
    three = (
        "/dev/nvme0n1: 100.00%, round 1 of 1, pass 3 of 3, "
        "eta 00:00:00, [verifying]>\n"
    )
    erased = (
        DRIVE_STATUS_HEADER
        + " nvme0n1 | Erased |  120MB/s | 01:25:04 | QEMU\n"
    )
    result = WipeResult(ok=True, exit_code=0, summary="finished", logfile="/tmp/x")
    ok, _summary, reason = completion_for_method(
        0, one_pass, "/dev/nvme0n1", MethodId.EXTRA
    )
    assert ok is False and reason == "completion_missing"
    outcome, _why = _outcome_for(
        result=result, method=MethodId.EXTRA, log_text=one_pass,
        device="/dev/nvme0n1", interrupted=False, cancelled=False,
    )
    assert outcome == OUTCOME_FAILED
    ok, _summary, reason = completion_for_method(
        0, three, "/dev/nvme0n1", MethodId.EXTRA
    )
    assert ok is True and reason == "completed"
    outcome, _why = _outcome_for(
        result=result, method=MethodId.EXTRA, log_text=three,
        device="/dev/nvme0n1", interrupted=False, cancelled=False,
    )
    assert outcome == OUTCOME_VERIFIED
    outcome, _why = _outcome_for(
        result=result, method=MethodId.EXTRA, log_text=erased,
        device="/dev/nvme0n1", interrupted=False, cancelled=False,
    )
    assert outcome == OUTCOME_VERIFIED
    outcome, _why = _outcome_for(
        result=result, method=MethodId.EVERYDAY, log_text=one_pass,
        device="/dev/nvme0n1", interrupted=False, cancelled=False,
    )
    assert outcome == OUTCOME_FAILED
    from beamo_wipe.evidence import build_evidence
    from beamo_wipe.models import DiscoveryResult, Disk, DiskKind
    from beamo_wipe.outcomes import present_evidence

    disk = Disk(
        path="/dev/nvme0n1", name="nvme0n1", model="Disk", serial="NVME",
        size_bytes=10**12, size_gb_label="1000", kind=DiskKind.SSD, bus="nvme",
        label="",
    )
    boot = Disk(
        path="/dev/sdb", name="sdb", model="USB", serial="BOOT",
        size_bytes=16_000_000_000, size_gb_label="16", kind=DiskKind.SSD,
        bus="usb", label="", is_boot=True,
    )
    discovery = DiscoveryResult(
        disks=(disk, boot), selectable=(disk,), boot=boot, boot_identified=True,
    )
    evidence = build_evidence(
        disk=disk, discovery=discovery, method=MethodId.EXTRA, request=None,
        result=result, started_at_wall=None, ended_at_wall=None,
        started_mono=0, ended_mono=1, argv=["nwipe"], log_text=one_pass,
    )
    assert evidence["outcome"] == OUTCOME_FAILED
    assert evidence["verification"]["verified"] is False
    assert evidence["completion"]["reason"] == "completion_missing"
    view = present_evidence(evidence)
    assert view.code == "completion_missing"
    assert view.success is False


def test_truncated_drive_status_name_still_counts_as_erased():
    """nwipe 0.42 prints an 8-column device field, stopping at the slash.

    ``/dev/nvme0n100`` is ``vme0n100``. The last SIGUSR1 sample is often
    below 100%, so the Erased row is the only completion marker.
    """
    from beamo_wipe.nwipe_runner import evaluate_nwipe_outcome, nwipe_status_device_field

    device = "/dev/nvme0n100"
    assert nwipe_status_device_field(device) == "vme0n100"
    assert nwipe_status_device_field("/dev/sda") == "     sda"
    assert nwipe_status_device_field("/dev/nvme0n1") == " nvme0n1"
    log = (
        f"{device}: 099.87%, round 1 of 1, pass 1 of 1, eta 00:00:02, [verifying]\n"
        + DRIVE_STATUS_HEADER
        + "  vme0n100 | Erased |  120MB/s | 01:25:04 | QEMU/HARDDISK\n"
    )
    ok, summary, reason = evaluate_nwipe_outcome(0, log, device)
    assert (ok, summary, reason) == (True, "finished", "completed")
    missed, _, missed_reason = evaluate_nwipe_outcome(
        0, log.splitlines()[0] + "\n", device
    )
    assert missed is False
    assert missed_reason == "completion_missing"


def test_shared_truncated_status_name_does_not_finish_the_other_disk():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_outcome

    log = (
        "/dev/nvme0n100: 12.50%, round 1 of 1, pass 1 of 1, eta 01:00:00, [writing]\n"
        "/dev/anvme0n100: 40.00%, round 1 of 1, pass 1 of 1, eta 01:00:00, [writing]\n"
        "  vme0n100 | Erased |  120MB/s | 01:00:00 | FAKE/DISK\n"
    )
    for device in ("/dev/nvme0n100", "/dev/anvme0n100"):
        ok, _summary, reason = evaluate_nwipe_outcome(0, log, device)
        assert ok is False
        assert reason == "completion_missing"


def test_truncated_failed_status_is_not_finished_by_a_final_percent():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_outcome

    device = "/dev/nvme0n100"
    log = (
        f"{device}: 100.00%, round 1 of 1, pass 1 of 1, eta 00:00:00, [verifying]\n"
        "! vme0n100 |-FAILED-| 0MB/s | 00:01:00 | QEMU/DISK\n"
    )
    ok, _summary, reason = evaluate_nwipe_outcome(0, log, device)
    assert ok is False
    assert reason == "engine_failed"


def test_evaluate_nwipe_erased_table_is_finished():
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        DRIVE_STATUS_HEADER
        + "      vda | Erased |  120MB/s | 01:25:04 | QEMU/HARDDISK\n"
        + "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is True
    assert summary == "finished"


def test_evaluate_nwipe_sigusr1_success_before_thread_is_not_finished():
    """nwipe 0.42 SIGUSR1 logs '/dev/X: Success' when thread is unset and
    result is 0 — including after options_log, before pthread_create."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "[2026/10/16 12:00:00] info: Program options are set as follows\n"
        "/dev/vda: Success\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False
    assert "without wiping" in summary


def test_evaluate_nwipe_geometry_fail_with_sigusr1_success_is_not_finished():
    """Geometry continue + wipe_threads_started==0 still exits 0 with INSANITY."""
    from beamo_wipe.nwipe_runner import evaluate_nwipe_completion

    log = (
        "[2026/10/16 12:00:00] info: Program options are set as follows\n"
        "/dev/vda: Success\n"
        "No sane device geometry for '/dev/vda'.\n"
        "      vda |INSANITY|        0 | 00:00:00 | QEMU/HARDDISK\n"
        "Nwipe successfully completed. See summary table for details.\n"
    )
    ok, summary = evaluate_nwipe_completion(0, log, "/dev/vda")
    assert ok is False


def test_nwipe_version_line_is_not_a_substring_match():
    from beamo_wipe.nwipe_runner import nwipe_version_is_pinned

    assert nwipe_version_is_pinned("nwipe version 0.42\n")
    assert nwipe_version_is_pinned("nwipe version 0.42")
    assert not nwipe_version_is_pinned("0.42")
    assert not nwipe_version_is_pinned("nwipe version 0.37\n")
    assert not nwipe_version_is_pinned("nwipe version 0.420\n")
    assert not nwipe_version_is_pinned("nwipe version 10.42\n")
    assert not nwipe_version_is_pinned("compiled with 0.42\n")
    assert not nwipe_version_is_pinned("nwipe version 0.42.1\n")


def test_job_percent_does_not_wrap_between_dodshort_passes():
    from beamo_wipe.nwipe_runner import _target_job_percent, _target_last_percent

    pass1 = "/dev/vda: 33.33%, round 1 of 1, pass 1 of 3, eta 00:10:00, [writing]\n"
    assert _target_last_percent(pass1, "/dev/vda") == 33.33
    mid = _target_job_percent(pass1, "/dev/vda")
    assert mid is not None
    assert mid == 33.33
    both = pass1 + "/dev/vda: 33.73%, round 1 of 1, pass 2 of 3, eta 00:10:00, [writing]\n"
    job = _target_job_percent(both, "/dev/vda")
    assert job is not None
    assert job == 33.73
    last = (
        both + "/dev/vda: 100.00%, round 1 of 1, pass 3 of 3, eta 00:00:00, [verifying]\n"
    )
    assert _target_job_percent(last, "/dev/vda") == 100.0


def test_target_last_percent_ignores_erasure_summary_zero():
    """nwipe 0.42 writes Erasure Summary 0.00% after SIGUSR1 progress lines."""
    from beamo_wipe.nwipe_runner import _target_last_percent

    log = (
        "/dev/vda: 45.00%, round 1 of 1, pass 1 of 1, eta 00:10:00, [writing]\n"
        " ! vda |                 0 |        10000000000 |             0.00%\n"
    )
    assert _target_last_percent(log, "/dev/vda") == 45.0


def test_nwipe_accepts_sigusr1_only_after_options_log():
    from beamo_wipe.nwipe_runner import nwipe_accepts_sigusr1

    assert not nwipe_accepts_sigusr1("")
    assert not nwipe_accepts_sigusr1("nwipe version 0.42\nAuto-selected fastest PRNG: AES\n")
    assert nwipe_accepts_sigusr1("[2026/10/16 12:00:00] info: Program options are set as follows...\n")
    assert nwipe_accepts_sigusr1("[2026/10/16 12:00:00] info: Using cached I/O on device '/dev/vda'.\n")


def test_sigusr1_not_sent_during_startup_before_nwipe_masks_it(tmp_path, monkeypatch):
    """nwipe 0.42 benches 8 PRNGs before pthread_sigmask(SIGUSR1). Default
    SIGUSR1 terminates; sending it at t=2s kills the engine."""
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_no_usr1_trap"
    script.write_text(
        "#!/bin/sh\n"
        "sleep 4\n"
        "exit 0\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    deadline = time.monotonic() + 2.5
    while time.monotonic() < deadline:
        result = runner.poll(req)
        if result is not None:
            runner.cancel()
            raise AssertionError(
                f"nwipe child exited during startup (exit {result.exit_code}); "
                "SIGUSR1 was sent before the engine masked it"
            )
        time.sleep(0.05)
    assert runner._proc is not None
    assert runner._proc.poll() is None
    runner.cancel()


def test_sigusr1_sent_after_nwipe_ready_marker(tmp_path, monkeypatch):
    """Readiness gates signaling, independent of host scheduling or sleeps."""
    import signal
    from beamo_wipe.nwipe_runner import NwipeRunner

    signals = []

    class FakeProc:
        returncode = None

        def poll(self):
            return self.returncode

        def send_signal(self, value):
            signals.append(value)

        def terminate(self):
            self.returncode = 143

        def wait(self, timeout):
            return self.returncode

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    monkeypatch.setattr("beamo_wipe.nwipe_runner.subprocess.Popen", lambda *a, **kw: FakeProc())
    monkeypatch.setattr("beamo_wipe.nwipe_runner.time.monotonic", lambda: 3.0)
    req = WipeRequest(
        device="/dev/vda", method=MethodId.EVERYDAY, boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(tmp_path / "fake_nwipe_ready"))
    runner.start(req)
    try:
        runner.poll(req)
        assert not runner._sigusr1_armed and not signals
        (tmp_path / "nwipe-vda.log").write_text("[2026/10/16 12:00:00] info: Program options are set as follows...\n")
        runner.poll(req)
        assert runner._sigusr1_armed
        assert runner._last_sigusr1 == 3.0
        assert signals == [signal.SIGUSR1]
        assert runner._proc.poll() is None
    finally:
        runner.cancel()


def test_nwipe_runner_busy_skip_log_is_failure(tmp_path, monkeypatch):
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_busy"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "for arg in \"$@\"; do\n"
        "  case \"$arg\" in --logfile=*)\n"
        "    printf '%s\\n%s\\n' "
        "'/dev/vda is reported as IN USE (it could be mounted)' "
        "'Nwipe successfully completed. See summary table for details.' "
        ">> \"${arg#--logfile=}\" ;;\n"
        "  esac\n"
        "done\n"
        "exit 0\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    deadline = time.monotonic() + 3.0
    result = None
    while time.monotonic() < deadline:
        result = runner.poll(req)
        if result is not None:
            break
        time.sleep(0.05)
    if runner._proc is not None:
        runner._proc.kill()
    assert result is not None
    assert result.exit_code == 0
    assert result.ok is False
    assert "in use" in result.summary.lower()


def test_progress_does_not_drop_to_summary_zero_percent(tmp_path, monkeypatch):
    """WORKING must keep SIGUSR1 progress, not the later Erasure Summary 0.00%."""
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_summary_zero"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "for arg in \"$@\"; do\n"
        "  case \"$arg\" in --logfile=*)\n"
        "    printf '%s\\n%s\\n' "
        "'/dev/vda: 45.00%, round 1 of 1, pass 1 of 1, eta 00:10:00, [writing]' "
        "' ! vda |                 0 |        10000000000 |             0.00%' "
        ">> \"${arg#--logfile=}\" ;;\n"
        "  esac\n"
        "done\n"
        "sleep 4\n"
        "exit 0\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    seen = None
    deadline = time.monotonic() + 2.5
    while time.monotonic() < deadline:
        runner.poll(req)
        if runner.progress is not None:
            seen = runner.progress
            break
        time.sleep(0.05)
    alive = runner._proc is not None and runner._proc.poll() is None
    runner.cancel()
    assert alive
    assert seen == 45.0


def test_completion_sees_erased_row_after_large_pdf_tail(tmp_path, monkeypatch):
    """nwipe 0.42 logs smartctl/PDF after Drive Status. A 64KiB tail can miss Erased."""
    import stat
    import time

    from beamo_wipe.nwipe_runner import NwipeRunner

    monkeypatch.setattr("beamo_wipe.safety.default_log_dir", lambda: tmp_path)
    script = tmp_path / "fake_nwipe_fat_tail"
    script.write_text(
        "#!/bin/sh\n"
        "trap '' USR1\n"
        "for arg in \"$@\"; do\n"
        "  case \"$arg\" in --logfile=*)\n"
        "    log=\"${arg#--logfile=}\"\n"
        "    echo '********************************* Drive Status *********************************' >> \"$log\"\n"
        "    echo '      vda | Erased |  120MB/s | 01:25:04 | QEMU/HARDDISK' >> \"$log\"\n"
        "    dd if=/dev/zero bs=1024 count=80 2>/dev/null | tr '\\0' 'x' >> \"$log\"\n"
        "    echo >> \"$log\"\n"
        "    ;;\n"
        "  esac\n"
        "done\n"
        "exit 0\n",
        encoding="utf-8",
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(tmp_path / "nwipe-vda.log"),
    )
    runner = NwipeRunner(binary=str(script))
    runner.start(req)
    deadline = time.monotonic() + 3.0
    result = None
    while time.monotonic() < deadline:
        result = runner.poll(req)
        if result is not None:
            break
        time.sleep(0.05)
    if runner._proc is not None:
        runner._proc.kill()
    assert result is not None
    assert result.exit_code == 0
    assert result.ok is True


# ---------------------------------------------------------------------------
# Cancel integrity: fail closed when the engine survives, never overwrite a
# concurrent outcome. Fake procs only; no real device is ever touched.
# ---------------------------------------------------------------------------


class _StillAliveProc:
    """Ignores terminate/kill: wait() always times out, poll() says running."""

    returncode = None

    def poll(self):
        return None

    def terminate(self):
        pass

    def kill(self):
        pass

    def wait(self, timeout=None):
        import subprocess

        raise subprocess.TimeoutExpired(cmd="nwipe", timeout=timeout)


class _ExitsOnKillProc:
    """Dies only once killed: first wait times out, second returns."""

    def __init__(self):
        self.returncode = None
        self.killed = False

    def poll(self):
        return self.returncode

    def terminate(self):
        pass

    def kill(self):
        self.killed = True
        self.returncode = -9

    def wait(self, timeout=None):
        import subprocess

        if not self.killed:
            raise subprocess.TimeoutExpired(cmd="nwipe", timeout=timeout)
        return self.returncode


def _cancel_runner(tmp_path):
    from beamo_wipe.nwipe_runner import NwipeRunner

    return NwipeRunner(binary=str(tmp_path / "fake"))


def test_cancel_surviving_engine_fails_closed(tmp_path):
    """kill() ignored -> SafetyError, no 'cancelled' claim, lock retained."""
    runner = _cancel_runner(tmp_path)
    proc = _StillAliveProc()
    runner._proc = proc
    runner._lock_fd = None
    runner.result = None
    with pytest.raises(SafetyError, match="still be erasing"):
        runner.cancel()
    assert runner.result is None
    assert runner._proc is proc
    # A retry still targets the live engine (and still fails closed).
    with pytest.raises(SafetyError, match="still be erasing"):
        runner.cancel()


def test_cancel_eperm_kill_fails_closed(tmp_path):
    """EPERM on terminate/kill with a live engine must not read 'cancelled'."""

    class _EpermProc(_StillAliveProc):
        def terminate(self):
            raise OSError(1, "Operation not permitted")

        def kill(self):
            raise OSError(1, "Operation not permitted")

    runner = _cancel_runner(tmp_path)
    proc = _EpermProc()
    runner._proc = proc
    runner._lock_fd = None
    runner.result = None
    with pytest.raises(SafetyError, match="still be erasing"):
        runner.cancel()
    assert runner.result is None
    assert runner._proc is proc


def test_cancel_exited_after_timeout_is_cancelled(tmp_path):
    """wait() timed out but the process is verifiably dead -> cancelled."""
    runner = _cancel_runner(tmp_path)
    proc = _ExitsOnKillProc()
    runner._proc = proc
    runner._lock_fd = None
    runner.result = None
    runner.cancel()
    assert runner.result is not None
    assert runner.result.summary == "cancelled"
    assert runner._proc is None


def test_cancel_keeps_concurrent_poll_completion(tmp_path):
    """poll() that won the race keeps its outcome; cancel() does not clobber."""
    from beamo_wipe.models import WipeResult

    runner = _cancel_runner(tmp_path)
    runner._proc = _StillAliveProc()
    runner.result = WipeResult(ok=True, exit_code=0, summary="finished", logfile="x")
    runner.cancel()
    assert runner.result is not None
    assert runner.result.summary == "finished"


def test_poll_keeps_concurrent_cancel(tmp_path):
    """A poll snapshot taken before cancel() must not overwrite 'cancelled'."""
    import threading

    from beamo_wipe.models import MethodId

    entered = threading.Event()
    release = threading.Event()

    class _RaceProc:
        returncode = None

        def poll(self):
            entered.set()
            assert release.wait(timeout=5)
            self.returncode = 0
            return 0

        def terminate(self):
            pass

        def kill(self):
            pass

        def wait(self, timeout=None):
            return 0

    log = tmp_path / "nwipe-vda.log"
    log.write_text("/dev/vda | Erased |\n", encoding="utf-8")
    req = WipeRequest(
        device="/dev/vda",
        method=MethodId.EVERYDAY,
        boot_device="/dev/sr0",
        logfile=str(log),
    )
    runner = _cancel_runner(tmp_path)
    runner._proc = _RaceProc()
    runner._lock_fd = None
    out = {}

    def do_poll():
        out["result"] = runner.poll(req)

    thread = threading.Thread(target=do_poll)
    thread.start()
    assert entered.wait(timeout=5)
    runner.cancel()
    assert runner.result is not None
    assert runner.result.summary == "cancelled"
    release.set()
    thread.join(timeout=5)
    assert not thread.is_alive()
    assert runner.result is not None
    assert runner.result.summary == "cancelled"


def test_rejects_flags_for_unconfirmed_method():
    """Validator binds flags to the confirmed method, not just the allowlist.

    An EVERYDAY request (prng/verify-last) with zero/off flags swapped in
    must fail: otherwise a weaker wipe than confirmed could exec.
    """
    req = _request(MethodId.EVERYDAY)
    argv = build_nwipe_argv(req)
    swapped = [
        "--method=zero" if a.startswith("--method=") else a for a in argv
    ]
    swapped = [
        "--verify=off" if a.startswith("--verify=") else a for a in swapped
    ]
    with pytest.raises(SafetyError, match="confirmed method"):
        validate_argv(swapped, req)
    # Cross-method for EXTRA too (dodshort expected, prng must fail).
    req_extra = _request(MethodId.EXTRA)
    argv_extra = build_nwipe_argv(req_extra)
    downgraded = [
        "--method=prng" if a.startswith("--method=") else a
        for a in argv_extra
    ]
    with pytest.raises(SafetyError, match="confirmed method"):
        validate_argv(downgraded, req_extra)


def test_rejects_empty_argv_as_safety_error():
    """Fail-closed boundary must raise SafetyError, never IndexError."""
    req = _request()
    with pytest.raises(SafetyError, match="First argument"):
        validate_argv([], req)

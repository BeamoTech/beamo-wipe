# SPDX-License-Identifier: GPL-3.0-or-later
"""Helper boot guidance: Win10/Win11 split, BitLocker warning, offline packaging.

Fake devices only. Live Microsoft URLs are read-only link checks.
"""

from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
import shutil
import tempfile
import urllib.error
import urllib.request

import pytest

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "helper" / "index.html"
BOOT_CARD = ROOT / "docs" / "boot-card.md"
START_HERE = ROOT / "packaging/live/config/includes.binary/START-HERE.html"
DESKTOP = ROOT / "desktop/web/index.html"
BUILD_ISO = ROOT / "scripts" / "build-iso.sh"

MICROSOFT_SOURCES = (
    "https://support.microsoft.com/en-us/windows/experience/backup-recovery/windows-recovery-environment",
    "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-recovery-environment--windows-re--technical-reference?view=windows-11",
    "https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/recovery-overview",
    "https://support.microsoft.com/en-us/windows/security/encryption/find-your-bitlocker-recovery-key",
)

FORBIDDEN = (
    "disable secure boot",
    "turn off secure boot",
    "turn off bitlocker",
    "disable bitlocker",
    "works on any computer",
    "works on every pc",
    "plug and play",
    "impossible to recover",
)

RISKY_FIRMWARE = FORBIDDEN + (
    "clear cmos",
    "reset cmos",
    "clear the cmos",
    "reset bios",
    "flash bios",
    "cmos battery",
    "disable secure boot forever",
    "turn secure boot off",
    "secure boot off",
)

GUIDED_BRANCHES = (
    ("trouble-usb", "The USB is missing or not listed"),
    ("trouble-key", "The boot-menu key does nothing"),
    ("trouble-firmware", "The computer refused the USB"),
    ("trouble-launcher", "The launcher failed"),
)


class _Doc(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.headings: list[tuple[int, str]] = []
        self.links: list[str] = []
        self.ids: list[str] = []
        self.external_assets: list[str] = []
        self._capture: list[str] | None = None
        self.skip = False
        self.has_main = False
        self.focus_visible = False

    def handle_starttag(self, tag, attrs):
        names = dict(attrs)
        if tag in {"h1", "h2", "h3"}:
            self._capture = []
        if tag == "a" and names.get("href"):
            self.links.append(names["href"])
        if tag == "main" and names.get("id") == "main":
            self.has_main = True
        if names.get("id"):
            self.ids.append(names["id"])
        if tag in {"link", "script"}:
            src = names.get("href") or names.get("src") or ""
            if src and not src.startswith("data:"):
                self.external_assets.append(src)
        if tag == "a" and "skip" in names.get("class", "").split():
            self.skip = names.get("href") == "#main"

    def handle_data(self, data):
        if self._capture is not None:
            self._capture.append(data)

    def handle_endtag(self, tag):
        if tag in {"h1", "h2", "h3"} and self._capture is not None:
            self.headings.append((int(tag[1]), "".join(self._capture).strip()))
            self._capture = None


def _html() -> str:
    return HELPER.read_text(encoding="utf-8")


def _parse() -> _Doc:
    doc = _Doc()
    raw = _html()
    doc.focus_visible = "a:focus-visible" in raw
    doc.feed(raw)
    return doc


def test_helper_and_iso_start_here_are_injected_from_source(tmp_path):
    # A clean checkout has no generated ISO staging. Check the asset stager's
    # two destinations and exercise the same injection against disposable files.
    from beamo_wipe import __version__
    from beamo_wipe.build_identity import write_injected
    from beamo_wipe.compat_story import SOURCE_STUB, inject_helper_html

    script = BUILD_ISO.read_text(encoding="utf-8")
    assets = (ROOT / "scripts/stage_live_assets.py").read_text(encoding="utf-8")
    assert "stage_live_assets.py" in script
    assert 'put_bytes(share / "helper/index.html", packaged_html)' in assets
    assert 'put_bytes(binary / "START-HERE.html", packaged_html)' in assets
    binary = tmp_path / "binary"
    share = tmp_path / "share"
    binary.mkdir()
    (share / "helper").mkdir(parents=True)
    for dest in (binary / "START-HERE.html", share / "helper/index.html"):
        dest.write_bytes(HELPER.read_bytes())
    assert HELPER.read_bytes() == (binary / "START-HERE.html").read_bytes()
    assert HELPER.read_bytes() == (share / "helper/index.html").read_bytes()
    payload = write_injected(
        tmp_path / "build-identity.json",
        source_commit="a" * 40,
        source_sha256="b" * 64,
        build_id="12345678-1234-1234-1234-123456789abc",
        source_dirty=False,
    )
    for dest in (binary / "START-HERE.html", share / "helper/index.html"):
        dest.write_text(
            inject_helper_html(
                dest.read_text(encoding="utf-8"),
                version=__version__,
                injected=payload,
                packaged=True,
            ),
            encoding="utf-8",
        )
    injected = (binary / "START-HERE.html").read_text(encoding="utf-8")
    assert injected == (share / "helper/index.html").read_text(encoding="utf-8")
    assert injected != HELPER.read_text(encoding="utf-8")
    assert SOURCE_STUB not in injected
    assert "12345678-1234-1234-1234-123456789abc" in injected


def test_helper_is_self_contained_for_offline_usb():
    doc = _parse()
    assert doc.external_assets == []
    text = _html()
    assert '<link rel="stylesheet"' not in text
    assert "<script" not in text
    assert "Windows 11: start this USB from Settings" in text
    assert "Windows 10: start this USB from Settings" in text
    assert "Settings → System → Recovery" in text
    assert "Settings → Update &amp; Security → Recovery" in text
    assert "Use a device" in text
    assert "48-digit recovery key" in text


def test_windows_10_and_11_sections_are_separate():
    headings = [title for _level, title in _parse().headings]
    assert headings.index("Windows 11: start this USB from Settings") < headings.index(
        "Windows 10: start this USB from Settings"
    )
    ids = _parse().ids
    assert "windows-11" in ids and "windows-10" in ids and "bitlocker" in ids
    win11 = _html().split('id="windows-11"', 1)[1].split('id="windows-10"', 1)[0]
    win10 = _html().split('id="windows-10"', 1)[1].split('id="fallbacks"', 1)[0]
    assert "System → Recovery" in win11
    assert "Update &amp; Security" not in win11
    assert "Update &amp; Security → Recovery" in win10
    assert "System → Recovery" not in win10
    assert "UEFI" in win11 and "UEFI" in win10


def test_bitlocker_warning_precedes_firmware_advice():
    text = _html()
    bit = text.index('id="bitlocker"')
    firmware_later = text.index("firmware, boot-order, or Secure Boot")
    assert bit < firmware_later
    assert bit < text.index("If the computer says Secure Boot")
    lower = text.lower()
    assert "before" in lower
    assert "microsoft support cannot retrieve" in lower
    assert "does not turn bitlocker off" in lower
    for phrase in FORBIDDEN:
        assert phrase not in lower, phrase


def test_oem_variation_and_safe_fallbacks_are_documented():
    text = _html()
    assert "not the same on every PC" in text
    assert "Examples only" in text
    assert "Shift" in text
    assert "another direct USB port" in text or "another USB port" in text
    assert "manufacturer" in text.lower()
    assert "legacy BIOS" in text


def test_boot_card_vendor_keys_match_helper():
    import re

    card = BOOT_CARD.read_text(encoding="utf-8")
    html = _html()
    rows = re.findall(r"^\| ([A-Za-z]+) \| (.+) \|$", card, flags=re.MULTILINE)
    assert len(rows) >= 7, "boot-card vendor table shrank unexpectedly"
    for vendor, keys in rows:
        assert vendor in html, f"helper page lost vendor {vendor}"
        for key in re.findall(r"F1[012]|Esc", keys):
            assert key in html, f"helper page lost key {key} for {vendor}"


def test_keyboard_and_small_display_structure():
    doc = _parse()
    assert doc.skip
    assert doc.has_main
    assert doc.focus_visible
    html = _html()
    assert "Skip to instructions" in html
    assert "@media (max-width: 600px)" in html
    assert "overflow-x: auto" in html
    assert 'scope="col"' in html
    assert "<caption>" in html
    levels = [level for level, _title in doc.headings]
    assert levels == sorted(levels)


def test_desktop_help_matches_helper_paths():
    text = DESKTOP.read_text(encoding="utf-8")
    assert "Windows 11: Settings → System → Recovery" in text
    assert "Windows 10: Settings → Update &amp; Security → Recovery" in text
    assert "BitLocker recovery key" in text
    assert "does not change Secure Boot or BitLocker" in text
    assert "START-HERE.html" in text
    assert "This USB uses Debian's signed boot files" in text
    assert "identity-label" in text
    lower = text.lower()
    for phrase in FORBIDDEN:
        assert phrase not in lower, phrase


def _guide_section(html: str) -> str:
    start = html.index('id="guide"')
    end = html.find('id="screen-reader"', start)
    return html[start:] if end == -1 else html[start:end]


def test_helper_and_desktop_guide_the_four_startup_problems():
    helper = _html()
    desktop = DESKTOP.read_text(encoding="utf-8")
    desktop_css = (ROOT / "desktop/web/style.css").read_text(encoding="utf-8")
    for html, css, phone_query in (
        (
            helper,
            helper.split("<style>", 1)[1].split("</style>", 1)[0],
            "@media (max-width: 600px)",
        ),
        (desktop, desktop_css, "@media (max-width: 580px)"),
    ):
        guide = _guide_section(html)
        assert "Choose what you see" in guide
        assert 'aria-label="Startup problems"' in guide
        if html is helper:
            assert html.index('id="guide"') < html.index("Start from your desktop")
        for branch_id, title in GUIDED_BRANCHES:
            assert f'id="{branch_id}"' in guide, branch_id
            assert f'href="#{branch_id}"' in guide
            assert title in guide
            assert f'id="{branch_id}" tabindex="-1"' in guide
        assert guide.count("<figure") >= 4
        assert guide.count("<figcaption>") >= 4
        assert guide.count("<ol>") >= 4
        assert "overflow-wrap: anywhere" in css
        assert "min-height: 2.75em" in css
        assert "white-space: nowrap" not in css
        # Table chrome on the helper may clip row corners; chooser/panels must wrap.
        chooser_css = css[css.index(".chooser") :]
        assert "overflow: hidden" not in chooser_css
        media = css.split(phone_query, 1)[1]
        assert ".chooser { grid-template-columns: 1fr; }" in media
        assert ".illustration { width: 100%; }" in media


def test_guided_branches_use_plain_language_and_safe_recovery():
    helper = _html()
    usb = helper.split('id="trouble-usb"', 1)[1].split('id="trouble-key"', 1)[0]
    key = helper.split('id="trouble-key"', 1)[1].split('id="trouble-firmware"', 1)[0]
    firmware = helper.split('id="trouble-firmware"', 1)[1].split(
        'id="trouble-launcher"', 1
    )[0]
    launcher = helper.split('id="trouble-launcher"', 1)[1].split(
        "Start from your desktop", 1
    )[0]
    assert "keyboard, monitor, or hub" in usb
    assert "Use a device" in usb
    assert "another direct USB port" in usb or "different port" in usb
    assert "as soon as you restart" in key
    assert "Windows Settings steps instead of changing firmware" in key
    assert firmware.lower().index("bitlocker") < firmware.lower().index("manufacturer")
    assert "does not change Secure Boot" in firmware
    assert "does not mean an erase has started" in firmware
    assert "does not erase" in launcher.lower()
    assert "Start Beamo Wipe.exe" in launcher
    assert "kiosk-recovery" in launcher
    desktop = DESKTOP.read_text(encoding="utf-8")
    desktop_fw = desktop.split('id="trouble-firmware"', 1)[1].split(
        'id="trouble-launcher"', 1
    )[0]
    assert desktop_fw.lower().index("bitlocker") < desktop_fw.lower().index(
        "manufacturer"
    )
    assert "does not run on macOS" in desktop
    assert "Not Apple Silicon" in desktop
    # Intel Mac Option key is helper-only; the launcher does not run on macOS.
    assert "Option (⌥)" in helper
    assert "Option (⌥)" not in desktop
    for blob in (helper.lower(), desktop.lower()):
        for phrase in RISKY_FIRMWARE:
            assert phrase not in blob, phrase


def test_helper_guide_stays_offline_and_keyboard_operable():
    doc = _parse()
    html = _html()
    assert doc.external_assets == []
    assert "<script" not in html
    assert "<form" not in html
    assert "summary:focus-visible" in html
    assert ".chooser a:focus-visible" in html
    guide = _guide_section(html)
    assert "<details>" in guide and "<summary>Technical detail</summary>" in guide
    assert "No internet is required" in guide
    desktop = DESKTOP.read_text(encoding="utf-8")
    assert "<form" not in desktop
    assert 'src="/app.js"' in desktop
    assert "START-HERE.html" in desktop


@pytest.mark.parametrize("url", MICROSOFT_SOURCES)
def test_cited_microsoft_sources_are_current(url):
    request = urllib.request.Request(
        url, headers={"User-Agent": "BeamoWipeHelperCheck/1.0"}
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            status = getattr(response, "status", 200)
            final = response.geturl()
            body = response.read(4000).decode("utf-8", "replace").lower()
    except urllib.error.HTTPError as exc:
        if exc.code in {403, 429, 502, 503}:
            pytest.skip(f"transient Microsoft source {url}: {exc.code}")
        pytest.fail(f"stale or unreachable Microsoft source {url}: {exc.code}")
    except urllib.error.URLError as exc:
        pytest.skip(f"network unavailable for {url}: {exc.reason}")
    assert status < 400
    assert (
        "microsoft" in final.lower()
        or "learn.microsoft.com" in final.lower()
        or "support.microsoft.com" in final.lower()
    )
    if "bitlocker" in url:
        assert "recovery" in body
    if "windows-recovery-environment" in url or "windows-re" in url:
        assert "recovery" in body


def test_helper_cites_the_verified_microsoft_sources():
    text = _html()
    for url in MICROSOFT_SOURCES:
        assert url in text
    doc = _parse()
    hrefs = [link for link in doc.links if link.startswith("http")]
    allowed = {
        "https://github.com/BeamoINT/beamo-wipe",
        *MICROSOFT_SOURCES,
    }
    from beamo_wipe.support_contact import SUPPORT_URL

    allowed.add(SUPPORT_URL)
    assert SUPPORT_URL in hrefs
    assert set(hrefs) <= allowed


def _chrome() -> str | None:
    mac = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
    if mac.is_file():
        return str(mac)
    return (
        shutil.which("google-chrome")
        or shutil.which("chromium")
        or shutil.which("chromium-browser")
    )


def test_helper_renders_both_windows_paths_on_small_and_desktop_displays():
    chrome = _chrome()
    if not chrome:
        pytest.skip("Chrome is not installed for helper pixel checks")
    html = HELPER.resolve().as_uri()
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        for width, height, name in ((360, 900, "small"), (1280, 900, "desktop")):
            # Headless Chrome in Docker/Xvfb needs --no-sandbox; share the
            # isolated renderer used by the phone-width branch shots.
            dom = _render_helper(chrome, tmp_path, name, html, width, height)
            assert "Windows 11: start this USB from Settings" in dom
            assert "Windows 10: start this USB from Settings" in dom
            assert "BitLocker recovery key" in dom
            assert "Skip to instructions" in dom
            assert "If something is not working" in dom
            for _branch_id, title in GUIDED_BRANCHES:
                assert title in dom


def _render_helper(
    chrome: str, tmp_path: Path, name: str, url: str, width: int, height: int
) -> str:
    shot = tmp_path / f"{name}.png"
    api = pytest.importorskip("playwright.sync_api")
    # Drive rendering explicitly. Chromium's one-shot --dump-dom path can
    # stay alive without producing output even after the page has loaded.
    with api.sync_playwright() as runtime:
        browser = runtime.chromium.launch(
            executable_path=chrome, args=["--no-sandbox", "--disable-dev-shm-usage"]
        )
        try:
            page = browser.new_page(viewport={"width": width, "height": height})
            page.goto(url)
            page.screenshot(path=str(shot))
            dom = page.content()
        finally:
            browser.close()
    assert shot.is_file() and shot.stat().st_size > 2000
    return dom


def test_guided_branches_render_on_a_phone_width():
    chrome = _chrome()
    if not chrome:
        pytest.skip("Chrome is not installed for helper pixel checks")
    html = HELPER.resolve().as_uri()
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        overview = _render_helper(chrome, tmp_path, "guide-360", html, 360, 900)
        assert "If something is not working" in overview
        for branch_id, title in GUIDED_BRANCHES:
            dom = _render_helper(
                chrome, tmp_path, branch_id, html + "#" + branch_id, 360, 900
            )
            assert title in dom
            assert "Back to problems" in dom

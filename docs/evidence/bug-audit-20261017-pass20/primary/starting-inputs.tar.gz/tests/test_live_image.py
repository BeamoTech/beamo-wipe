# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path

from beamo_wipe import NWIPE_PINNED_COMMIT, NWIPE_PINNED_VERSION

ROOT = Path(__file__).resolve().parents[1]
SUPERVISOR = ROOT / "packaging/live/config/includes.chroot/usr/local/sbin/beamo-wipe-kiosk"
SERVICE = ROOT / "packaging/live/config/includes.chroot/etc/systemd/system/beamo-wipe-kiosk.service"
PACKAGES = ROOT / "packaging/live/config/package-lists/beamo.list.chroot"
HOOK = ROOT / "packaging/live/config/hooks/normal/0500-build-nwipe.hook.chroot"
LAUNCHER = ROOT / "packaging/live/config/includes.chroot/usr/local/bin/beamo-wipe"

FORBIDDEN_PACKAGES = (
    "curl",
    "git",
    "build-essential",
    "sudo",
    "iputils-ping",
    "network-manager",
    "openssh-server",
    "wget",
    "nmap",
    # Not needed by the kiosk or the configured nwipe invocation.
    "nano",
    "less",
    "iproute2",
    "dmidecode",
    "pciutils",
    "usbutils",
    "eject",
)


def test_hdparm_is_only_an_nwipe_read_only_dependency():
    text = PACKAGES.read_text(encoding="utf-8")
    assert "hdparm" in text.split()
    source = "\n".join(
        p.read_text(encoding="utf-8")
        for p in (ROOT / "src" / "beamo_wipe").glob("*.py")
    )
    assert "security-erase" not in source
    assert "--dco-restore" not in source


def test_live_supervisor_does_not_timeout_the_running_wizard():
    text = SUPERVISOR.read_text(encoding="utf-8")
    assert "timeout 90 startx /usr/local/bin/beamo-wipe" not in text
    assert "beamo-wipe" in text
    assert "while" in text
    assert "nwipe" not in text.split("beamo-wipe")[0] or "exec nwipe" not in text


def test_live_supervisor_does_not_auto_start_nwipe():
    text = SUPERVISOR.read_text(encoding="utf-8")
    assert "nwipe --autonuke" not in text
    assert "exec nwipe" not in text


def test_live_packages_omit_network_and_compilers():
    names = {
        line.strip()
        for line in PACKAGES.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    }
    for pkg in FORBIDDEN_PACKAGES:
        assert pkg not in names, pkg

    build = (ROOT / "packaging" / "live" / "inside-docker.sh").read_text(
        encoding="utf-8"
    )
    assert '--debootstrap-options "--variant=minbase"' in build
    assert "--ignore-system-defaults" in build


def test_nwipe_hook_fails_closed_instead_of_unpinned_fallback():
    text = HOOK.read_text(encoding="utf-8")
    assert f"v{NWIPE_PINNED_VERSION}" in text or f"{NWIPE_PINNED_VERSION}" in text
    assert NWIPE_PINNED_COMMIT in text
    assert "apt-get install -y nwipe" not in text
    assert "apt-get purge -y nwipe" not in text
    assert "ERROR: gcc is still present" in text
    assert "ERROR: nwipe commit" in text
    assert "git clone nwipe failed after" in text
    assert "GIT_CONFIG_NOSYSTEM=1" in text
    assert "GIT_CONFIG_GLOBAL=/dev/null" in text
    assert "GIT_CONFIG_SYSTEM=/dev/null" in text


def test_nwipe_hook_accepts_safe_debian_arch_qualifier_before_purge():
    text = HOOK.read_text(encoding="utf-8")
    assert "base_package=\"${package%%:*}\"" in text
    assert 'case "$base_package" in' in text
    assert "apt-get purge -y -- \"$@\"" in text
    assert "grep -E '^(gcc|g\\+\\+)" in text


def test_live_launcher_isolates_sys_path_and_preview_env():
    text = LAUNCHER.read_text(encoding="utf-8")
    assert "python3 -sP" in text
    assert "PYTHONPATH=/usr/lib/python3/dist-packages" in text
    assert "PYTHONNOUSERSITE=1" in text
    assert "unset BEAMO_WIPE_DRY_RUN" in text
    assert "unset BEAMO_WIPE_BOOT_DEVICE" in text
    assert "unset LD_PRELOAD" in text
    assert "unset PYTHONSTARTUP" in text
    assert "PATH=/usr/sbin:/usr/bin:/sbin:/bin" in text
    assert "umask 077" in text
    assert "cd /" in text
    assert "--demo" not in text
    assert "--dry-run" not in text


def test_nwipe_hook_hides_engine_and_extra_gettys():
    text = HOOK.read_text(encoding="utf-8")
    assert "/usr/lib/beamo-wipe/nwipe" in text
    assert "ERROR: nwipe is still on PATH" in text
    assert "/usr/sbin/nwipe" in text
    assert "nwipe is not run directly" in text
    assert 'systemctl mask "getty@${tty}.service"' in text or "getty@tty2.service" in text
    logind = (
        ROOT
        / "packaging/live/config/includes.chroot/etc/systemd/logind.conf.d/beamo-kiosk.conf"
    ).read_text(encoding="utf-8")
    assert "NAutoVTs=1" in logind
    assert "systemd-networkd.service" in text
    assert "sshd.service" in text
    assert "getty@tty1" in text or 'getty@${tty}' in text
    assert "beamo-wipe-kiosk.service" in text


def test_iso_build_uses_https_debian_mirrors():
    text = (ROOT / "packaging/live/inside-docker.sh").read_text(encoding="utf-8")
    assert "https://deb.debian.org/debian/" in text
    assert "https://security.debian.org/" in text
    assert "ip=frommedia" in text
    assert "--bootappend-live-failsafe" in text
    failsafe = [
        line
        for line in text.splitlines()
        if "--bootappend-live-failsafe" in line
    ]
    assert failsafe
    assert "noswap" in failsafe[0]
    assert "ip=frommedia" in failsafe[0]
    assert "nopersistence" in failsafe[0]
    assert "http://deb.debian.org/debian/" not in text


def test_live_config_bootstrap_uses_https_debian_mirrors():
    bootstrap = ROOT / "packaging/live/config/bootstrap"
    binary = ROOT / "packaging/live/config/binary"
    if not bootstrap.is_file() or not binary.is_file():
        import pytest

        pytest.skip("lb config artifacts are generated by scripts/build-iso.sh")
    bootstrap_text = bootstrap.read_text(encoding="utf-8")
    assert "https://deb.debian.org/debian/" in bootstrap_text
    assert "https://security.debian.org/" in bootstrap_text
    assert "http://deb.debian.org/" not in bootstrap_text
    assert "http://security.debian.org/" not in bootstrap_text
    binary_text = binary.read_text(encoding="utf-8")
    assert "ip=frommedia" in binary_text
    assert 'LB_FIRMWARE_BINARY="false"' in binary_text
    assert 'LB_FIRMWARE_CHROOT="false"' in binary_text
    failsafe_cfg = [
        line
        for line in binary_text.splitlines()
        if line.startswith("LB_BOOTAPPEND_LIVE_FAILSAFE=")
    ]
    assert failsafe_cfg
    assert "noswap" in failsafe_cfg[0]
    assert "ip=frommedia" in failsafe_cfg[0]
    assert "username=root" in failsafe_cfg[0]
    assert "nopersistence" in failsafe_cfg[0]


def test_staged_chroot_package_matches_src():
    src = ROOT / "src/beamo_wipe"
    staged = (
        ROOT
        / "packaging/live/config/includes.chroot/usr/lib/python3/dist-packages/beamo_wipe"
    )
    if not staged.is_dir():
        return
    for path in src.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix == ".pyc" or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(src)
        other = staged / rel
        assert other.is_file(), f"missing staged copy of {rel}"
        assert other.read_bytes() == path.read_bytes(), f"staged copy drifted: {rel}"


def test_xorg_does_not_force_vesa_on_every_gpu():
    text = (
        ROOT / "packaging/live/config/includes.chroot/etc/X11/xorg.conf.d/10-beamo.conf"
    ).read_text(encoding="utf-8")
    assert 'Driver "vesa"' not in text
    assert "AllowMouseOpenFail" in text
    assert 'Section "Device"' not in text
    assert 'Option "XkbLayout" "us"' in text
    default = (
        ROOT / "packaging/live/config/includes.chroot/etc/default/keyboard"
    ).read_text(encoding="utf-8")
    assert 'XKBLAYOUT="us"' in default
    kiosk = SUPERVISOR.read_text(encoding="utf-8")
    assert "setxkbmap" not in kiosk
    assert "loadkeys" not in kiosk


def test_live_config_xinit_cannot_hijack_kiosk():
    """Debian live-config 0140-xinit writes an infinite startx loop on tty1
    before ~/.profile. Without nox11autologin (and a stub profile.d file),
    the wizard never starts."""
    docker = (ROOT / "packaging/live/inside-docker.sh").read_text(encoding="utf-8")
    for option in ("--bootappend-live ", "--bootappend-live-failsafe "):
        (line,) = [line for line in docker.splitlines() if option in line]
        assert "nox11autologin" in line
    stub = (
        ROOT
        / "packaging/live/config/includes.chroot/etc/profile.d/zz-live-config_xinit.sh"
    )
    assert stub.is_file()
    stub_text = stub.read_text(encoding="utf-8")
    assert "while true" not in stub_text
    assert not any(line.strip().startswith("startx") for line in stub_text.splitlines())
    hook = HOOK.read_text(encoding="utf-8")
    assert "0140-xinit" in hook
    binary = ROOT / "packaging/live/config/binary"
    if not binary.is_file():
        import pytest

        pytest.skip("lb config artifacts are generated by scripts/build-iso.sh")
    binary_text = binary.read_text(encoding="utf-8")
    live_line = [
        line
        for line in binary_text.splitlines()
        if line.startswith("LB_BOOTAPPEND_LIVE=") and "FAILSAFE" not in line
    ]
    assert live_line
    assert "nox11autologin" in live_line[0]
    failsafe = [
        line
        for line in binary_text.splitlines()
        if line.startswith("LB_BOOTAPPEND_LIVE_FAILSAFE=")
    ]
    assert failsafe
    assert "nox11autologin" in failsafe[0]


def test_extra_gettys_are_masked_as_unit_symlinks():
    """systemctl mask is a no-op in the live-build chroot (not PID 1)."""
    text = HOOK.read_text(encoding="utf-8")
    assert 'ln -sfn /dev/null "/etc/systemd/system/getty@${tty}.service"' in text or (
        'ln -sfn /dev/null /etc/systemd/system/getty@${tty}.service' in text
    )
    assert "getty@tty2" in text or "getty@${tty}" in text


def test_kiosk_is_a_hardened_systemd_service_not_a_login_shell():
    service = SERVICE.read_text(encoding="utf-8")
    supervisor = SUPERVISOR.read_text(encoding="utf-8")
    assert "ExecStart=/usr/local/sbin/beamo-wipe-kiosk" in service
    assert "Conflicts=getty@tty1.service" in service
    assert "NoNewPrivileges=yes" in service
    assert "PrivateNetwork=yes" in service
    assert "ProtectSystem=full" in service
    assert "StandardOutput=tty" in service
    assert "StandardError=tty" in service
    assert "trap '' TSTP INT QUIT" in supervisor
    assert not (ROOT / "packaging/live/config/includes.chroot/etc/systemd/system/getty@tty1.service.d/autologin.conf").exists()


def test_bootloaders_autostart_the_normal_live_entry():
    """An unattended kiosk must not wait forever at either firmware menu."""
    isolinux = (
        ROOT
        / "packaging/live/config/bootloaders/isolinux/isolinux.cfg"
    ).read_text()
    grub = (
        ROOT
        / "packaging/live/config/bootloaders/grub-pc/config.cfg"
    ).read_text()

    assert "default vesamenu.c32" in isolinux
    assert "prompt 0" in isolinux
    assert "timeout 50" in isolinux  # Syslinux units are tenths of a second.
    assert "NOESCAPE 1" in isolinux
    assert "ALLOWOPTIONS 0" in isolinux
    assert "timeout 0" not in isolinux
    assert "set default=0" in grub
    assert "set timeout=5" in grub
    assert 'set superusers="beamo"' in grub


def test_live_supervisor_falls_back_to_console_after_x_failure():
    text = SUPERVISOR.read_text(encoding="utf-8")
    assert "startx /usr/local/bin/beamo-wipe" in text
    assert "rm -f /tmp/.X11-unix/X0" in text
    assert "/usr/local/bin/beamo-wipe --console" in text
    assert "while :" in text


def test_kiosk_supervisor_disables_suspend_and_interrupt():
    text = SUPERVISOR.read_text(encoding="utf-8")
    assert "stty susp undef" in text
    assert "stty intr undef" in text
    assert "trap '' TSTP" in text or 'trap "" TSTP' in text
    assert "rm -f /tmp/.X11-unix/X0" in text


def test_live_kiosk_ignores_sigint():
    text = (ROOT / "src/beamo_wipe/app.py").read_text(encoding="utf-8")
    assert "signal.SIGINT" in text
    assert "signal.SIGTSTP" in text

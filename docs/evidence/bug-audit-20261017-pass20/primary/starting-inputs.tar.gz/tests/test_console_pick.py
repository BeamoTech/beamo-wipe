# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path

from beamo_wipe.models import Screen
from beamo_wipe.ui.console_wizard import _plain_loop
from beamo_wipe.wizard import make_demo_wizard


def test_plain_console_zero_does_not_select_last_disk(monkeypatch):
    wiz = make_demo_wizard()
    wiz.skip_intro()
    wiz.accept_what()
    wiz.set_owner(True)
    wiz.continue_owner()
    assert wiz.screen == Screen.PICK
    assert wiz.selected is None
    calls = []

    def fake_input(_prompt=""):
        calls.append(1)
        if len(calls) == 1:
            return "0"
        wiz.shutdown()
        return "x"

    monkeypatch.setattr("builtins.input", fake_input)
    _plain_loop(wiz)
    assert wiz.screen == Screen.PICK
    assert wiz.selected is None


def test_plain_console_garbage_method_stays_on_method(monkeypatch):
    """Invalid method input must re-prompt, not start the last-chance countdown."""
    from beamo_wipe.models import MethodId

    wiz = make_demo_wizard()
    wiz.skip_intro()
    wiz.accept_what()
    wiz.set_owner(True)
    wiz.continue_owner()
    wiz.select_disk(wiz.selectable[0].path)
    wiz.continue_pick()
    wiz.set_confirm_input(wiz.confirm.token)
    wiz.continue_confirm()
    assert wiz.screen == Screen.METHOD
    screens = []

    def fake_input(_prompt=""):
        screens.append(wiz.screen)
        if len(screens) == 1:
            return "nope"
        wiz.shutdown()
        return "x"

    monkeypatch.setattr("builtins.input", fake_input)
    _plain_loop(wiz)
    assert screens
    assert all(s == Screen.METHOD for s in screens)
    assert wiz.screen == Screen.METHOD
    assert wiz.method == MethodId.EVERYDAY


def test_plain_console_eof_does_not_crash(monkeypatch):
    """Ctrl-D on the last-resort TTY must shut down, not raise EOFError."""
    wiz = make_demo_wizard()
    wiz.skip_intro()
    wiz.accept_what()

    def fake_input(_prompt=""):
        raise EOFError

    monkeypatch.setattr("builtins.input", fake_input)
    code = _plain_loop(wiz)
    assert code == 0
    assert wiz.wants_shutdown
    assert not getattr(wiz.runner, "started", False)


def test_plain_console_empty_method_keeps_extra(monkeypatch):
    """Enter on Choice [1] must not overwrite Extra thorough after backing up."""
    from beamo_wipe.models import MethodId

    wiz = make_demo_wizard()
    wiz.skip_intro()
    wiz.accept_what()
    wiz.set_owner(True)
    wiz.continue_owner()
    wiz.select_disk(wiz.selectable[0].path)
    wiz.continue_pick()
    wiz.set_confirm_input(wiz.confirm.token)
    wiz.continue_confirm()
    wiz.set_method(MethodId.EXTRA)
    wiz.continue_method()
    assert wiz.screen == Screen.LAST_CHANCE
    steps = []

    def fake_input(_prompt=""):
        steps.append(wiz.screen)
        if wiz.screen == Screen.LAST_CHANCE:
            if steps.count(Screen.LAST_CHANCE) == 1:
                return "nope"
            wiz.shutdown()
            return "x"
        if wiz.screen == Screen.METHOD:
            return ""
        wiz.shutdown()
        return "x"

    monkeypatch.setattr("builtins.input", fake_input)
    _plain_loop(wiz)
    assert wiz.method == MethodId.EXTRA
    assert Screen.METHOD in steps


def test_curses_enter_repeat_helper_ignores_second_enter():
    from beamo_wipe.ui.console_wizard import _is_enter_repeat

    assert not _is_enter_repeat(False, 10)
    assert _is_enter_repeat(True, 10)
    assert _is_enter_repeat(True, 13)
    assert not _is_enter_repeat(True, ord("x"))


def _drive_to_working_plain(wiz):
    wiz.skip_intro()
    wiz.accept_what()
    wiz.set_owner(True)
    wiz.continue_owner()
    wiz.select_disk(wiz.selectable[0].path)
    wiz.continue_pick()
    wiz.set_confirm_input(wiz.confirm.token)
    wiz.continue_confirm()
    wiz.continue_method()
    return wiz


def test_plain_working_hint_does_not_promise_typing(capsys):
    """WORKING must not tell the owner to 'type cancel + Enter': the plain
    loop never reads stdin on WORKING, so the instruction is unexecutable."""
    from beamo_wipe.ui import console_wizard as C

    import inspect

    src = inspect.getsource(C._plain_loop_body)
    working = src.split("if screen == Screen.WORKING:", 1)[1].split("Screen.DONE", 1)[0]
    assert "input(" not in working.replace("via input()", "")
    out = working
    assert "type 'cancel'" not in out


def test_plain_loop_ctrl_c_while_working_cancels(monkeypatch):
    """Ctrl-C during a plain-loop wipe must cancel it, not traceback.

    Fake runner only; no real device is ever touched.
    """
    from beamo_wipe.models import Screen
    from beamo_wipe.nwipe_runner import DryRunRunner
    from beamo_wipe.ui import console_wizard as C
    from beamo_wipe.wizard import Wizard

    class _Clock:
        t = 0.0

        def __call__(self):
            return _Clock.t

    base = make_demo_wizard()
    wiz = Wizard(base.discovery, DryRunRunner(duration_s=60.0), clock=_Clock(), dry_run=True)
    _drive_to_working_plain(wiz)
    _Clock.t += 5.0
    wiz.confirm_erase()
    assert wiz.screen == Screen.WORKING

    class _Time:
        calls = 0

        @staticmethod
        def sleep(_s):
            _Time.calls += 1
            if _Time.calls == 1:
                raise KeyboardInterrupt

    monkeypatch.setattr(C, "time", _Time)
    monkeypatch.setattr(
        "builtins.input", lambda _prompt="": (wiz.shutdown(), "x")[1]
    )
    code = C._plain_loop(wiz)
    assert code == 0
    assert wiz.runner.cancelled is True
    assert wiz.screen == Screen.DONE
    assert wiz.wipe_result is not None and not wiz.wipe_result.ok


def test_plain_loop_ctrl_c_outside_working_shuts_down(monkeypatch):
    """Ctrl-C before any wipe must shut down cleanly, not traceback."""
    from beamo_wipe.models import Screen
    from beamo_wipe.ui import console_wizard as C

    wiz = make_demo_wizard()
    wiz.skip_intro()
    wiz.accept_what()
    assert wiz.screen == Screen.OWNER

    def fake_input(_prompt=""):
        raise KeyboardInterrupt

    monkeypatch.setattr("builtins.input", fake_input)
    code = C._plain_loop(wiz)
    assert code == 0
    assert wiz.wants_shutdown


def test_curses_confirm_enter_sets_held_so_method_is_not_skipped():
    """Confirm uses its own getch and `continue`s; that path must set enter_held."""
    import inspect

    from beamo_wipe.ui.console_wizard import _loop

    src = inspect.getsource(_loop)
    assert "wizard.continue_confirm()" in src
    assert "enter_held = True" in src


def test_curses_pick_shows_serial_and_same_size_hint():
    text = (
        Path(__file__)
        .resolve()
        .parents[1]
        .joinpath("src/beamo_wipe/ui/console_wizard.py")
        .read_text(encoding="utf-8")
    )
    assert "disk_view" in text
    assert "SAME_SIZE_HINT" in text
    assert "_identity_field_lines" in text
    assert "listed_disks" in text
    assert "wizard.progress_view.status_text" in text
    assert "AMBIGUOUS_IDENTITY" not in text or "too similar" in text or "compact_line" in text


def test_curses_pick_empty_enter_ignored_until_idle():
    from beamo_wipe.ui.console_wizard import _handle

    wiz = make_demo_wizard(scenario="empty")
    wiz.preview = False
    wiz.skip_intro()
    wiz.accept_what()
    wiz.set_owner(True)
    wiz.continue_owner()
    assert wiz.screen == Screen.PICK_EMPTY
    _handle(wiz, 10)
    assert not wiz.wants_shutdown
    wiz.arm_done_keyboard()
    _handle(wiz, 10)
    assert wiz.wants_shutdown


def test_curses_done_enter_ignored_until_idle():
    from beamo_wipe.models import WipeResult
    from beamo_wipe.ui.console_wizard import _handle

    wiz = make_demo_wizard(fail=True)
    wiz.preview = False
    wiz._finish(
        WipeResult(ok=False, exit_code=1, summary="The wipe did not finish.", logfile="")
    )
    _handle(wiz, 10)
    assert not wiz.wants_shutdown
    wiz.arm_done_keyboard()
    _handle(wiz, 10)
    assert wiz.wants_shutdown



def test_plain_working_sounds_command_toggles(monkeypatch, tmp_path, capsys):
    import select as select_module
    import sys
    import time

    from beamo_wipe import copy as C
    from beamo_wipe import sound as sound_module
    from test_wizard_flow import _drive_to_working, _wiz

    def _boom(*a, **k):
        raise AssertionError("spawned audio")

    monkeypatch.setattr(sound_module, "_run", _boom)
    monkeypatch.setattr(sound_module, "_popen", _boom)
    monkeypatch.setattr(
        "beamo_wipe.safety.default_log_dir", lambda: tmp_path
    )
    wiz, clock = _wiz()
    wiz.preview = False
    _drive_to_working(wiz, clock)
    lines = ["sounds\n", "hear\n", ""]
    pos = {"i": 0}

    class FakeStdin:
        def readline(self):
            if pos["i"] >= 2:
                end = time.monotonic() + 1
                while wiz._audio_request is not None and time.monotonic() < end:
                    wiz.tick()
                    time.sleep(0.005)
            line = lines[min(pos["i"], len(lines) - 1)]
            pos["i"] += 1
            return line

    monkeypatch.setattr(sys, "stdin", FakeStdin())
    monkeypatch.setattr(
        select_module, "select", lambda r, w, x, t=0: (r, [], [])
    )
    assert _plain_loop(wiz) == 0
    assert wiz.sounds_enabled is True
    assert wiz.sound_message == C.SOUND_OUTCOME_OFF_LIVE
    out = capsys.readouterr().out
    assert C.SOUND_TOGGLE_ON in out
    assert "SOUNDS" in out


def test_plain_done_sounds_words_and_auto_play(monkeypatch, tmp_path, capsys):
    import time
    from beamo_wipe import copy as C
    from beamo_wipe import sound as sound_module
    from beamo_wipe.models import WipeResult
    from test_wizard_flow import _drive_to_working, _wiz

    monkeypatch.setattr(
        "beamo_wipe.safety.default_log_dir", lambda: tmp_path
    )
    wiz, clock = _wiz()
    wiz.preview = False
    _drive_to_working(wiz, clock)
    wiz.runner.duration_s = 1000
    wiz._finish(
        WipeResult(True, 0, "Erase completed", str(tmp_path / "x.log"))
    )
    calls = []
    monkeypatch.setattr(
        sound_module,
        "play_test",
        lambda kind: calls.append(kind) or sound_module.SoundResult(False, C.SOUND_OUTCOME_OFF_LIVE),
    )
    answers = ["SOUNDS", "HEAR", "SHUTDOWN"]

    def fake_input(_prompt=""):
        if answers and answers[0] in {"HEAR", "SHUTDOWN"}:
            end = time.monotonic() + 1
            while wiz._audio_request is not None and time.monotonic() < end:
                wiz.tick()
                time.sleep(0.005)
        if answers:
            return answers.pop(0)
        wiz.shutdown()
        return "x"

    monkeypatch.setattr("builtins.input", fake_input)
    assert _plain_loop(wiz) == 0
    assert wiz.sounds_enabled is True
    assert calls == [sound_module.KIND_ATTENTION, sound_module.KIND_ATTENTION]
    assert wiz.sound_message == C.SOUND_OUTCOME_OFF_LIVE
    out = capsys.readouterr().out
    assert C.SOUND_TOGGLE_ON in out
    assert "HEAR" in out

# SPDX-License-Identifier: GPL-3.0-or-later
"""Process entry. Preview with ./preview or --demo. Never auto-starts a wipe."""

from __future__ import annotations

import argparse
import os
import signal
import sys
from pathlib import Path

from beamo_wipe import NWIPE_PINNED_VERSION
from beamo_wipe.compat_story import version_report
from beamo_wipe.demo import Scenario, make_demo_wizard
from beamo_wipe.discover import discover, load_lsblk_json_text
from beamo_wipe.nwipe_runner import DryRunRunner, NwipeRunner
from beamo_wipe.models import Screen
from beamo_wipe.safety import SafetyError, require_live_or_dry_run, running_on_live_usb
from beamo_wipe.ui import StartupDisplayUnavailable
from beamo_wipe.wizard import Wizard


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


class _VersionAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        parser.exit(status=0, message=version_report())


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="beamo-wipe",
        description=(
            "Guided front-end for nwipe. This is not a wipe engine. "
            "It will not erase disks from inside Windows or macOS. "
            "On this computer, use --preview or ./preview (fake disks)."
        ),
    )
    p.add_argument(
        "--demo",
        "--preview",
        dest="demo",
        action="store_true",
        help="Tk window with fake disks. Nothing is erased.",
    )
    p.add_argument(
        "--web",
        "--gallery",
        dest="web",
        action="store_true",
        help="Open a browser click-through of the screens. Does not wipe.",
    )
    p.add_argument(
        "--lang",
        choices=("en", "fr", "de"),
        default="en",
        help="Gallery language: en, fr, or de. Preview only; ignored on the live USB.",
    )
    p.add_argument(
        "--helper",
        action="store_true",
        help="Open the boot-menu helper page (does not wipe).",
    )
    p.add_argument(
        "--scenario",
        choices=("happy", "empty", "blocked", "fail"),
        default="happy",
        help="Preview disk list: happy, empty, blocked, or fail.",
    )
    p.add_argument("--empty", action="store_true", help="Preview: only the Beamo USB.")
    p.add_argument("--blocked", action="store_true", help="Preview: cannot identify USB.")
    p.add_argument(
        "--fail",
        "--fail-demo",
        dest="fail_demo",
        action="store_true",
        help="Preview a failed wipe.",
    )
    p.add_argument("--plain-console", action="store_true", help="Use sequential text prompts without curses screen redraws.")
    p.add_argument("--console", action="store_true", help="Use the keyboard console UI.")
    p.add_argument("--accessible", action="store_true", help="Use the Linux GTK screen-reader view.")
    p.add_argument("--fullscreen", action="store_true", help="Fill the screen (live USB).")
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Do not invoke nwipe. Test only; ignored on the live USB.",
    )
    p.add_argument(
        "--lsblk-json",
        help="Read disks from an lsblk JSON file. Test only; ignored on the live USB.",
    )
    p.add_argument(
        "--boot-device",
        help="Override live-medium path. Test only; ignored on the live USB.",
    )
    p.add_argument("--version", action=_VersionAction, nargs=0, help="Show version and USB image identity.")
    return p


def _scenario(args: argparse.Namespace) -> Scenario:
    if args.empty:
        return "empty"
    if args.blocked:
        return "blocked"
    if args.fail_demo:
        return "fail"
    return args.scenario  # type: ignore[return-value]


def _open_html(path: Path) -> int:
    if not path.is_file():
        print(MISSING_FILE.format(path=path), file=sys.stderr)
        return 2
    if os.environ.get("BEAMO_WIPE_NO_OPEN") == "1":
        print(path)
        return 0
    import webbrowser

    try:
        opened = webbrowser.open(path.resolve().as_uri())
    except Exception:
        opened = False
    if not opened:
        print(f"Could not open the helper in a browser: {path}", file=sys.stderr)
        return 2
    print(path)
    return 0


def apply_live_session_overrides(args: argparse.Namespace) -> None:
    """On the live USB, preview/gallery flags cannot disguise a fake wipe."""
    if not running_on_live_usb():
        return
    cleared = [
        name
        for name, was_set in (
            ("demo", args.demo),
            ("empty", args.empty),
            ("blocked", args.blocked),
            ("fail_demo", args.fail_demo),
            ("scenario", args.scenario != "happy"),
            ("lsblk_json", bool(args.lsblk_json)),
            ("boot_device", bool(args.boot_device)),
            ("dry_run", args.dry_run),
            ("web", args.web),
            ("helper", args.helper),
            ("lang", args.lang != "en"),
        )
        if was_set
    ]
    args.demo = False
    args.empty = False
    args.blocked = False
    args.fail_demo = False
    args.scenario = "happy"
    args.lsblk_json = None
    args.boot_device = None
    args.dry_run = False
    args.web = False
    args.helper = False
    args.lang = "en"
    os.environ.pop("BEAMO_WIPE_BOOT_DEVICE", None)
    os.environ.pop("BEAMO_WIPE_DRY_RUN", None)
    os.environ.pop("BEAMO_WIPE_DEMO", None)
    if cleared:
        # Visible to maintainers: an operator who passed a test flag on the
        # live USB should find why it had no effect. Never raises.
        try:
            from beamo_wipe.diagnostics import log_diag

            log_diag("app", "live_overrides_cleared", ",".join(sorted(cleared))[:120])
        except Exception:
            pass


def _build_wizard(args: argparse.Namespace, progress=None) -> Wizard:
    apply_live_session_overrides(args)

    if args.demo:
        os.environ["BEAMO_WIPE_DEMO"] = "1"
        os.environ["BEAMO_WIPE_DRY_RUN"] = "1"
        return make_demo_wizard(
            fail=args.fail_demo, scenario=_scenario(args), synthesize_stages=True
        )

    if args.lsblk_json:
        args.dry_run = True
    if args.dry_run:
        os.environ["BEAMO_WIPE_DRY_RUN"] = "1"
    if args.boot_device:
        os.environ["BEAMO_WIPE_BOOT_DEVICE"] = args.boot_device

    require_live_or_dry_run()

    payload = None
    if args.lsblk_json:
        with open(args.lsblk_json, encoding="utf-8") as fh:
            payload = load_lsblk_json_text(fh.read())

    import time as _time

    _discover_start = _time.monotonic()
    discovery = discover(
        lsblk_payload=payload,
        boot_path=args.boot_device,
        progress=progress,
    )
    try:
        from beamo_wipe.diagnostics import log_diag as _log_diag

        _elapsed_ms = int((_time.monotonic() - _discover_start) * 1000)
        _log_diag(
            "discover",
            "timing",
            f"elapsed_ms={_elapsed_ms} boot_identified={discovery.boot_identified}",
        )
    except Exception:
        pass
    use_dry = (
        args.dry_run
        or args.demo
        or bool(args.lsblk_json)
        or os.environ.get("BEAMO_WIPE_DEMO") == "1"
        or os.environ.get("BEAMO_WIPE_DRY_RUN") == "1"
    )
    if use_dry:
        runner = DryRunRunner(
            duration_s=3.0, fail=args.fail_demo, synthesize_stages=True
        )
        def fresh_fake_discovery():
            if not args.lsblk_json:
                raise SafetyError(FAKE_REQUIRED)
            with open(args.lsblk_json, encoding="utf-8") as fh:
                fresh_payload = load_lsblk_json_text(fh.read())
            return discover(lsblk_payload=fresh_payload, boot_path=args.boot_device)
        return Wizard(discovery, runner, dry_run=True, rediscover=fresh_fake_discovery)
    live_runner = NwipeRunner()
    return Wizard(discovery, live_runner, dry_run=False)


def _shutdown() -> bool:
    import subprocess

    last_exc: Exception | None = None
    for cmd in (
        ["/usr/bin/systemctl", "poweroff"],
        ["/bin/systemctl", "poweroff"],
        ["/sbin/shutdown", "-h", "now"],
        ["/usr/sbin/shutdown", "-h", "now"],
        ["/sbin/poweroff"],
        ["/usr/sbin/poweroff"],
        ["/sbin/halt", "-p"],
    ):
        try:
            # Harden: never inherit attacker-controlled env (LD_PRELOAD etc.)
            # even for poweroff — use the same replacement env as nwipe.
            from beamo_wipe.safety import CLEAN_SUBPROCESS_ENV

            completed = subprocess.run(
                cmd,
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
                env=CLEAN_SUBPROCESS_ENV,
                shell=False,
                timeout=8,
            )
            if completed.returncode == 0:
                return True
            last_exc = RuntimeError(f"exit {completed.returncode}")
        except (OSError, subprocess.TimeoutExpired) as exc:
            last_exc = exc
            continue
    # All shutdown paths failed; surface to diagnostics and stderr (safe, no secrets)
    try:
        from beamo_wipe.diagnostics import log_diag

        detail = type(last_exc).__name__ if last_exc else "unknown"
        log_diag("app", "shutdown_failed", detail)
    except Exception:
        pass
    print(SHUTDOWN_FAILED, file=sys.stderr)
    return False


def _shutdown_if_still_safe(wizard: Wizard) -> bool:
    if not wizard.shutdown_still_safe():
        print(POWER_REQUEST_BLOCKED, file=sys.stderr)
        return False
    return _shutdown()


def _blocked_wizard(exc: Exception) -> Wizard:
    # Startup remains fail-closed, but support stays reachable.
    from beamo_wipe.diagnostic_report import exception_code
    from beamo_wipe.models import DiscoveryResult
    startup_code = exception_code(exc)
    discovery = DiscoveryResult(error=STARTUP_BLOCKED,
                                error_code=startup_code)
    wizard = Wizard(discovery, DryRunRunner(), dry_run=not running_on_live_usb())
    wizard._startup_blocked = True
    wizard.screen = Screen.PICK_BLOCKED
    wizard.error = discovery.error
    print(STARTUP_BLOCKED_LOG.format(code=startup_code), file=sys.stderr)
    return wizard


def _print_startup_row(title: str, hint: str) -> None:
    import textwrap as _textwrap

    print(f"{title}.")
    for line in _textwrap.wrap(hint, 76):
        print(line)


def _build_wizard_with_console_stages(args: argparse.Namespace) -> Wizard:
    """Staged startup for the keyboard screens: lines, then the wizard."""
    import time as _time

    from beamo_wipe.startup_stages import StartupRun

    run = StartupRun(lambda report: _build_wizard(args, progress=report))
    shown: set = set()

    def show() -> None:
        for row in run.drain():
            if row["state"] == "pending" or row["key"] in shown:
                continue
            shown.add(row["key"])
            _print_startup_row(row["title"], row["hint"])

    show()
    try:
        run.start()
    except Exception as exc:
        # A worker launch failure leaves no startup outcome to poll. Keep the
        # same blocked support route as a discovery failure.
        return _blocked_wizard(exc)
    while True:
        _time.sleep(0.2)
        outcome = run.poll()
        # Poll drains first, so this prints the final stage too — the last
        # line before the wizard is never "Waiting" for finished work.
        show()
        note = run.stalled_note()
        if note is not None:
            print(note)
        if outcome is None:
            continue
        kind, payload = outcome
        if kind == "wizard":
            return payload
        return _blocked_wizard(payload)


def _build_without_splash(args: argparse.Namespace) -> Wizard:
    """Synchronous build when no display exists for a startup splash."""
    try:
        return _build_wizard(args)
    except Exception as exc:  # startup remains fail-closed, support reachable
        return _blocked_wizard(exc)


def _build_wizard_with_tk_stages(args: argparse.Namespace, fullscreen: bool):
    """Staged startup for the graphical wizard; None when abandoned."""
    from beamo_wipe.ui.tk_wizard import run_tk_startup

    try:
        kind, payload = run_tk_startup(
            lambda report: _build_wizard(args, progress=report),
            fullscreen=fullscreen,
        )
    except StartupDisplayUnavailable:
        # No display for the splash (probe refused to abort the process).
        # Build with no splash; the later run_tk keeps the long-standing
        # graphical-failure path (keyboard fallback, or code 3).
        return _build_without_splash(args)
    except Exception as exc:
        return _blocked_wizard(exc)
    if kind == "wizard":
        return payload
    if kind == "failed":
        return _blocked_wizard(payload)
    return None


def _build_wizard_with_accessible_stages(args: argparse.Namespace, fullscreen: bool):
    """Staged startup for the screen-reader view; None when abandoned."""
    from beamo_wipe.ui.accessible_wizard import run_accessible_startup

    try:
        kind, payload = run_accessible_startup(
            lambda report: _build_wizard(args, progress=report),
            fullscreen=fullscreen,
        )
    except StartupDisplayUnavailable:
        # No display for the splash; same fallback discipline as Tk.
        return _build_without_splash(args)
    except Exception as exc:
        return _blocked_wizard(exc)
    if kind == "wizard":
        return payload
    if kind == "failed":
        return _blocked_wizard(payload)
    return None


def _main(argv: list[str] | None = None, *, session_store=None, args=None) -> int:
    args = args if args is not None else _parser().parse_args(argv)
    if args.empty or args.blocked or args.fail_demo or args.scenario != "happy":
        args.demo = True
    apply_live_session_overrides(args)
    if not args.demo:
        try:
            signal.signal(signal.SIGTSTP, signal.SIG_IGN)
            signal.signal(signal.SIGINT, signal.SIG_IGN)
        except (AttributeError, ValueError, OSError):
            pass
    if args.web:
        from beamo_wipe.gallery import open_gallery, write_gallery

        dest = project_root() / "web-preview" / "index.html"
        if not (project_root() / "helper" / "index.html").is_file():
            dest = Path.cwd() / "web-preview" / "index.html"
        try:
            if os.environ.get("BEAMO_WIPE_NO_OPEN") == "1":
                path = write_gallery(dest, args.lang)
            else:
                path = open_gallery(dest, args.lang)
        except OSError:
            print("Could not write or open the preview gallery in a browser.", file=sys.stderr)
            return 2
        print(path)
        return 0
    if args.helper:
        helper = project_root() / "helper" / "index.html"
        if not helper.is_file():
            helper = Path.cwd() / "helper" / "index.html"
        return _open_html(helper)

    windowed = args.demo and not args.fullscreen
    use_console = args.plain_console or args.console or os.environ.get("BEAMO_WIPE_UI") == "console"
    want_accessible = (not use_console
                       and (args.accessible or os.environ.get("BEAMO_WIPE_UI") == "accessible"))
    fullscreen = args.fullscreen or not windowed
    reader = None
    if want_accessible and not args.demo:
        # Speech starts before the startup stages so a blind owner hears
        # discovery progress instead of a silent window.
        from beamo_wipe.ui.accessible_wizard import start_live_reader

        reader = start_live_reader()
    try:
        return _run_session(
            args,
            session_store=session_store,
            use_console=use_console,
            want_accessible=want_accessible,
            fullscreen=fullscreen,
            reader=reader,
        )
    finally:
        if reader is not None:
            from beamo_wipe.ui.accessible_wizard import stop_live_reader

            stop_live_reader(reader)


def _run_session(args, *, session_store, use_console, want_accessible,
                 fullscreen, reader) -> int:
    # A new object graph is the session boundary: never reset live authority
    # fields in place or reuse a runner, report worker, or discovery snapshot.
    keyboard_layout = None
    language = None
    text_size = None
    owned_reader = None
    try:
        while True:
            # Tk can switch to the accessible view after _main's initial
            # reader decision. Start Orca before the next startup stages so
            # that a fresh disk discovery is announced as well as the wizard.
            if want_accessible and not args.demo and running_on_live_usb():
                needs_reader = reader is None
                poll_reader = getattr(reader, "poll", None)
                if not needs_reader and callable(poll_reader):
                    try:
                        needs_reader = poll_reader() is not None
                    except OSError:
                        # An unreadable process status cannot establish that
                        # speech is still available for the next startup.
                        needs_reader = True
                if needs_reader:
                    from beamo_wipe.ui.accessible_wizard import start_live_reader

                    owned_reader = start_live_reader()
                    reader = owned_reader
            code = _run_one_session(
                args, session_store=session_store, use_console=use_console,
                want_accessible=want_accessible, fullscreen=fullscreen, reader=reader,
                keyboard_layout=keyboard_layout, language=language,
                text_size=text_size)
            if not isinstance(code, Wizard):
                return code
            keyboard_layout = code.keyboard_layout
            language = code.language
            text_size = code.text_size
            use_console = code.diagnostic_ui == "console"
            want_accessible = code.diagnostic_ui == "accessible"
            del code
            if session_store is not None:
                session_store.begin_new_session()
    finally:
        if owned_reader is not None:
            from beamo_wipe.ui.accessible_wizard import stop_live_reader

            stop_live_reader(owned_reader)


def _run_one_session(args, *, session_store, use_console, want_accessible,
                     fullscreen, reader, keyboard_layout=None,
                     language=None, text_size=None) -> int | Wizard:
    if args.demo:
        # Instant fake data: stages would flash meaninglessly.
        try:
            wizard = _build_wizard(args)
        except Exception as exc:  # startup remains fail-closed, but support stays reachable
            wizard = _blocked_wizard(exc)
    elif use_console:
        wizard = _build_wizard_with_console_stages(args)
    elif want_accessible:
        wizard = _build_wizard_with_accessible_stages(args, fullscreen)
    else:
        wizard = _build_wizard_with_tk_stages(args, fullscreen)
    if wizard is None:
        # The startup display was closed before discovery finished: stop
        # like a window close, without opening the wizard and without
        # powering off (closing the wizard does not power off either; the
        # kiosk supervisor offers recovery choices).
        return 0

    if not args.demo and not wizard.dry_run and running_on_live_usb():
        from beamo_wipe.report_intent import ReportIntentStore

        wizard.enable_report_intent_recovery(ReportIntentStore())

    if session_store is not None:
        wizard.enable_session_recovery(session_store)

    if keyboard_layout is not None:
        wizard.keyboard_layout = keyboard_layout
    if text_size is not None:
        wizard.set_text_size(text_size)
    wizard.diagnostic_ui = "console" if use_console else "graphical"
    # The language modules are process-wide. Every freshly constructed
    # wizard must record the same choice as the copy it will render. Keep
    # the owner's choice when they erase another disk in this live session.
    # The flag is preview/dev only; it is cleared on the live USB.
    wizard.set_language(language if language is not None else args.lang)
    if use_console and os.environ.get("BEAMO_WIPE_GRAPHICAL_UNAVAILABLE") == "1" and not wizard.startup_error_code:
        wizard.startup_error_code = "graphical_unavailable"
    if not use_console:
        try:
            if want_accessible:
                wizard.diagnostic_ui = "accessible"
                from beamo_wipe.ui.accessible_wizard import run_accessible
                code = run_accessible(wizard, fullscreen=fullscreen, reader=reader)
            else:
                from beamo_wipe.ui.tk_wizard import run_tk
                code = run_tk(wizard, fullscreen=fullscreen)
                if code == 4:
                    wizard.diagnostic_ui = "accessible"
                    from beamo_wipe.ui.accessible_wizard import run_accessible
                    code = run_accessible(wizard, fullscreen=fullscreen, reader=reader)
            if wizard.wants_new_session:
                return wizard
            if wizard.wants_shutdown and not args.demo and not wizard.dry_run:
                _shutdown_if_still_safe(wizard)
            if not wizard.wants_shutdown and not wizard.wants_new_session:
                # Tk/GTK can return without a window action (for example if
                # their event loop is quit externally). Keep the same owner
                # boundary as the console before releasing SessionStore.
                wizard.settle_failed_interface()
            return code
        except BaseException as exc:  # noqa: BLE001 — settle owned engine first
            if not isinstance(exc, Exception):
                # A control interruption bypasses the normal graphical
                # fallback. Keep the same ownership boundary as the console
                # before SessionStore's outer finally can release it.
                wizard.settle_failed_interface()
                raise
            print(GRAPHICAL_UNAVAILABLE, file=sys.stderr)
            if getattr(wizard, "_wipe_request", None) is None and not getattr(wizard, "startup_error_code", ""):
                wizard.startup_error_code = "graphical_unavailable"
            if not args.demo and not wizard.dry_run:
                # Under startx, running the console here leaves X owning tty1
                # and hides the fallback. Exit so the kiosk supervisor can
                # tear X down and launch the visible console on tty1.
                try:
                    wizard.settle_failed_interface()
                except Exception as cancel_exc:
                    try:
                        from beamo_wipe.diagnostics import log_diag

                        log_diag(
                            "app",
                            "graphical_failure_cancel_failed",
                            type(cancel_exc).__name__,
                        )
                    except Exception:
                        pass
                return 3
            use_console = True

    wizard.diagnostic_ui = "console"
    from beamo_wipe.ui.console_wizard import run_console

    try:
        if args.plain_console:
            from beamo_wipe.ui.console_wizard import _plain_loop
            code = _plain_loop(wizard)
        else:
            code = run_console(wizard)
    except BaseException:
        # The console may fail outside its own handlers. Settle any active
        # engine before SessionStore's outer finally releases UI ownership.
        wizard.settle_failed_interface()
        raise
    if not wizard.wants_shutdown and not wizard.wants_new_session:
        # A console exit without an accepted end-of-session action is also
        # interface loss, even if the renderer returned a status code.
        wizard.settle_failed_interface()
    if wizard.wants_new_session:
        return wizard
    if wizard.wants_shutdown and not args.demo and not wizard.dry_run:
        _shutdown_if_still_safe(wizard)
    return code


FAKE_REQUIRED = "A fake lsblk JSON file is required for refresh."
SHUTDOWN_FAILED = "Shutdown failed: could not power off. Hold the power button."
POWER_REQUEST_BLOCKED = "Power request blocked: an erase or report action may still be active."
STARTUP_BLOCKED = "Startup was blocked. Save a diagnostic report for support."
STARTUP_BLOCKED_LOG = "Startup blocked ({code})."
GRAPHICAL_UNAVAILABLE = "Graphical UI unavailable. Using keyboard screens."
RECOVERY_UNAVAILABLE = "Session recovery or interface ownership is unavailable. Erase startup is blocked."
MISSING_FILE = "Missing file: {path}"


def main(argv: list[str] | None = None) -> int:
    # Help, version and invalid arguments must not create a recovery session.
    args = _parser().parse_args(argv)
    if not running_on_live_usb():
        return _main(argv, args=args)
    from beamo_wipe.session_recovery import SessionStore
    store = SessionStore()
    try:
        # Acquire interface ownership and persist preflight before discovery.
        # A failed journal/identity/ownership check must never reach runner startup.
        store.open()
        return _main(argv, session_store=store, args=args)
    except (OSError, SafetyError, ValueError) as exc:
        # A fixed serial marker lets the isolated boot gate distinguish a
        # volatile-filesystem refusal from other pre-UI startup failures.
        # Never put the exception text, a disk path, or journal data on serial.
        try:
            from beamo_wipe.diagnostics import emit_serial_marker
            from beamo_wipe.session_recovery import RECOVERY_DIRECTORY_NOT_VOLATILE

            marker = (
                "BEAMO_WIPE_RECOVERY_TMP_NOT_VOLATILE"
                if isinstance(exc, SafetyError)
                and str(exc) == RECOVERY_DIRECTORY_NOT_VOLATILE
                else "BEAMO_WIPE_RECOVERY_UNAVAILABLE"
            )
            emit_serial_marker(marker)
        except Exception:
            pass
        print(RECOVERY_UNAVAILABLE, file=sys.stderr)
        return 3
    finally:
        store.close()


# Referenced by packaging so the ISO banner can print the engine version.
NWIPE_VERSION = NWIPE_PINNED_VERSION

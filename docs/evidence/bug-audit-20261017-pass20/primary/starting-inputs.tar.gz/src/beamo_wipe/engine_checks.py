# SPDX-License-Identifier: GPL-3.0-or-later
"""Parse pinned nwipe v0.42 log warnings. Never invoke hdparm or smartctl.

Statuses are pass, warning, fail, unavailable, or not_applicable. Missing,
malformed, localized, or contradictory output is unavailable — never a pass.
These checks do not rewrite wipe or verification outcomes.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Iterable, Optional

from beamo_wipe import NWIPE_PINNED_COMMIT, NWIPE_PINNED_VERSION
from beamo_wipe.models import Disk, DiskKind
from beamo_wipe.storage_limits import notice

STATUSES = frozenset({"pass", "warning", "fail", "unavailable", "not_applicable"})
CHECK_IDS = ("hidden_capacity", "io_media", "coverage")
PARSER = "beamo_wipe.engine_checks"
# nwipe v0.42 logging.c prefixes (debug lines are omitted unless --verbose).
_LEVEL = re.compile(
    r"^(?:\[[^\]\r\n]*\]\s*)?\s*(?:debug|info|notice|warning|error|fatal|sanity):\s*"
)
# Positive hidden-storage results are timestamped INFO records in v0.42.
# A bare sentence (even with an info label) fits inside an ATA model field
# after an embedded LF and is not evidence emitted by hpa_dco_status().
_INFO_RECORD = re.compile(
    r"^\[[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\]\s+info:\s+"
)
_ERROR_SUMMARY_HEADER = (
    "******************************** Error Summary "
    "*********************************"
)
# v0.42 hpa_dco.c / logging.c English lines. Do not add later-release GUI tokens.
_HIDDEN_DETECTED = re.compile(
    r"\*\*\*\s*HIDDEN SECTORS DETECTED\s*!\s*\*\*\*\s+on\s+(/dev/[A-Za-z0-9._+-]+)"
)
_HIDDEN_INDETERMINATE = re.compile(
    r"HIDDEN SECTORS INDETERMINATE!\s+on\s+(/dev/[A-Za-z0-9._+-]+)"
)
_HIDDEN_NONE = re.compile(r"No hidden sectors on[ \t]+(/dev/[A-Za-z0-9._+-]+)[ \t]*\Z")
_HPA_LINE_UNKNOWN = re.compile(
    r"\[UNKNOWN\] We can't find the HPA line, has hdparm ouput unknown/changed\?\s+"
    r"(/dev/[A-Za-z0-9._+-]+)"
)
_HDPARM_MISSING = re.compile(
    r"(?:hdparm command not found|Installing hdparm is mandatory)"
)
_HDPARM_STREAM = re.compile(r"hpa_dco_status: Failed to create stream to")
_HDPARM_FAILED = re.compile(r"hpa_dco_status\(\): hdparm failed")
_SG_IO = re.compile(r"SG_IO bad/missing sense data")
_HDPARM_INVALID = re.compile(
    r"hdparm reports invalid output, sector information may be invalid"
)
_ERROR_SUMMARY = re.compile(r"^(?:\*+\s*)?Error Summary(?:\s*\*+)?$")
_ERROR_ROW = re.compile(
    r"^[! ]\s*([A-Za-z0-9._+-]+)\s*\|\s*([0-9]{1,20})\s*\|\s*([0-9]{1,20})\s*\|\s*([0-9]{1,20})\s*$"
)
_ERASURE_SUMMARY = re.compile(r"^(?:\*+\s*)?Erasure Summary(?:\s*\*+)?$")
_ERASURE_ROW = re.compile(
    r"^[! ]\s*([A-Za-z0-9._+-]+)\s*\|\s*([0-9]{1,20})\s*\|\s*([0-9]{1,20})\s*\|\s*(\S+)\s*$"
)
MAX_UINT64 = 2**64 - 1


@dataclass(frozen=True)
class CheckResult:
    id: str
    status: str
    summary: str
    detail: str
    provenance: dict[str, str]

    def payload(self) -> dict[str, Any]:
        if self.id not in CHECK_IDS or self.status not in STATUSES:
            raise ValueError("invalid check")
        return {
            "id": self.id,
            "status": self.status,
            "summary": self.summary,
            "detail": self.detail,
            "provenance": dict(self.provenance),
        }


def _names(device: str) -> frozenset[str]:
    base = os.path.basename((device or "").rstrip("/"))
    if not base:
        return frozenset()
    names = {base, f"/dev/{base}", device}
    # Summary tables use nwipe_strip_path's 8-column basename.
    if device.startswith("/"):
        from beamo_wipe.nwipe_runner import nwipe_status_device_field

        column = nwipe_status_device_field(device).strip()
        if column:
            names.add(column)
    return frozenset(name for name in names if name)


def _body(line: str) -> str:
    return _LEVEL.sub("", line.rstrip("\r\n"))


def _mentions(line: str, names: Iterable[str]) -> bool:
    text = line
    for name in names:
        if name and re.search(r"(?<![A-Za-z0-9._+/-])" + re.escape(name) + r"(?![A-Za-z0-9._+/-])", text):
            return True
    return False


def _matches_device(pattern: re.Pattern[str], line: str, names: frozenset[str]) -> bool:
    # The pinned nwipe status sentence starts the log body. Device-supplied
    # model/serial text can contain the same words later in a line.
    match = pattern.match(_body(line))
    return match is not None and match.group(1) in names


def _redact(line: str) -> str:
    text = " ".join(_body(line).split())
    return re.sub(r"/dev/[A-Za-z0-9._+-]+", "/dev/<disk>", text)[:240]


def _provenance(parser: str, line: str = "", source: str = "nwipe_log") -> dict[str, str]:
    data = {
        "source": source,
        "parser": parser,
        "engine": "nwipe",
        "engine_version": NWIPE_PINNED_VERSION,
        "engine_commit": NWIPE_PINNED_COMMIT,
    }
    if line:
        data["matched"] = _redact(line)
    return data


def _check(
    check_id: str,
    status: str,
    summary: str,
    detail: str,
    provenance: dict[str, str],
) -> CheckResult:
    result = CheckResult(check_id, status, summary, detail, provenance)
    result.payload()
    return result


def _target_lines(log_text: str, names: frozenset[str]) -> list[str]:
    out = []
    for raw in (log_text or "").split("\n"):
        if _mentions(raw, names):
            out.append(raw)
    return out


HIDDEN_UNAVAILABLE = "The hidden-storage check was not available. That is not a pass."
HIDDEN_NO_DEVICE = "No target device path was supplied."
HIDDEN_CONTRADICTORY = "Contradictory hidden-storage lines were present in the pinned nwipe v0.42 log."
HIDDEN_MAYBE = "This disk may have hidden storage the erase did not reach. Save the report and ask support."
HIDDEN_REPORTED = "Pinned nwipe v0.42 reported hidden or reduced host-visible capacity. Beamo does not expand hidden areas."
HIDDEN_INDETERMINATE = "Pinned nwipe v0.42 could not determine HPA/DCO status for this disk."
HIDDEN_NONE = "No hidden storage was reported for this disk."
HIDDEN_NONE_DETAIL = "Pinned nwipe v0.42 logged that no hidden sectors were found on the target."
HIDDEN_NO_RESULT = "The pinned nwipe v0.42 log did not contain a usable hidden-storage result for this disk."
IO_UNAVAILABLE = "Disk error counts were not available. That is not a pass."
IO_NOT_INCLUDED = "The pinned nwipe v0.42 Error Summary did not include this disk."
IO_ERRORS = "The disk reported write or read-back errors. Files may still be on the disk."
IO_ERROR_DETAIL = "Error Summary pass={p} verify={v} fsync={f} for the target."
IO_CLEAN = "No write or read-back errors were counted for this disk."
IO_CLEAN_DETAIL = "Error Summary listed zero pass, verification, and fdatasync errors for the target."
IO_FAILURE_MARK = "Pinned nwipe v0.42 logged a failure marker for the target."
COVERAGE_SUMMARY = "Overwrite reaches only storage the disk exposes. Hidden copies may remain."


def _parse_hidden_capacity(log_text: str, device: str) -> CheckResult:
    parser = f"{PARSER}.hidden_capacity"
    names = _names(device)
    if not names:
        return _check(
            "hidden_capacity",
            "unavailable",
            HIDDEN_UNAVAILABLE,
            HIDDEN_NO_DEVICE,
            _provenance(parser, source="missing"),
        )
    lines = _target_lines(log_text, names)
    detected = [line for line in lines if _matches_device(_HIDDEN_DETECTED, line, names)]
    none = [
        line for line in lines
        if _INFO_RECORD.match(line) and _matches_device(_HIDDEN_NONE, line, names)
    ]
    unknown = [
        line
        for line in lines
        if _matches_device(_HIDDEN_INDETERMINATE, line, names)
        or _matches_device(_HPA_LINE_UNKNOWN, line, names)
        or _SG_IO.search(_body(line))
        or _HDPARM_INVALID.search(_body(line))
    ]
    missing_tool = [
        line
        for line in (log_text or "").split("\n")
        if _HDPARM_MISSING.search(_body(line))
        or _HDPARM_STREAM.search(_body(line))
        or _HDPARM_FAILED.search(_body(line))
    ]
    from beamo_wipe.nwipe_runner import _status_column_is_shared

    # The Erasure Summary carries only eight characters of the disk name.
    # A second logged path with the same cell makes that table unassignable.
    erasure = (
        "invalid"
        if _status_column_is_shared(log_text, device)
        else _erasure_summary_state(log_text, names)
    )
    if sum(1 for flag in (bool(detected), bool(none), bool(unknown)) if flag) > 1:
        sample = (detected or none or unknown)[0]
        return _check(
            "hidden_capacity",
            "unavailable",
            HIDDEN_UNAVAILABLE,
            HIDDEN_CONTRADICTORY,
            _provenance(parser, sample),
        )
    if detected or erasure == "shortfall":
        sample = (detected[0] if detected else "")
        return _check(
            "hidden_capacity",
            "warning",
            HIDDEN_MAYBE,
            HIDDEN_REPORTED,
            _provenance(parser, sample or "Erasure Summary shortfall"),
        )
    if unknown or missing_tool:
        sample = (unknown or missing_tool)[0]
        return _check(
            "hidden_capacity",
            "unavailable",
            HIDDEN_UNAVAILABLE,
            HIDDEN_INDETERMINATE,
            _provenance(parser, sample),
        )
    if none and erasure in {"absent", "complete"}:
        return _check(
            "hidden_capacity",
            "pass",
            HIDDEN_NONE,
            HIDDEN_NONE_DETAIL,
            _provenance(parser, none[0]),
        )
    return _check(
        "hidden_capacity",
        "unavailable",
        HIDDEN_UNAVAILABLE,
        HIDDEN_NO_RESULT,
        _provenance(parser, source="missing" if not (log_text or "").strip() else "nwipe_log"),
    )


def _erasure_summary_state(log_text: str, names: frozenset[str]) -> str:
    """Classify the target's v0.42 summary without trusting a first row only."""
    in_table = False
    found: Optional[bool] = None
    for raw in (log_text or "").split("\n"):
        body = _body(raw)
        if _ERASURE_SUMMARY.fullmatch(body.strip()):
            in_table = True
            continue
        if in_table and body.startswith("***"):
            in_table = False
            continue
        if not in_table:
            continue
        match = _ERASURE_ROW.match(body)
        if not match:
            # A target row with invalid numbers or a missing percentage must
            # not be ignored while an earlier, apparently complete row passes.
            row_name = re.match(r"^[! ]\s*([A-Za-z0-9._+-]+)\s*\|", body)
            if row_name and row_name.group(1) in names:
                return "invalid"
            continue
        if match.group(1) not in names:
            continue
        erased, total = int(match.group(2)), int(match.group(3))
        percentage = re.fullmatch(r"(\d{1,3})\.(\d{2})%", match.group(4))
        if (
            found is not None
            or total <= 0
            or erased > total
            or erased > MAX_UINT64
            or total > MAX_UINT64
            or percentage is None
        ):
            return "invalid"
        hundredths = int(percentage.group(1)) * 100 + int(percentage.group(2))
        # The printed percentage is rounded to two decimal places by nwipe.
        # Compare in integer arithmetic so large byte counts cannot overflow.
        if abs(hundredths * total - erased * 10000) > total // 2:
            return "invalid"
        found = erased < total
    if found is None:
        return "absent"
    return "shortfall" if found else "complete"


def _parse_io_media(log_text: str, device: str) -> CheckResult:
    parser = f"{PARSER}.io_media"
    names = _names(device)
    if not names:
        return _check(
            "io_media",
            "unavailable",
            IO_UNAVAILABLE,
            HIDDEN_NO_DEVICE,
            _provenance(parser, source="missing"),
        )
    from beamo_wipe.nwipe_runner import (
        _line_reports_target_failure,
        _line_reports_target_verification_mismatch,
        _status_column_is_shared,
    )

    if _status_column_is_shared(log_text, device):
        explicit_failures = [
            line
            for line in (log_text or "").split("\n")
            if _line_reports_target_failure(line, device, shared=True)
            or _line_reports_target_verification_mismatch(line, device)
        ]
        if explicit_failures:
            return _check(
                "io_media", "fail", IO_ERRORS, IO_FAILURE_MARK,
                _provenance(parser, explicit_failures[0]),
            )
        return _check(
            "io_media", "unavailable", IO_UNAVAILABLE,
            "The nwipe status column is shared by another logged disk.",
            _provenance(parser, source="nwipe_log"),
        )
    fail_lines = [
        line
        for line in (log_text or "").split("\n")
        if _line_reports_target_failure(line, device, shared=False)
        or _line_reports_target_verification_mismatch(line, device)
    ]
    row = _error_summary_row(log_text, names)
    if row is None and not fail_lines:
        return _check(
            "io_media",
            "unavailable",
            IO_UNAVAILABLE,
            IO_NOT_INCLUDED,
            _provenance(
                parser,
                source="missing" if not (log_text or "").strip() else "nwipe_log",
            ),
        )
    if row is not None:
        pass_errors, verify_errors, fsync_errors = row
        if pass_errors or verify_errors or fsync_errors or fail_lines:
            return _check(
                "io_media",
                "fail",
                IO_ERRORS,
                IO_ERROR_DETAIL.format(
                    p=pass_errors, v=verify_errors, f=fsync_errors
                ),
                _provenance(parser, fail_lines[0] if fail_lines else "Error Summary"),
            )
        return _check(
            "io_media",
            "pass",
            IO_CLEAN,
            IO_CLEAN_DETAIL,
            _provenance(parser, "Error Summary"),
        )
    return _check(
        "io_media",
        "fail",
        IO_ERRORS,
        IO_FAILURE_MARK,
        _provenance(parser, fail_lines[0]),
    )


def _error_summary_row(
    log_text: str, names: frozenset[str]
) -> Optional[tuple[int, int, int]]:
    in_table = False
    malformed = False
    found = None
    trusted_table = False
    trusted_zero = False
    for raw in (log_text or "").split("\n"):
        body = _body(raw)
        if _ERROR_SUMMARY.fullmatch(body.strip()):
            in_table = True
            trusted_table = raw.rstrip("\r\n") == _ERROR_SUMMARY_HEADER
            continue
        if in_table and body.startswith("***"):
            in_table = False
            continue
        if not in_table:
            continue
        if "Device" in body and "Pass Errors" in body:
            continue
        if set(body) <= {"-", " "}:
            continue
        match = _ERROR_ROW.match(body)
        if not match:
            if body.strip():
                malformed = True
            continue
        if match.group(1) not in names:
            continue
        counts = (int(match.group(2)), int(match.group(3)), int(match.group(4)))
        if any(count > MAX_UINT64 for count in counts):
            malformed = True
            continue
        if found is not None and counts != found:
            malformed = True
        found = counts
        if trusted_table and not any(counts):
            trusted_zero = True
    if malformed:
        return None
    # The exact 80-character engine banner cannot fit inside a device model.
    # Keep conservative nonzero/error parsing, but do not bless a forged
    # short Error Summary followed by a zero row as a passing check.
    if found == (0, 0, 0) and not trusted_zero:
        return None
    return found


def _parse_coverage(disk: Optional[Disk]) -> CheckResult:
    kind = disk.kind if disk is not None else DiskKind.UNKNOWN
    text = notice(kind)
    return _check(
        "coverage",
        "warning",
        COVERAGE_SUMMARY,
        text,
        _provenance(f"{PARSER}.coverage", source="storage_limits"),
    )


def evaluate_engine_checks(
    log_text: str,
    device: str,
    disk: Optional[Disk] = None,
) -> list[CheckResult]:
    """Return the three structured checks. Order is stable."""
    checks = [
        _parse_hidden_capacity(log_text, device),
        _parse_io_media(log_text, device),
        _parse_coverage(disk),
    ]
    # nwipe terminates every record with LF. A missing final LF may cut a
    # zero error count or a hidden-storage result before contradictory text.
    # Keep warning/failure evidence, but never turn an incomplete log into a
    # passing report check, even if its current numeric prefix looks valid.
    if log_text and not log_text.endswith("\n"):
        checks = [
            _check(
                item.id, "unavailable",
                HIDDEN_UNAVAILABLE if item.id == "hidden_capacity" else IO_UNAVAILABLE,
                "The nwipe log ended before its final record was complete.",
                _provenance(item.provenance["parser"]),
            ) if item.status == "pass" else item
            for item in checks
        ]
    return checks


def check_payloads(
    log_text: str,
    device: str,
    disk: Optional[Disk] = None,
) -> list[dict[str, Any]]:
    return [item.payload() for item in evaluate_engine_checks(log_text, device, disk)]


def alert_summaries(checks: Iterable[dict[str, Any] | CheckResult]) -> tuple[str, ...]:
    """Concise UI lines. Coverage already appears at method selection."""
    alerts: list[str] = []
    seen: set[str] = set()
    for item in checks:
        payload = item.payload() if isinstance(item, CheckResult) else item
        if not isinstance(payload, dict):
            continue
        if payload.get("id") == "coverage":
            continue
        if payload.get("status") not in {"warning", "fail", "unavailable"}:
            continue
        summary = payload.get("summary")
        if not isinstance(summary, str) or not summary.strip() or summary in seen:
            continue
        seen.add(summary)
        alerts.append(summary.strip())
    return tuple(alerts)

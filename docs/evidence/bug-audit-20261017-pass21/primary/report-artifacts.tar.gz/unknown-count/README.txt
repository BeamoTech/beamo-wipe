The result could not be confirmed. Files may still be on the disk. Save the report if available and contact support. Shut down before disconnecting.
Beamo Wipe report
result.json, RESULT.txt, and REPORT.html are the original report. They include disk identifiers.
SHARE.json and SHARE.txt are a privacy-reduced sharing copy. They omit serials, hardware IDs, device paths, and engine logs. They are not identity evidence.
To share, copy only SHARE.json and SHARE.txt. Do not share result.json, RESULT.txt, REPORT.html, or engine logs.
nwipe log: complete (original report only).
COMPLETE authenticates these file contents only. It does not claim that the USB is safe to remove.
Support: beamosupport.com.
Check hidden_capacity: pass. No hidden storage was reported for this disk.
Check io_media: unavailable. Disk error counts were not available. That is not a pass.
Check coverage: warning. Overwrite reaches only storage the disk exposes. Hidden copies may remain.

# Beamo Wipe — boot card (print one side)

**Beamo Wipe** — this USB erases a disk with **nwipe** (open source).
You must own this PC and disk, or have written permission.

For the new desktop-readable USB image: open **Start Beamo Wipe.exe** on
Windows, or **Start Beamo Wipe Linux** on a supported Linux desktop.
On Windows, save your work, use the normal Restart command, then
choose this USB from the boot menu. On supported Linux desktops, the
application offers **Restart into Beamo Wipe** only when its checks pass;
an operating-system permission prompt may appear. If the application
cannot open, use the boot menu below.

**Erasing still requires booting this USB.** Inserting it or opening the
application does not erase anything. Open START-HERE.html on this USB to see
this image's build. Older sticks may use different startup files.

## Open the boot menu (typical keys)

| PC | Boot menu key |
| --- | --- |
| Dell | F12 |
| HP | F9 or Esc |
| Lenovo | F12 |
| ASUS | F8 or Esc |
| Acer | F12 |
| MSI | F11 |
| Gigabyte | F12 |

Windows 11 fallback: Settings → System → Recovery → Advanced startup →
Restart now → Use a device (UEFI).
Windows 10: Settings → Update & Security → Recovery → Advanced startup →
Restart now → Use a device (UEFI).
Those keys and menus vary by PC. Open START-HERE.html on the USB for the
full steps. If something is not working, choose the problem you see on
that page.

If you might start this Windows installation again, confirm you can reach
the BitLocker recovery key **before** changing firmware, boot order, or
Secure Boot. Those changes can trigger BitLocker recovery. Do not disable
Secure Boot as a routine step.

Plug into a **USB-A or USB-C** port on the PC, not a keyboard hub if you
can avoid it. Then restart and tap the key above.

**Not for Apple Silicon Macs. Not for Chromebooks.** Some Intel Macs may
show this USB; many will not.

## After it boots

When the Beamo Wipe menu appears, pick **Beamo Wipe: start the erase guide**
(or **troubleshoot startup** if the PC does not start normally). Opening the
guide erases nothing by itself.

The menu also offers **Beamo Wipe: speech for screen readers** — press **S**
as soon as the menu appears. UEFI computers with a built-in speaker play two
short beeps when the menu is showing; many laptops and the older BIOS menu
make no sound, so press **S** a few times after the firmware logo. The menu waits
five seconds, then starts the ordinary guide; if that happens, press **F8**
in the guide to switch to the spoken view. Choosing either entry erases
nothing.

1. Read the first screen. This is nwipe with a guide on top.
2. Check the owner box.
3. Pick the disk by **size and serial**. The Beamo USB is marked and
   cannot be selected.
4. Type the confirm number. Wait five seconds. Erase.

If the stick never appears: try another port, disable fast boot, or allow
USB boot in firmware.

If a diagnostic or wipe report cannot be saved, read the **Support code**
and **Build** lines on the screen and tell support those exact values.
They do not include disk serials or paths.

This image includes signed Debian EFI components. Secure Boot still depends
on the computer's trust settings and revocation updates. If firmware rejects
the USB, record its exact message and use the computer manufacturer's
guidance or contact support at **beamosupport.com**. Error
screens and START-HERE.html show the same address as text and as a phone
code. The application does not change Secure Boot settings. Older sticks
may contain a different boot image.

Source and license: **https://github.com/BeamoINT/beamo-wipe**
(print a QR to that README, not a store page).

# Amazon / pack copy (allowed language only)

Use this file as listing copy. Do not add claims that are not written here.

## Allowed title shape

Beamo Wipe — Bootable nwipe Drive Eraser USB for x64 PCs (UEFI & Legacy), Dual USB-A/C — Not for Apple Silicon

## Allowed bullets

- Guided screens on top of nwipe (open source). You pay for the flashed stick and the guide, not a secret algorithm.
- For x64 PCs that can boot from USB. You will use the PC’s boot menu (F12 / Esc / F9). Not Apple Silicon. Not Chromebooks.
- Choose the disk by size and serial. The Beamo USB cannot be selected.
- HDD overwrite via nwipe. SSD results depend on the drive’s controller. Not a Blancco-style certificate.
- No subscription. Reusable. No account.
- Source and license on GitHub and on the USB.

## Forbidden bullets

Do not write any of these:

- plug and play
- no technical skills
- any laptop / any computer / any Mac
- military certified / DoD certified / NSA / NIST compliant (as a badge)
- works on Mac (unless you only say Intel best-effort and Apple Silicon no)
- impossible to recover
- we invented this wipe technology
- Blancco replacement

## Honesty lines you may add

- This uses nwipe (open source). GPL-3.0-or-later for the wrapper; nwipe is GPL-2.0.
- There is no warranty.
- If the USB does not appear, you may need to allow USB boot in firmware settings.
- Secure Boot: this USB uses Debian's signed boot files. Whether a PC accepts
  them depends on its firmware trust settings and revocation updates. We do
  not ship circumvention tools. Older sticks may differ; read START-HERE.html
  on the USB you are holding.
- Overwrite is not a formal certificate. On an SSD the drive's controller decides
  what remains — see `docs/storage-and-controller-limits.md` for wear-leveling,
  hidden areas, encryption, RAID, and when to use the vendor's secure-erase
  tool or physical destruction instead.

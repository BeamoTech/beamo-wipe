# SPDX-License-Identifier: GPL-3.0-or-later
"""One bounded worker for optional audio I/O; UI threads poll tickets.

One latest interactive request and one outcome notification may wait. Outcome
notifications are not superseded by interactive discovery. A cancelled request is
cooperatively stopped by sound._run. A stuck third-party call can occupy the
single daemon, but cannot create more workers or hold the interface hostage.
"""

from __future__ import annotations

import atexit
import threading
import time
from typing import Callable


OPERATION_SECONDS = 30.0


class AudioTicket:
    def __init__(self, seconds: float = OPERATION_SECONDS, *, protected: bool = False):
        self.protected = protected
        self.cancelled = threading.Event()
        self.deadline = time.monotonic() + seconds
        self._lock = threading.Lock()
        self._done = False
        self._value = None
        self._completed_at: float | None = None
        self._expired = False

    def cancel(self) -> None:
        self.cancelled.set()

    def _finish(self, value) -> None:
        with self._lock:
            self._value = value
            self._completed_at = time.monotonic()
            self._done = True

    def poll(self):
        """(ready, value). Cancelled tickets are deliberately never applied."""
        if self.cancelled.is_set():
            return True, TimeoutError("Audio operation timed out") if self._expired else None
        with self._lock:
            if self._done and self._completed_at is not None and self._completed_at <= self.deadline:
                return True, self._value
            late = self._done
        if late or time.monotonic() >= self.deadline:
            self._expired = True
            self.cancel()
            return True, TimeoutError("Audio operation timed out")
        return False, None


class AudioWorker:
    def __init__(self):
        self._condition = threading.Condition()
        self._pending: tuple[AudioTicket, Callable] | None = None
        self._pending_outcome: tuple[AudioTicket, Callable] | None = None
        self._active: AudioTicket | None = None
        self._closed = False
        self._thread: threading.Thread | None = None

    def submit(self, action: Callable, seconds: float = OPERATION_SECONDS, *, protected: bool = False) -> AudioTicket:
        ticket = AudioTicket(seconds, protected=protected)
        with self._condition:
            if self._closed:
                ticket._finish(RuntimeError("Audio worker closed"))
                return ticket
            if protected:
                if self._pending_outcome is not None:
                    self._pending_outcome[0].cancel()
                self._pending_outcome = (ticket, action)
            else:
                if self._active is not None and not self._active.protected:
                    self._active.cancel()
                if self._pending is not None:
                    self._pending[0].cancel()
                self._pending = (ticket, action)
            if self._thread is None:
                launch_decided = threading.Event()
                launch_allowed = threading.Event()

                def accepted_worker() -> None:
                    # start() can raise after its OS thread exists. A rejected
                    # worker must never consume a later launch's queue or
                    # retire that launch's thread reference.
                    launch_decided.wait()
                    if launch_allowed.is_set():
                        self._run()

                try:
                    self._thread = threading.Thread(
                        target=accepted_worker, name="beamo-audio", daemon=True
                    )
                    self._thread.start()
                    launch_allowed.set()
                except BaseException as exc:
                    # An interrupted set() may have published acceptance
                    # before raising. Revoke it before waking the target.
                    launch_allowed.clear()
                    if protected:
                        self._pending_outcome = None
                    else:
                        self._pending = None
                    self._thread = None
                    if not isinstance(exc, RuntimeError):
                        ticket.cancel()
                        raise
                    ticket._finish(exc)
                    return ticket
                finally:
                    launch_decided.set()
            self._condition.notify()
        return ticket

    def _run(self) -> None:
        from beamo_wipe import sound

        while True:
            with self._condition:
                while self._pending is None and self._pending_outcome is None and not self._closed:
                    self._condition.wait(timeout=1.0)
                    # A submitter can acquire the lock after the timeout but
                    # before this waiter reacquires it. Recheck the queues;
                    # wait()'s return value alone cannot decide to retire.
                    if self._pending is None and self._pending_outcome is None and not self._closed:
                        self._thread = None
                        return
                if self._closed:
                    return
                if self._pending_outcome is not None:
                    ticket, action = self._pending_outcome
                    self._pending_outcome = None
                elif self._pending is not None:
                    ticket, action = self._pending
                    self._pending = None
                else:
                    continue
                self._active = ticket
            try:
                if ticket.cancelled.is_set():
                    value = None
                else:
                    sound._audio_context.ticket = ticket
                    try:
                        value = action()
                    finally:
                        del sound._audio_context.ticket
            except BaseException as exc:
                value = exc
            ticket._finish(value)
            with self._condition:
                if self._active is ticket:
                    self._active = None

    def close(self) -> None:
        with self._condition:
            self._closed = True
            if self._active is not None:
                self._active.cancel()
            if self._pending is not None:
                self._pending[0].cancel()
                self._pending = None
            if self._pending_outcome is not None:
                self._pending_outcome[0].cancel()
                self._pending_outcome = None
            self._condition.notify_all()
            thread = self._thread
        if thread is not None:
            thread.join(timeout=0.6)


worker = AudioWorker()
atexit.register(worker.close)

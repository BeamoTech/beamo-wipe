#!/bin/sh
printf "%s\n" "$0" >> /tmp/pass16-primary/forbidden-fallback-attempts.txt
printf "Blocked unmocked external or privileged fixture fallback\n" >&2
exit 97

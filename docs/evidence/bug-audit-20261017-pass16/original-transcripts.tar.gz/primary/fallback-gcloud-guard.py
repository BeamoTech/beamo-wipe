#!/tmp/beamo-pass16-python/bin/python3
"""Allow the exact offline file-list fixture; reject every remote operation."""
import json
import os
from pathlib import Path
import stat
import sys

args=sys.argv[1:]
allowed=False
if len(args)==3 and args[:2]==['meta','list-files-for-upload']:
    upload=Path(args[2])
    config=Path(os.environ.get('CLOUDSDK_CONFIG','/not-a-fixture'))
    canonical=upload.resolve()
    parent=canonical.parent
    try:
        parent_stat=parent.stat()
        allowed=(upload.is_absolute() and upload==canonical
                 and canonical.is_relative_to(Path('/tmp/pytest-of-root').resolve())
                 and upload.name=='upload' and upload.is_dir()
                 and parent_stat.st_uid==os.getuid() and stat.S_IMODE(parent_stat.st_mode)&0o077==0
                 and config==parent/'gcloud-config' and not os.path.lexists(config)
                 and (upload/'.gcloudignore').is_file() and not (upload/'.gcloudignore').is_symlink()
                 and upload.stat().st_uid==os.getuid())
    except OSError:
        allowed=False
if allowed:
    with Path('/tmp/pass16-primary/permitted-offline-gcloud.jsonl').open('a') as log:
        log.write(json.dumps(dict(command=args,test=os.environ.get('PYTEST_CURRENT_TEST','')))+'\n')
    os.environ.update(CLOUDSDK_COMPONENT_MANAGER_DISABLE_UPDATE_CHECK='true',
                      CLOUDSDK_CORE_DISABLE_USAGE_REPORTING='true',
                      CLOUDSDK_CORE_DISABLE_PROMPTS='true',
                      CLOUDSDK_AUTH_DISABLE_CREDENTIALS='true',
                      CLOUDSDK_PYTHON='/tmp/beamo-pass16-python/bin/python3')
    for name in ('GOOGLE_APPLICATION_CREDENTIALS','CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE',
                 'CLOUDSDK_AUTH_ACCESS_TOKEN','CLOUDSDK_AUTH_IMPERSONATE_SERVICE_ACCOUNT'):
        os.environ.pop(name,None)
    os.execv('/usr/bin/gcloud',['/usr/bin/gcloud',*args])
with Path('/tmp/pass16-primary/forbidden-fallback-attempts.txt').open('a') as log:
    log.write('gcloud remote or non-fixture operation blocked\n')
raise SystemExit(97)

# SPDX-License-Identifier: GPL-3.0-or-later
"""Plain data types. No I/O."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Tuple


class DiskKind(str, Enum):
    HDD = "HDD"
    SSD = "SSD"
    NVME = "NVMe"
    UNKNOWN = "Unknown"


CONTENTS_WINDOWS = "windows"
CONTENTS_SYSTEM = "system"
CONTENTS_DATA = "data"
CONTENTS_UNKNOWN = "unknown"
CONTENTS_VALUES = frozenset(
    {CONTENTS_WINDOWS, CONTENTS_SYSTEM, CONTENTS_DATA, CONTENTS_UNKNOWN}
)


def capacity_phrase(size_gb_label: str) -> str:
    """Familiar decimal GB/TB from the confirm-token GB label.

    TB is used only when the GB count is an exact tenth or whole TB, so two
    nearby sizes never share a rounded TB name. The integer GB stays visible.
    """
    raw = (size_gb_label or "").strip()
    if not raw.isdigit():
        return "Capacity unknown"
    gb = int(raw)
    if gb <= 0:
        return "0 GB"
    if gb >= 1000 and gb % 1000 == 0:
        return f"{gb // 1000} TB ({gb} GB)"
    if gb >= 1000 and gb % 100 == 0:
        tenths = gb // 100
        whole, frac = divmod(tenths, 10)
        return f"{whole}.{frac} TB ({gb} GB)"
    return f"{gb} GB"


class MethodId(str, Enum):
    EVERYDAY = "everyday"
    EXTRA = "extra"
    QUICK_ZERO = "quick_zero"


class Screen(str, Enum):
    SPLASH = "splash"
    KEYBOARD = "keyboard"
    WHAT = "what"
    OWNER = "owner"
    PICK = "pick"
    DISK_HELP = "disk_help"
    PICK_BLOCKED = "pick_blocked"
    PICK_EMPTY = "pick_empty"
    CONFIRM = "confirm"
    METHOD = "method"
    LAST_CHANCE = "last_chance"
    CHECKING = "checking"
    STOPPING = "stopping"
    WORKING = "working"
    DONE = "done"
    ADVANCED = "advanced"
    REPORT_HELP = "report_help"
    SHUTDOWN_CONFIRM = "shutdown_confirm"
    LIMITS = "limits"
    REFRESHING = "refreshing"
    REFRESH_CONFIRM = "refresh_confirm"
    DIAGNOSTIC = "diagnostic"


UNKNOWN_MODEL = "Unknown model"


@dataclass(frozen=True)
class Disk:
    path: str
    name: str
    model: str
    serial: str
    size_bytes: int
    size_gb_label: str
    kind: DiskKind
    bus: str
    label: str
    is_boot: bool = False
    read_only: bool = False
    wwn: str = ""
    vendor: str = ""
    mountpoints: Tuple[str, ...] = ()
    # ``model`` is presentation text and may fall back to a volume label or
    # "Unknown model".  None means a caller did not provide raw identity
    # metadata; discovery always sets this to the exact cleaned lsblk MODEL,
    # including an empty string when MODEL is absent.
    raw_model: Optional[str] = None
    # Proven from lsblk partitions only: windows, system, data, or unknown.
    contents: str = CONTENTS_UNKNOWN
    # Observed lsblk RM or HOTPLUG. SATA/NVMe with this set may be a USB
    # enclosure; presentation must not guess internal vs external location.
    hotplug: bool = False
    # Hash of partition and whole-disk filesystem identity. Empty when none
    # was recorded. Rediscovery uses it to catch a blank disk that was swapped.
    layout_id: str = ""

    @property
    def display_name(self) -> str:
        # Kernel names are not stable identity. Unknown stays unknown.
        return (self.model or "").strip() or (self.label or "").strip() or UNKNOWN_MODEL

    @property
    def size_phrase(self) -> str:
        # A positive disk that half-up rounds to 0 GB is not empty and is
        # not 1 GB. Zero-byte disks stay "0 GB".
        if self.size_bytes > 0 and (self.size_gb_label or "").strip() == "0":
            return "under 1 GB"
        return capacity_phrase(self.size_gb_label)


@dataclass(frozen=True)
class ConfirmSpec:
    token: str
    prompt: str
    identity_field: str = "size"


@dataclass(frozen=True)
class WipeRequest:
    device: str
    method: MethodId
    boot_device: str
    logfile: str
    # Linux st_rdev of the target at confirm time. 0 when the node is absent
    # (unit tests / dry-run). Re-checked immediately before exec.
    device_rdev: int = 0
    device_size_bytes: int = 0
    # Boot-medium identity recorded at the confirmation boundary. Production
    # rechecks it immediately before exec so a hotplug/rename cannot redirect
    # --exclude to a different node.
    boot_rdev: int = 0
    # disk_identity() at confirmation. The device number of /dev/sdX does not
    # change when a different disk reuses that name, so exec rechecks this.
    device_identity: tuple = ()
    # The same hotplug/path-reuse check also applies to the boot medium before
    # nwipe receives --exclude for its /dev path.
    boot_identity: tuple = ()


@dataclass(frozen=True)
class WipeResult:
    ok: bool
    exit_code: Optional[int]
    summary: str
    logfile: str
    reason: str = ""


@dataclass
class DiscoveryResult:
    disks: Tuple[Disk, ...] = field(default_factory=tuple)
    selectable: Tuple[Disk, ...] = field(default_factory=tuple)
    boot: Optional[Disk] = None
    error: Optional[str] = None
    boot_identified: bool = False
    # Legacy local troubleshooting detail, excluded from startup reports.
    # UI shows `error`; startup support exports only the allowlisted error_code.
    diagnostic: Optional[str] = None
    # Display-only inventory. Never a source of selectable Disk objects.
    excluded: Tuple[ExcludedDevice, ...] = ()
    error_code: str = ""


@dataclass(frozen=True)
class ExcludedDevice:
    identity: str
    reasons: Tuple[str, ...]
    path: str = ""
    # Display-only nesting. Empty parent_path means no known physical parent;
    # callers must not invent one from kernel names.
    parent_path: str = ""
    kind_label: str = ""
    summary: str = ""
    children: Tuple["ExcludedDevice", ...] = ()

    @property
    def explanation(self) -> str:
        return f"{self.identity}\nCannot erase: {'; '.join(self.reasons)}."

# SPDX-License-Identifier: GPL-3.0-or-later
"""Build and run nwipe. Never autonuke without a single explicit device."""

from __future__ import annotations

import fcntl
import errno
import math
import os
import re
import signal
import stat
import subprocess
import threading
import time
from typing import Any, List, Optional

from beamo_wipe import NWIPE_PINNED_PATH, NWIPE_PINNED_VERSION
from beamo_wipe.methods import (
    ALLOWED_NWIPE_METHODS,
    ALLOWED_ROUNDS,
    ALLOWED_VERIFY,
    METHODS,
    NwipeMethodSpec,
)
from beamo_wipe.models import WipeRequest, WipeResult
from beamo_wipe.progress import Observation
from beamo_wipe.sleep_inhibit import SleepInhibit
from beamo_wipe.safety import (
    CLEAN_SUBPROCESS_ENV,
    SafetyError,
    assert_existing_is_block_device,
    assert_log_not_on_target,
    assert_local_device_transport,
    assert_not_boot,
    assert_rediscovered_identity,
    assert_size_unchanged,
    block_rdev,
    normalize_whole_disk,
    require_real_live_for_nwipe,
    truncate_log_file,
)

PERCENT_RE = re.compile(r"(?<!\d)(\d{1,3}(?:\.\d+)?)\s*%")
# nwipe 0.42 SIGUSR1: "/dev/vda: 045.23%, round 1 of 1, pass 1 of 1, eta …"
# Groups: percent, round i, round n, optional pass i, optional pass n.
NWIPE_PROGRESS_RE = re.compile(
    r"^\s*(?:(?:\[[^\]\r\n]*\]\s*)?"
    r"(?:debug|info|notice|warning|error|fatal|sanity):\s*)?"
    r"(/dev/[A-Za-z0-9._+-]+)"
    r":\s*(\d{1,3}(?:\.\d+)?)\s*%,\s*round\s+(\d{1,6})\s+of\s+(\d{1,6})"
    r"(?:,\s*pass\s+(\d{1,6})\s+of\s+(\d{1,6}))?"
    # Do not backtrack a malformed/truncated pass clause into an absent one,
    # or accept a numeric prefix of a malformed counter as completion proof.
    r"(?=\s*(?:,\s*eta\b|$))"
)
# nwipe 0.42's final read-back sample has one phase field after its ETA.
# A stray later "[verifying]" in a malformed line is not completion proof.
NWIPE_VERIFY_SUFFIX_RE = re.compile(
    r"\s*,\s*eta\s+\d{2,6}:[0-5]\d:[0-5]\d,\s*<?\[verifying\]>?\s*", re.I
)
NWIPE_WRITE_SUFFIX_RE = re.compile(
    r"\s*,\s*eta\s+\d{2,6}:[0-5]\d:[0-5]\d,\s*<?\[writing\]>?\s*", re.I
)
NWIPE_METHOD_COUNTER_SUFFIX_RE = re.compile(
    r"\s*,\s*eta\s+\d{2,6}:[0-5]\d:[0-5]\d,\s*<?"
    r"\[(?:writing|verifying|blanking|syncing|retrying)\]>?\s*", re.I
)
# nwipe 0.42 (device.c / nwipe.c) when the target is mounted and --force is unset.
NWIPE_BUSY_RE = re.compile(
    r"(?:is reported as IN USE|is IN USE but --force is not set, not wiping it)"
)
NWIPE_BUSY_TARGET_RE = re.compile(
    r"^(/dev/[A-Za-z0-9._+-]+) is "
    r"(?:reported as IN USE\b|IN USE but --force is not set, not wiping it\b)"
)
NWIPE_ABORT_RE = re.compile(r"Nwipe was aborted by the user")
NWIPE_ABORT_LINE_RE = re.compile(r"^Nwipe was aborted by the user\b")
# Wipe-time open (nwipe.c). device.c also logs
# "Unable to open device %s to obtain serial number" and continues.
NWIPE_OPEN_FAIL_RE = re.compile(r"Unable to open device '[^']+'\.")
NWIPE_OPEN_TARGET_RE = re.compile(
    r"^Unable to open device '(/dev/[A-Za-z0-9._+-]+)'\."
)
# Drive Status column is exactly 8 chars between pipes (logging.c).
NWIPE_FAILURE_RE = re.compile(
    r"(?:>>> FAILURE! <<<|\|-FAILED-\||\|UABORTED\||\|INSANITY\|)"
)
NWIPE_LOG_PREFIX_RE = re.compile(
    r"^\s*(?:\[[^\]\r\n]*\]\s*)?"
    r"(?:(?:debug|info|notice|warning|error|fatal|sanity):\s*)?",
    re.I,
)
NWIPE_DIRECT_FAILURE_RE = re.compile(
    r"^(/dev/[A-Za-z0-9._+-]+):\s*>>> FAILURE! <<<"
)
NWIPE_PIPE_FAILURE_RE = re.compile(
    r"^\|(/dev/[A-Za-z0-9._+-]+)\|[^|]*\|\s*"
    r"(?:-FAILED-|UABORTED|INSANITY)\s*\|"
)
NWIPE_VERIFY_MISMATCH_RE = re.compile(
    r"^Verification mismatch on ['\"]?(/dev/[A-Za-z0-9._+-]+)"
)
NWIPE_POSSIBLE_ERASURE_STATUS_RE = re.compile(
    r"(?:\|\s*Erased\s*\||\|-FAILED-\||\|UABORTED\|)"
)
NWIPE_ERROR_ROW_RE = re.compile(
    r"^\s*!?\s*([A-Za-z0-9._+-]+)\s*\|\s*(\d{1,20})\s*\|\s*(\d{1,20})\s*\|\s*(\d{1,20})\s*$"
)
NWIPE_ERROR_SUMMARY_HEADER_RE = re.compile(
    r"^(?:\*+\s*)?Error Summary(?:\s*\*+)?$"
)
# Exact nwipe 0.42 logging.c banner: device models cannot supply this line
# (ATA IDENTIFY is 40 bytes, status-table model is truncated to 17 bytes).
NWIPE_DRIVE_STATUS_HEADER = (
    "********************************* Drive Status "
    "*********************************"
)
NWIPE_GEOMETRY_RE = re.compile(r"No sane device geometry")
NWIPE_GEOMETRY_TARGET_RE = re.compile(
    r"^(?:No sane device geometry for ['\"]?(/dev/[A-Za-z0-9._+-]+)"
    r"|(/dev/[A-Za-z0-9._+-]+): No sane device geometry)"
)
# Logged by nwipe_options_log() after pthread_sigmask(SIGUSR1) and the
# signal-handler thread exist. Until then SIGUSR1 uses the default action
# (terminate). The PRNG auto-bench (8 generators × 1.0s) runs before that.
NWIPE_SIGUSR1_READY_RE = re.compile(
    r"^\[\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}\]\s+"
    r"(?:debug|info|notice|sanity):\s*"
    r"(?:Program options are set as follows\b|do not show GUI interface\b|"
    r"Using direct I/O\b|Using cached I/O\b)"
)
NWIPE_VERSION_TIMEOUT_S = 5
# Drive Status is written before create_system_multi_disc_pdf()/smartctl.
# 64KiB from EOF can be only that tail, hiding | Erased |.
NWIPE_COMPLETION_LOG_BYTES = 1024 * 1024
NWIPE_PROGRESS_LOG_BYTES = 8000
# Completion can be larger than the displayed/exported tail. Stream it and
# retain only parser-relevant lines; an oversized individual line or too much
# relevant evidence is indeterminate rather than a partial success.
NWIPE_COMPLETION_SCAN_LINE_BYTES = 64 * 1024
NWIPE_COMPLETION_EVIDENCE_BYTES = 1024 * 1024
NWIPE_CLEAN_ENV = dict(CLEAN_SUBPROCESS_ENV)
# nwipe 0.42 `nwipe -V` prints this line (src/nwipe.c). Substring "0.42"
# would also match 0.420 / 10.42 / a binary that mentions the pin in help.
NWIPE_VERSION_LINE_RE = re.compile(
    rf"(?im)^nwipe version {re.escape(NWIPE_PINNED_VERSION)}(?:\s|$)"
)


class ProcessStatusError(SafetyError):
    """Polling failed; cancellation can still confirm exit through wait()."""


def resolve_nwipe_binary(binary: str) -> str:
    """Production always execs the pinned path. Relative PATH lookup is forbidden."""
    if not binary:
        raise SafetyError("nwipe binary path is missing.")
    base = os.path.basename(binary)
    if base != "nwipe":
        # Hardened: only the `nwipe` basename is ever exec'd in production
        # (prevents /tmp/evil). For local pytest, allow any absolute fake
        # when BEAMO_WIPE_DRY_RUN is set — never on the live USB where
        # BEAMO_WIPE_LIVE=1 and BEAMO_WIPE_DRY_RUN is unset.
        if os.environ.get("BEAMO_WIPE_DRY_RUN") == "1":
            if not os.path.isabs(binary):
                raise SafetyError("Refusing to exec a relative non-nwipe binary.")
            return binary
        raise SafetyError("Refusing to exec a non-nwipe binary.")
    if binary in {"nwipe", NWIPE_PINNED_PATH}:
        return NWIPE_PINNED_PATH
    # Any other absolute path named `nwipe` is not the pinned path
    # — fail-closed (prevents /usr/local/bin/nwipe shadow). Test fakes
    # for nwipe must use the non-nwipe dry-run path above.
    raise SafetyError("nwipe is not at the pinned path.")


def nwipe_version_is_pinned(text: str) -> bool:
    """True only for the pinned `nwipe version X.Y` line, not a substring."""
    return bool(NWIPE_VERSION_LINE_RE.search(text or ""))


def _verify_pinned_nwipe(binary: str) -> None:
    if os.path.basename(binary) != "nwipe":
        return
    assert_nwipe_binary_safe(binary)
    try:
        proc = subprocess.run(
            [binary, "-V"],
            check=False,
            capture_output=True,
            text=True,
            timeout=NWIPE_VERSION_TIMEOUT_S,
            shell=False,
            env=NWIPE_CLEAN_ENV,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SafetyError("Cannot verify the nwipe binary.") from exc
    blob = f"{proc.stdout or ''}{proc.stderr or ''}"
    if proc.returncode != 0 or not nwipe_version_is_pinned(blob):
        raise SafetyError(
            f"Refusing to exec nwipe; pinned version is {NWIPE_PINNED_VERSION}."
        )


def assert_nwipe_binary_safe(path: str) -> None:
    """Pinned engine must be a root-owned ELF, not a script or a writable stub."""
    try:
        st = os.lstat(path)
    except OSError as exc:
        raise SafetyError("Cannot stat nwipe binary.") from exc
    if stat.S_ISLNK(st.st_mode):
        raise SafetyError("Refusing to exec nwipe through a symlink.")
    if not stat.S_ISREG(st.st_mode):
        raise SafetyError("nwipe is not a regular file.")
    if not (st.st_mode & stat.S_IXUSR):
        raise SafetyError("nwipe is not executable.")
    if stat.S_IMODE(st.st_mode) & 0o022:
        raise SafetyError("nwipe binary is writable by group or others.")
    if st.st_mode & (stat.S_ISUID | stat.S_ISGID):
        raise SafetyError("nwipe binary must not be setuid or setgid.")
    if os.geteuid() == 0 and st.st_uid != 0:
        raise SafetyError("nwipe binary must be owned by root.")
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError as exc:
        raise SafetyError("Cannot open nwipe binary.") from exc
    try:
        # Re-validate after open to close TOCTOU: the fd must still be the
        # same regular file we just lstat'd, not a swapped inode.
        try:
            fst = os.fstat(fd)
        except OSError as exc:
            raise SafetyError("Cannot stat nwipe binary.") from exc
        if stat.S_ISLNK(fst.st_mode) or not stat.S_ISREG(fst.st_mode):
            raise SafetyError("nwipe is not a regular file.")
        if fst.st_ino != st.st_ino or fst.st_dev != st.st_dev:
            raise SafetyError("nwipe binary changed during check.")
        if stat.S_IMODE(fst.st_mode) & 0o022:
            raise SafetyError("nwipe binary is writable by group or others.")
        if fst.st_mode & (stat.S_ISUID | stat.S_ISGID):
            raise SafetyError("nwipe binary must not be setuid or setgid.")
        magic = os.read(fd, 4)
    finally:
        os.close(fd)
    if magic != b"\x7fELF":
        raise SafetyError("nwipe binary is not an ELF executable.")


def _try_log_diag(area: str, code: str, detail: str = "") -> None:
    """Best-effort diagnostic emit that also falls back to stderr on failure.

    Never raises, never logs secrets. Ensures swallowed log_diag failures
    become visible to maintainers via stderr when the diagnostics file cannot
    be written.
    """
    try:
        from beamo_wipe.diagnostics import log_diag

        log_diag(area, code, detail)
    except Exception:
        # Fallback to stderr for visibility when diagnostics itself fails.
        try:
            import sys

            # sanitize detail already truncated; avoid leaking full device paths
            safe = detail[:120].replace("\n", " ") if detail else code
            print(f"beamo-wipe [{area}] {code}: {safe}", file=sys.stderr)
        except Exception:
            pass


def pinned_nwipe_already_running(*, exclude_pid: Optional[int] = None) -> bool:
    """True if another process is already exec'ing the pinned engine.

    Permission failures and top-level /proc failures are treated as
    "possibly running". Vanished processes and kernel threads without an
    executable are ignored after emitting a bounded diagnostic.
    """
    try:
        pinned = os.path.realpath(NWIPE_PINNED_PATH)
    except OSError as exc:
        _try_log_diag("nwipe", "already_running_realpath_failed", type(exc).__name__)
        return True
    try:
        names = os.listdir("/proc")
    except OSError as exc:
        _try_log_diag("nwipe", "proc_list_failed", type(exc).__name__)
        return True
    try:
        pinned_stat = os.stat(NWIPE_PINNED_PATH)
    except FileNotFoundError:
        # An old engine may still be executing through a hard link after the
        # installed path was removed. Its inode cannot be compared with the
        # missing pathname; absence of a concurrent erase is unprovable.
        _try_log_diag("nwipe", "already_running_pinned_missing")
        return True
    except OSError as exc:
        _try_log_diag("nwipe", "already_running_stat_failed", type(exc).__name__)
        return True
    unreadable = 0
    for name in names:
        if not name.isdigit():
            continue
        pid = int(name)
        if exclude_pid is not None and pid == exclude_pid:
            continue
        try:
            exe_link = os.readlink(f"/proc/{name}/exe")
            # procfs marks an unlinked executable with this suffix. It may
            # still be running after a package update and must remain a hit.
            if exe_link.endswith(" (deleted)"):
                exe_link = exe_link[: -len(" (deleted)")]
            exe = os.path.realpath(exe_link)
        except OSError as exc:
            # Processes can exit between listdir and readlink; kernel threads
            # may not expose exe. Those expected races do not prove nwipe is
            # running, but remain visible as a bounded diagnostic.
            if exc.errno in {errno.ENOENT, errno.ESRCH}:
                unreadable += 1
                continue
            code = (
                "proc_exe_permission_denied"
                if exc.errno in {errno.EACCES, errno.EPERM}
                else "proc_exe_check_failed"
            )
            _try_log_diag("nwipe", code, f"pid={pid}")
            return True
        if exe == pinned:
            return True
        try:
            # /proc/PID/exe refers to the executing inode even when its
            # launch path was a hard link that has since been removed.
            running_stat = os.stat(f"/proc/{name}/exe")
        except OSError as exc:
            if exc.errno in {errno.ENOENT, errno.ESRCH}:
                continue
            _try_log_diag("nwipe", "proc_exe_stat_failed", f"pid={pid}")
            return True
        if (running_stat.st_dev, running_stat.st_ino) == (
            pinned_stat.st_dev, pinned_stat.st_ino
        ):
            return True
    if unreadable:
        _try_log_diag("nwipe", "proc_exe_unreadable", f"count={unreadable}")
        # If many entries unreadable we already fail-closed above for list
        # failures; single unreadable entries are not treated as running
        # but are now visible for triage.
    return False


def _recheck_identity_under_lock(request: WipeRequest) -> None:
    """Read the bus again immediately before exec. A failed read is a refusal."""
    from beamo_wipe.discover import discover

    try:
        fresh = discover()
    except Exception as exc:
        raise SafetyError("Disk identity changed. Refusing to erase.") from exc
    assert_rediscovered_identity(request, fresh)


def build_nwipe_argv(request: WipeRequest) -> List[str]:
    try:
        spec: NwipeMethodSpec = METHODS[request.method]
    except KeyError as exc:
        raise SafetyError("Unknown wipe method.") from exc
    if spec.nwipe_method not in ALLOWED_NWIPE_METHODS:
        raise SafetyError("nwipe method is not in the allowlist.")
    if spec.verify not in ALLOWED_VERIFY:
        raise SafetyError("nwipe verify flag is not in the allowlist.")
    if spec.rounds not in ALLOWED_ROUNDS:
        raise SafetyError("nwipe rounds value is not allowed.")
    device = normalize_whole_disk(request.device, allow_optical=False)
    boot = normalize_whole_disk(request.boot_device, allow_optical=True)
    if device == boot:
        raise SafetyError("Target is the boot device.")
    assert_not_boot(device, boot)
    assert_log_not_on_target(request.logfile, device)
    argv = [
        "nwipe",
        "--autonuke",
        "--nogui",
        "--nowait",
        "--quiet",
        f"--method={spec.nwipe_method}",
        f"--verify={spec.verify}",
        f"--rounds={str(int(spec.rounds))}",
        f"--logfile={request.logfile}",
        "--PDFreportpath=noPDF",
        f"--exclude={boot}",
    ]
    if spec.noblank:
        argv.append("--noblank")
    argv.append(device)
    validate_argv(argv, request)
    return argv


def validate_argv(argv: List[str], request: WipeRequest) -> None:
    if not argv or argv[0] != "nwipe":
        raise SafetyError("First argument must be nwipe.")
    try:
        spec: NwipeMethodSpec = METHODS[request.method]
    except KeyError as exc:
        raise SafetyError("Unknown wipe method.") from exc
    # Bind flags to the confirmed method: an allowlist alone would accept a
    # stronger/weaker method than the owner confirmed (e.g. zero/off on EVERYDAY).
    expected = {
        f"--method={spec.nwipe_method}",
        f"--verify={spec.verify}",
        f"--rounds={int(spec.rounds)}",
    }
    for want in sorted(expected):
        if argv.count(want) != 1:
            raise SafetyError(
                f"nwipe flags do not match the confirmed method ({want} required)."
            )
    if spec.noblank != ("--noblank" in argv):
        raise SafetyError(
            "nwipe flags do not match the confirmed method (--noblank mismatch)."
        )
    if any(a == "--force" or a.startswith("--force=") for a in argv):
        raise SafetyError("Refusing to pass --force to nwipe.")
    if "--autonuke" not in argv or "--nogui" not in argv:
        raise SafetyError("Non-interactive nwipe flags required.")
    for required in (
        "--autonuke",
        "--nogui",
        "--nowait",
        "--quiet",
        "--PDFreportpath=noPDF",
    ):
        if argv.count(required) != 1:
            raise SafetyError(f"Exactly one {required} flag is required.")
    for prefix in ("--method=", "--verify=", "--rounds=", "--logfile=", "--exclude="):
        hits = [a for a in argv if a.startswith(prefix)]
        if len(hits) != 1:
            raise SafetyError(f"Exactly one {prefix} flag is required.")
    if argv.count("--noblank") > 1:
        raise SafetyError("Refusing duplicate --noblank flags.")
    device = normalize_whole_disk(request.device, allow_optical=False)
    boot = normalize_whole_disk(request.boot_device, allow_optical=True)
    if argv[-1] != device:
        raise SafetyError("Target device must be the only positional path, last.")
    extra_positionals = [a for a in argv[1:-1] if not a.startswith("-")]
    if extra_positionals:
        raise SafetyError("Refusing extra positional arguments.")
    for flag in argv[1:-1]:
        if not _nwipe_flag_allowed(flag):
            raise SafetyError("Refusing unexpected nwipe argument.")
    devices = [a for a in argv if a.startswith("/dev/")]
    if device not in devices:
        raise SafetyError("Target device missing from argv.")
    extra = [d for d in devices if d != device]
    if extra:
        raise SafetyError("Refusing to pass more than one target device.")
    exclude = f"--exclude={boot}"
    if exclude not in argv:
        raise SafetyError("Boot device must be excluded.")
    logfile_flags = [a for a in argv if a.startswith("--logfile=")]
    if len(logfile_flags) != 1:
        raise SafetyError("Exactly one --logfile= flag is required.")
    log_value = logfile_flags[0].split("=", 1)[1]
    if log_value.startswith("/dev/") or log_value != request.logfile:
        raise SafetyError("Log path is not the approved log file.")
    assert_log_not_on_target(log_value, device)
    if "--PDFreportpath=noPDF" not in argv:
        raise SafetyError("PDF reports must be disabled.")
    if "--autonuke" in argv and argv[-1].startswith("-"):
        raise SafetyError("autonuke without an explicit device is forbidden.")
    if any("\n" in a or "\r" in a or "\0" in a for a in argv):
        raise SafetyError("Refusing control characters in nwipe arguments.")


def _nwipe_flag_allowed(flag: str) -> bool:
    if flag in {"--autonuke", "--nogui", "--nowait", "--quiet", "--noblank"}:
        return True
    if flag == "--PDFreportpath=noPDF":
        return True
    if flag.startswith("--method="):
        return flag.split("=", 1)[1] in ALLOWED_NWIPE_METHODS
    if flag.startswith("--verify="):
        return flag.split("=", 1)[1] in ALLOWED_VERIFY
    if flag.startswith("--rounds="):
        try:
            return int(flag.split("=", 1)[1], 10) in ALLOWED_ROUNDS
        except ValueError:
            return False
    if flag.startswith("--logfile="):
        return bool(flag.split("=", 1)[1]) and not flag.split("=", 1)[1].startswith("-")
    if flag.startswith("--exclude="):
        rest = flag.split("=", 1)[1]
        if not rest or any(ch in rest for ch in " \t\n\r\0,;"):
            return False
        try:
            normalize_whole_disk(rest, allow_optical=True)
        except SafetyError:
            return False
        return True
    return False


def parse_percent(text: str) -> Optional[float]:
    last = None
    for match in PERCENT_RE.finditer(text or ""):
        value = float(match.group(1))
        if 0.0 <= value <= 100.0:
            last = value
    return last


def _device_log_names(device: str) -> List[str]:
    names = []
    for raw in (device, os.path.realpath(device), os.path.basename(device)):
        if raw and raw not in names:
            names.append(raw)
    return names


def _line_mentions_device(line: str, device: str) -> bool:
    for name in _device_log_names(device):
        if not name:
            continue
        if re.search(r"(?:^|[^\w/])" + re.escape(name) + r"(?:[^\w]|$)", line):
            return True
    return False


def target_skipped_busy(log_text: str, device: str) -> bool:
    """True if nwipe logged that *this* target is in use and was not wiped."""
    return _target_has_record(log_text, device, NWIPE_BUSY_TARGET_RE)


def _engine_log_body(line: str) -> str:
    return NWIPE_LOG_PREFIX_RE.sub("", line, count=1)


def _target_has_record(log_text: str, device: str, pattern: re.Pattern[str]) -> bool:
    target = os.path.realpath(device)
    for line in (log_text or "").split("\n"):
        match = pattern.match(_engine_log_body(line))
        if match is not None and any(
            part is not None and os.path.realpath(part) == target
            for part in match.groups()
        ):
            return True
    return False


def _nwipe_aborted(log_text: str) -> bool:
    return any(
        NWIPE_ABORT_LINE_RE.match(_engine_log_body(line))
        for line in (log_text or "").split("\n")
    )


def nwipe_accepts_sigusr1(log_text: str) -> bool:
    """True once the log shows nwipe 0.42 has installed its SIGUSR1 handler."""
    text = log_text or ""
    # Model and serial fields are supplied by the disk. They may contain a
    # readiness phrase after an embedded newline. Require the full timestamped
    # option/I/O record rather than trusting a model's continuation line.
    return any(
        NWIPE_SIGUSR1_READY_RE.match(line.strip(" \t\r"))
        for line in text.split("\n")[:-1]
    )


def _target_open_failed(log_text: str, device: str) -> bool:
    return _target_has_record(log_text, device, NWIPE_OPEN_TARGET_RE)


def _target_geometry_failed(log_text: str, device: str) -> bool:
    return _target_has_record(log_text, device, NWIPE_GEOMETRY_TARGET_RE)


# nwipe 0.42 nwipe_strip_path(): right-align the basename in 8 columns and
# stop at '/'. ``/dev/nvme0n100`` is printed ``vme0n100``, not the full name.
NWIPE_STATUS_DEVICE_WIDTH = 8


def nwipe_status_device_field(device: str) -> str:
    """8-character Drive Status device column for this path."""
    raw = device
    if device.startswith("/"):
        try:
            raw = os.path.realpath(device)
        except OSError:
            raw = device
    chars = [" "] * NWIPE_STATUS_DEVICE_WIDTH
    dest = NWIPE_STATUS_DEVICE_WIDTH - 1
    src = len(raw) - 1
    while dest >= 0 and src >= 0:
        ch = raw[src]
        if ch == "/":
            break
        chars[dest] = ch
        dest -= 1
        src -= 1
    return "".join(chars)


def _status_device_names(device: str) -> List[str]:
    names: List[str] = []
    full = os.path.basename(os.path.realpath(device))
    column = nwipe_status_device_field(device).strip()
    for name in (full, column):
        if name and name not in names:
            names.append(name)
    return names


def _status_column_has_name(line: str, name: str) -> bool:
    return re.match(rf"^\s*!?\s*{re.escape(name)}\s*\|", line) is not None


def _is_error_summary_header(line: str) -> bool:
    return NWIPE_ERROR_SUMMARY_HEADER_RE.fullmatch(
        _engine_log_body(line).strip()
    ) is not None


def _status_failure_has_name(line: str, name: str) -> bool:
    """Match the Drive Status cell, never device-controlled model text."""
    return re.match(
        rf"^\s*!?\s*{re.escape(name)}\s*\|\s*"
        r"(?:-FAILED-|UABORTED|INSANITY)\s*\|",
        line,
    ) is not None


def _line_reports_target_failure(line: str, device: str, *, shared: bool) -> bool:
    body = _engine_log_body(line)
    direct = NWIPE_DIRECT_FAILURE_RE.match(body)
    if direct is not None:
        return os.path.realpath(direct.group(1)) == os.path.realpath(device)
    pipe = NWIPE_PIPE_FAILURE_RE.match(body)
    if pipe is not None:
        return os.path.realpath(pipe.group(1)) == os.path.realpath(device)
    if shared:
        return False
    return any(
        _status_failure_has_name(line, name)
        for name in _status_device_names(device)
    )


def _line_reports_target_verification_mismatch(line: str, device: str) -> bool:
    body = _engine_log_body(line)
    match = NWIPE_VERIFY_MISMATCH_RE.match(body)
    return match is not None and os.path.realpath(match.group(1)) == os.path.realpath(device)


def _target_reported_failure(log_text: str, device: str) -> bool:
    shared = _status_column_is_shared(log_text, device)
    for line in (log_text or "").split("\n"):
        if _line_reports_target_failure(line, device, shared=shared):
            return True
    return False


def _shared_status_reports_failure(log_text: str, device: str) -> bool:
    """A colliding failure cell cannot be cleared by final target progress."""
    if not _status_column_is_shared(log_text, device):
        return False
    column = nwipe_status_device_field(device).strip()
    return any(
        _status_failure_has_name(line, column)
        for line in (log_text or "").split("\n")
    )


def _target_error_summary_conflict(log_text: str, device: str) -> str:
    """Return a non-success reason for a contradictory target error row."""
    names = _status_device_names(device)
    shared = _status_column_is_shared(log_text, device)
    in_table = False
    for line in (log_text or "").split("\n"):
        if _is_error_summary_header(line):
            in_table = True
            continue
        if in_table and line.lstrip().startswith("***"):
            in_table = False
            continue
        if not any(_status_column_has_name(line, n) for n in names):
            continue
        row = NWIPE_ERROR_ROW_RE.match(line)
        if not in_table:
            # The bounded completion tail can start inside Error Summary and
            # lose its header. A target row with nonzero counts still
            # contradicts a later Erased row, but without the header its
            # provenance is uncertain rather than an attributable failure.
            if row is not None and any(int(row.group(i)) > 0 for i in (2, 3, 4)):
                return "indeterminate"
            continue
        if row is None:
            return "indeterminate"
        if any(int(row.group(i)) > 0 for i in (2, 3, 4)):
            return "indeterminate" if shared else "engine_failed"
    return ""


def _target_has_erase_activity(log_text: str, device: str) -> bool:
    """Evidence that contradicts a claim the target was never touched."""
    if any(True for _match, _value in _iter_target_progress(log_text, device)):
        return True
    if _nwipe_aborted(log_text):
        return True
    if _target_error_summary_conflict(log_text, device):
        return True
    if any(
        _line_reports_target_failure(line, device, shared=False)
        or _line_reports_target_verification_mismatch(line, device)
        for line in (log_text or "").split("\n")
    ):
        return True
    names = _status_device_names(device)
    for line in (log_text or "").split("\n"):
        if not any(_status_column_has_name(line, name) for name in names):
            continue
        if NWIPE_POSSIBLE_ERASURE_STATUS_RE.search(line):
            return True
    return False


def _iter_target_progress(log_text: str, device: str):
    """Yield SIGUSR1 progress matches for this device, in log order."""
    for line in (log_text or "").split("\n"):
        match = NWIPE_PROGRESS_RE.match(line)
        if match is None:
            continue
        if os.path.realpath(match.group(1)) != os.path.realpath(device):
            continue
        try:
            value = float(match.group(2))
            round_i, round_n = int(match.group(3)), int(match.group(4))
            pass_i = int(match.group(5)) if match.group(5) is not None else None
            pass_n = int(match.group(6)) if match.group(6) is not None else None
        except (TypeError, ValueError, OverflowError):
            continue
        if not (0.0 <= value <= 100.0 and 1 <= round_i <= round_n):
            continue
        whole, _dot, fraction = match.group(2).partition(".")
        if int(whole) == 100 and fraction.strip("0"):
            # A tiny excess above 100 can float-round back to 100. Exact
            # range validation must precede using that rounded display value.
            continue
        if (pass_i is None) != (pass_n is None):
            continue
        if pass_i is not None and pass_n is not None and not (1 <= pass_i <= pass_n):
            continue
        yield match, value


def _target_last_percent(log_text: str, device: str) -> Optional[float]:
    """Last SIGUSR1 progress percent for this device.

    The Erasure Summary table also prints ``0.00%`` / ``100.00%`` on a
    device line. That is not live progress and must not replace a SIGUSR1
    reading (WORKING would jump to 0% just before Done).
    """
    last = None
    for _match, value in _iter_target_progress(log_text, device):
        last = value
    return last


def _job_percent_from_match(match: re.Match, value: float) -> float:
    """Return nwipe 0.42's already job-wide ``round_percent`` value."""
    return value


def _target_job_percent(log_text: str, device: str) -> Optional[float]:
    last = None
    for match, value in _iter_target_progress(log_text, device):
        last = _job_percent_from_match(match, value)
    return last


def _log_signature(st: os.stat_result) -> tuple[int, int, int, int, int]:
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def _progress_is_final_pass(match: re.Match) -> bool:
    """True if this SIGUSR1 line is the last pass of the last round."""
    round_i, round_n = int(match.group(3)), int(match.group(4))
    if round_i != round_n:
        return False
    pass_i, pass_n = match.group(5), match.group(6)
    if pass_i is None or pass_n is None:
        # A truncated SIGUSR1 line that ends after "round N of N" is not
        # proof of the last pass. nwipe 0.42 logs pass counters; | Erased |
        # remains the independent completion marker.
        return False
    return int(pass_i) == int(pass_n)


def logged_last_pass_total(
    log_text: str, device: str, *, require_verifying: bool = False
) -> Optional[int]:
    """Pass count on the last complete 100% final-pass line.

    Verified methods require a verifying phase; Quick zero requires writing.
    A later line that is not 100% of the final pass clears the value. The
    Erased row does not carry a pass count; callers treat that row separately.
    """
    total: Optional[int] = None
    for match, _value in _iter_target_progress(log_text, device):
        verified_phase = (
            NWIPE_VERIFY_SUFFIX_RE.fullmatch(match.string[match.end() :]) is not None
        )
        writing_phase = (
            NWIPE_WRITE_SUFFIX_RE.fullmatch(match.string[match.end() :]) is not None
        )
        if (
            _progress_is_complete_percent(match)
            and _progress_is_final_pass(match)
            and (verified_phase if require_verifying else writing_phase)
        ):
            total = int(match.group(6))
        else:
            total = None
    return total


def completion_for_method(
    exit_code: Optional[int], log_text: str, device: str, method: Any
) -> tuple[bool, str, str]:
    """Engine completion constrained to the method that was launched.

    ``| Erased |`` has no pass count and stays a completion marker unless
    complete target progress contradicts the launched method. The
    100% fallback is completion only when the logged pass count is the
    method's overwrite count. A one-pass line must not finish Three
    overwrites.
    """
    ok, summary, reason = evaluate_nwipe_outcome(exit_code, log_text, device)
    if not ok:
        return ok, summary, reason
    spec = METHODS.get(method)
    if (
        spec is None
        or (
            not _target_reported_success(log_text, device)
            and logged_last_pass_total(
                log_text, device, require_verifying=spec.verify != "off"
            ) != spec.overwrite_passes
        )
    ):
        return False, "nwipe exited without wiping", "completion_missing"
    for match, _value in _iter_target_progress(log_text, device):
        if _progress_has_method_counters(match) and (
            int(match.group(4)) != spec.rounds
            or int(match.group(6)) != spec.overwrite_passes
        ):
            return False, "nwipe progress contradicted the confirmed method", "indeterminate"
    return ok, summary, reason


def _progress_has_method_counters(match: re.Match) -> bool:
    """Complete known phases constrain initialized round/pass denominators."""
    suffix = match.string[match.end() :]
    return (match.group(6) is not None
            and NWIPE_METHOD_COUNTER_SUFFIX_RE.fullmatch(suffix) is not None)


def _progress_is_complete_percent(match: re.Match) -> bool:
    """Only exact decimal 100 is a terminal marker; float rounding is display-only."""
    return re.fullmatch(r"100(?:\.0+)?", match.group(2)) is not None


def _target_reached_last_pass(log_text: str, device: str) -> bool:
    """True if the last complete SIGUSR1 line finishes the final pass.

    Extra thorough (dodshort) reports 100% at the end of each of 3 passes.
    That is not Finished unless the last logged pass is the last pass.
    """
    last = None
    for match, _value in _iter_target_progress(log_text, device):
        suffix = match.string[match.end() :]
        valid_phase = (
            NWIPE_VERIFY_SUFFIX_RE.fullmatch(suffix) is not None
            or NWIPE_WRITE_SUFFIX_RE.fullmatch(suffix) is not None
        )
        last = _progress_is_complete_percent(match) and _progress_is_final_pass(match) and valid_phase
    return bool(last)


# Paths used by nwipe include names such as dm-0 and md_raid. Truncating the
# match at punctuation can hide another device that shares an eight-character
# Drive Status cell, causing its Erased row to be credited to the target.
_LOG_DEVICE_RE = re.compile(r"/dev/[A-Za-z0-9._+-]+")


def _status_column_is_shared(log_text: str, device: str) -> bool:
    """True when another logged path truncates to this disk's status column.

    nwipe 0.42 keeps eight characters. ``/dev/nvme0n100`` and a different
    name ending in those characters would otherwise share one Erased row.
    """
    column = nwipe_status_device_field(device).strip()
    full = os.path.basename(os.path.realpath(device))
    if not column:
        return False
    for match in _LOG_DEVICE_RE.finditer(log_text or ""):
        other = os.path.basename(os.path.realpath(match.group(0)))
        if other == full:
            continue
        if nwipe_status_device_field(match.group(0)).strip() == column:
            return True
    return False


def _target_reported_success(log_text: str, device: str) -> bool:
    """True only for the Drive Status 'Erased' row.

    nwipe 0.42 SIGUSR1 logs ``/dev/X: Success`` whenever the wipe thread
    pointer is unset and result is 0 — including after nwipe_options_log()
    and before pthread_create. That line is not a completed wipe.
    The status table uses an 8-column basename, so a longer name is truncated.
    A column shared with another path in the same log is not this disk.
    Require the whole table row under nwipe's exact banner: libparted leaves
    internal LF in an ATA model, which nwipe logs without escaping. Such a
    model can forge a bare Erased cell, including inside another status row.
    """
    shared = _status_column_is_shared(log_text, device)
    if shared:
        return False
    rows = [
        re.compile(
            rf"^\s*!?\s*{re.escape(name)}\s*\|\s*Erased\s*\|"
            r"\s*[^|\r\n]+/s\s*\|\s*\d{2,}:\d{2}:\d{2}\s*\|"
        )
        for name in _status_device_names(device)
    ]
    in_status = False
    for line in (log_text or "").split("\n"):
        if line == NWIPE_DRIVE_STATUS_HEADER:
            in_status = True
            continue
        if in_status and line.startswith("***"):
            in_status = False
        if in_status and any(row.match(line) for row in rows):
            return True
    return False


def evaluate_nwipe_outcome(
    exit_code: Optional[int], log_text: str, device: str
) -> tuple[bool, str, str]:
    """Map nwipe's process exit to owner-facing success.

    nwipe 0.42 returns 0 and logs "Nwipe successfully completed" when no wipe
    thread ran (busy skip, open failure, insane geometry) and also after a
    user abort that already logged a percent. SIGUSR1 may log
    ``/dev/X: Success`` before pthread_create. 100% of pass 1 of 3 (dodshort)
    is not Finished. Those must not become Finished.
    """
    if (
        type(exit_code) is not int
        or not isinstance(log_text, str)
        or not isinstance(device, str)
        or not device.startswith("/dev/")
    ):
        return False, "invalid completion metadata", "indeterminate"
    busy = target_skipped_busy(log_text, device)
    open_failed = _target_open_failed(log_text, device)
    geometry_failed = _target_geometry_failed(log_text, device)
    if (busy or open_failed or geometry_failed) and _target_has_erase_activity(
        log_text, device
    ):
        return (
            False,
            "nwipe's erase activity contradicted its skip report",
            "indeterminate",
        )
    if busy:
        return False, "nwipe skipped the disk because it is in use", "occupied"
    if _nwipe_aborted(log_text):
        return False, "nwipe was aborted", "interrupted"
    if open_failed:
        return False, "nwipe could not open the disk", "open_failed"
    if geometry_failed:
        return False, "nwipe could not use the disk", "geometry_unusable"
    if any(
        _line_reports_target_verification_mismatch(line, device)
        for line in (log_text or "").split("\n")
    ):
        return False, "nwipe read-back verification failed", "verification_failed"
    if _target_reported_failure(log_text, device):
        return False, "nwipe reported a failure", "engine_failed"
    if exit_code != 0:
        return False, f"nwipe exited {exit_code}", "process_failed"
    summary_conflict = _target_error_summary_conflict(log_text, device)
    if summary_conflict:
        if summary_conflict == "engine_failed":
            return False, "nwipe reported disk errors", "engine_failed"
        return False, "nwipe completion could not be confirmed", "indeterminate"
    # nwipe 0.42 writes newline-terminated records. A final record cut short
    # by failed or interrupted log I/O can already contain an Erased row or
    # a plausible final 100% sample; neither is complete terminal evidence.
    # Keep an earlier explicit failure reason rather than hiding it here.
    if (
        log_text
        and not log_text.endswith("\n")
        and (
            _target_reported_success(log_text, device)
            or _target_reached_last_pass(log_text, device)
        )
    ):
        return False, "nwipe completion log ended mid-record", "indeterminate"
    if _target_reported_success(log_text, device):
        return True, "finished", "completed"
    if _target_reached_last_pass(log_text, device):
        if _shared_status_reports_failure(log_text, device):
            return False, "nwipe completion could not be confirmed", "indeterminate"
        return True, "finished", "completed"
    return False, "nwipe exited without wiping", "completion_missing"


def evaluate_nwipe_completion(
    exit_code: Optional[int], log_text: str, device: str
) -> tuple[bool, str]:
    ok, detail, _reason = evaluate_nwipe_outcome(exit_code, log_text, device)
    return ok, detail


def _assert_named_wipe_lock(fd: int, lock_path: str) -> None:
    """The coordination name must still refer to our locked inode."""
    try:
        opened = os.fstat(fd)
        named = os.lstat(lock_path)
    except OSError as exc:
        raise SafetyError("Wipe lock changed during acquisition.") from exc
    if (not stat.S_ISREG(named.st_mode)
            or (named.st_dev, named.st_ino) != (opened.st_dev, opened.st_ino)):
        raise SafetyError("Wipe lock changed during acquisition.")


class NwipeRunner:
    """Real subprocess runner. Use DryRunRunner in tests and --demo."""

    def __init__(self, binary: str = NWIPE_PINNED_PATH) -> None:
        self.binary = binary
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()
        self._lock_fd: Optional[int] = None
        self._lock_path = ""
        self._cleanup_failed = False
        self._cancelling: Optional[subprocess.Popen] = None
        self._status_polling: Optional[subprocess.Popen] = None
        self.progress_observation: Optional[Observation] = None
        self._progress_read_seq = 0
        self.finalizing = False
        self.progress: Optional[float] = None
        self.result: Optional[WipeResult] = None
        self._log_tail = ""
        self._last_sigusr1 = 0.0
        self._sigusr1_armed = False
        self._last_logfile = ""
        self._log_fd: Optional[int] = None
        self._active_log_identity: Optional[tuple[str, int, int]] = None
        self._active_request: Optional[WipeRequest] = None
        self._sleep_inhibit = SleepInhibit()
        self._spawned_this_attempt = False
        # A bounded projection of the whole terminal log for outcome and
        # report checks. _log_tail remains the exact suffix used for export.
        self._assessment_log_text: Optional[str] = None
        self._assessment_ready = False
        # Completion reads are bounded. Keep truncation on the reading thread
        # so a concurrent progress read cannot change a completion decision.
        self._log_read_state = threading.local()

    def start_not_spawned(self) -> bool:
        """Confirm a failed launch left no registered process or wipe lock."""
        with self._lock:
            return (
                not self._spawned_this_attempt
                and self._proc is None
                and self._lock_fd is None
                and self._log_fd is None
                and not self._cleanup_failed
            )

    def start(self, request: WipeRequest) -> None:
        # Refuse a duplicate before touching the active run's log.
        with self._lock:
            if self._cleanup_failed:
                raise SafetyError("Runner cleanup could not be confirmed.")
            if (self._proc is not None or self._lock_fd is not None
                    or self._log_fd is not None):
                raise SafetyError("A wipe is already running.")
            # A new launch attempt owns the runner state even if an early
            # preflight check refuses it. A later poll must not return the
            # previous session's terminal verdict as this attempt's result.
            self._progress_read_seq += 1
            self.result = None
            self.progress = None
            self.progress_observation = None
            self.finalizing = False
            self._log_tail = ""
            self._assessment_log_text = None
            self._assessment_ready = False
            self._last_logfile = ""
            self._active_log_identity = None
            self._spawned_this_attempt = False
            self._active_request = None
        resolved = resolve_nwipe_binary(self.binary)
        real_engine = os.path.basename(resolved) == "nwipe"
        if real_engine:
            require_real_live_for_nwipe()
            if pinned_nwipe_already_running(exclude_pid=os.getpid()):
                raise SafetyError("A wipe is already running.")
            _verify_pinned_nwipe(resolved)
            assert_existing_is_block_device(request.device, required=True)
            assert_existing_is_block_device(request.boot_device, required=True)
            assert_size_unchanged(request.device, request.device_size_bytes)
            assert_local_device_transport(request.device)
            now_rdev = block_rdev(request.device)
            if now_rdev is None:
                raise SafetyError("Target is not a block device.")
            if not request.device_rdev or now_rdev != request.device_rdev:
                raise SafetyError("Disk identity changed. Refusing to erase.")
            now_boot_rdev = block_rdev(request.boot_device)
            if not request.boot_rdev or now_boot_rdev != request.boot_rdev:
                raise SafetyError("Boot device identity changed. Refusing to erase.")
        assert_not_boot(request.device, request.boot_device, required=real_engine)
        argv = build_nwipe_argv(request)
        argv[0] = resolved
        assert_log_not_on_target(request.logfile, request.device)
        popen_env = None
        if real_engine:
            env = dict(NWIPE_CLEAN_ENV)
            env["TERM"] = "linux"
            popen_env = env
        with self._lock:
            if self._cleanup_failed:
                raise SafetyError("Runner cleanup could not be confirmed.")
            if (self._proc is not None or self._lock_fd is not None
                    or self._log_fd is not None):
                raise SafetyError("A wipe is already running.")
            self._acquire_wipe_lock(request)
            try:
                # A losing concurrent process must never truncate the active
                # runner's log. Touch the logfile only after flock succeeds.
                self._log_fd = truncate_log_file(
                    request.logfile, request.device, retain_fd=True
                )
                if self._log_fd is None:
                    raise SafetyError("Cannot retain the validated log file.")
                log_stat = os.fstat(self._log_fd)
                self._active_log_identity = (
                    request.logfile, log_stat.st_dev, log_stat.st_ino
                )
                if real_engine:
                    # Recheck both identities while holding the exclusive wipe
                    # lock, immediately before Popen. This narrows the hotplug
                    # window after the owner confirms the displayed disk.
                    assert_existing_is_block_device(request.device, required=True)
                    assert_existing_is_block_device(request.boot_device, required=True)
                    assert_size_unchanged(request.device, request.device_size_bytes)
                    if block_rdev(request.device) != request.device_rdev:
                        raise SafetyError("Disk identity changed. Refusing to erase.")
                    if block_rdev(request.boot_device) != request.boot_rdev:
                        raise SafetyError(
                            "Boot device identity changed. Refusing to erase."
                        )
                    assert_local_device_transport(request.device)
                    assert_not_boot(request.device, request.boot_device, required=True)
                    _recheck_identity_under_lock(request)
            except BaseException:
                self._release_wipe_lock()
                raise
            self.result = None
            self.progress = None
            self.progress_observation = None
            self.finalizing = False
            self._log_tail = ""
            self._assessment_log_text = None
            self._assessment_ready = False
            self._last_sigusr1 = 0.0
            self._sigusr1_armed = False
            self._last_logfile = request.logfile
            if real_engine:
                try:
                    self._sleep_inhibit.start()
                    # An independently launched nwipe can appear while the
                    # final lsblk/identity checks run under our app lock.
                    # Probe again after those checks, as close to exec as
                    # possible. Our flock alone cannot govern other callers.
                    if pinned_nwipe_already_running(exclude_pid=os.getpid()):
                        raise SafetyError("A wipe is already running.")
                except BaseException:
                    # The erase process has not been launched yet, so an
                    # interrupted inhibitor must not strand the wipe lock.
                    self._release_wipe_lock()
                    raise
            popen_kwargs: dict[str, Any] = {
                "stdin": subprocess.DEVNULL,
                "stdout": subprocess.DEVNULL,
                "stderr": subprocess.DEVNULL,
                "shell": False,
                "close_fds": True,
                "cwd": "/",
                "env": popen_env,
                # New session: the wizard ignores SIGINT, but nwipe is in the
                # same TTY group and would abort on Ctrl-C / leftover INTR.
                "start_new_session": True,
            }
            # Python os.open uses O_CLOEXEC. pass_fds keeps the flock in the
            # child so a crashed wizard cannot start a second nwipe.
            try:
                if self._lock_fd is not None:
                    popen_kwargs["pass_fds"] = (self._lock_fd,)
                    # Preparation and rediscovery can take time. Ownership
                    # checked at flock acquisition must still govern the
                    # pathname another interface will use before we exec.
                    _assert_named_wipe_lock(self._lock_fd, self._lock_path)
                current_log = os.lstat(request.logfile)
                if (not stat.S_ISREG(current_log.st_mode)
                        or current_log.st_uid != os.getuid()
                        or self._active_log_identity != (
                            request.logfile, current_log.st_dev, current_log.st_ino
                        )):
                    raise SafetyError("Log file changed before launch.")
            except BaseException:
                self._release_wipe_lock()
                raise
            try:
                self._proc = subprocess.Popen(argv, **popen_kwargs)
                self._active_request = request
                self._spawned_this_attempt = True
            except Exception as exc:
                # CPython can fork successfully and then raise a parent-side
                # OSError while closing or reading its exec-error pipe. That
                # child inherited our flock through pass_fds; unlocking here
                # would let another wipe launch while it may still run.
                # An exec error naming the executable comes from the child's
                # pre-exec report, after CPython reaped it, so it is safe to
                # release and allow a fresh confirmed attempt.
                if isinstance(exc, OSError) and exc.filename == resolved:
                    try:
                        self._sleep_inhibit.stop()
                    finally:
                        self._release_wipe_lock()
                else:
                    _try_log_diag(
                        "nwipe", "spawn_ownership_uncertain", type(exc).__name__
                    )
                raise

    def _update_progress(self, percent: Optional[float]) -> None:
        """Clamp 0-100, monotonic, never show 100 before success."""
        if percent is None:
            return
        try:
            v = float(percent)
        except (TypeError, ValueError, OverflowError):
            return
        # A nonfinite reading cannot be interpreted as a percentage. Python's
        # min/max would otherwise turn NaN or +inf into 100%.
        if not math.isfinite(v):
            _try_log_diag("nwipe", "progress_nonfinite")
            return
        # Clamp finite out-of-range values.
        if not (0.0 <= v <= 100.0):
            # Clamp instead of ignoring, but log anomaly for diagnostics
            _try_log_diag("nwipe", "progress_clamped", f"raw={percent!r}")
            v = max(0.0, min(100.0, v))
        # Monotonic: never go backwards (tail truncation, log rotation)
        if self.progress is not None and v < self.progress:
            # Small backward jitter is expected if log truncated; keep max
            return
        # Never opportunistically jump to 100 while still working; poll()
        # gates 100 to verified success only. Cap working progress at 99.9.
        if v >= 100.0 and self._proc is not None:
            # If nwipe is still running, cap at 99.9 until verification
            v = min(v, 99.9)
        self.progress = v

    def poll(
        self, request: WipeRequest, *, expected_proc: Optional[subprocess.Popen] = None
    ) -> Optional[WipeResult]:
        # Read proc under lock to avoid race with cancel() clearing _proc.
        with self._lock:
            proc = self._proc
            if expected_proc is not None and proc is not expected_proc:
                return self.result
            if proc is not None:
                # The verdict is bound to the disk, method, and log selected
                # at launch. A stale caller must not classify this process
                # using another request's terminal evidence.
                if self._active_request is not None and request != self._active_request:
                    raise SafetyError("Poll request does not match the active erase.")
                if self._status_polling is proc:
                    return None
                self._status_polling = proc
        if proc is None:
            return self.result
        try:
            code = proc.poll()
        except (OSError, AttributeError) as exc:
            _try_log_diag("nwipe", "poll_failed", type(exc).__name__)
            with self._lock:
                if self._proc is not proc:
                    return self.result
            raise ProcessStatusError("Process status could not be confirmed.") from exc
        finally:
            with self._lock:
                if self._status_polling is proc:
                    self._status_polling = None
        self._refresh_progress(request.logfile, request.device, expected_proc=proc)
        if code is None:
            ready_text = ""
            if not getattr(self, "_sigusr1_armed", False):
                ready_text = self._read_log_tail(request.logfile, 65536)
                ready_text = self._complete_log_records(ready_text)
            now = time.monotonic()
            with self._lock:
                if self._proc is not proc:
                    return self.result
                if nwipe_accepts_sigusr1(ready_text):
                    self._sigusr1_armed = True
                if self._sigusr1_armed and now - self._last_sigusr1 >= 2.0:
                    try:
                        proc.send_signal(signal.SIGUSR1)
                        self._last_sigusr1 = now
                    except (ProcessLookupError, OSError, AttributeError) as exc:
                        _try_log_diag("nwipe", "sigusr1_failed", type(exc).__name__)
            return None
        with self._lock:
            if self._proc is not proc:
                return self.result
            self.finalizing = True
        self._log_read_state.truncated = False
        log_text = self._read_log_tail(request.logfile, NWIPE_COMPLETION_LOG_BYTES)
        completion_truncated = self._log_read_state.truncated
        completion_text: Optional[str] = log_text
        if completion_truncated:
            completion_text = self._scan_completion_log(
                request.logfile, request.device, self._log_read_state.identity
            )
        with self._lock:
            if self._proc is not proc:
                return self.result
            self._assessment_log_text = completion_text
            self._assessment_ready = True
            if log_text:
                self._log_tail = log_text
                percent = (
                    _target_job_percent(self._complete_log_records(log_text), request.device)
                    if log_text.endswith("\n") else None
                )
                if percent is not None:
                    self._update_progress(percent)
        if not log_text.strip():
            _try_log_diag("nwipe", "completion_log_empty", f"exit={code}")
        if completion_text is None:
            ok, summary, reason = (
                False, "nwipe completion log was incomplete", "indeterminate"
            )
        else:
            ok, summary, reason = completion_for_method(
                code, completion_text, request.device, request.method
            )
        _try_log_diag("nwipe", reason, f"exit={code}; {summary}")
        if not ok and code == 0 and log_text:
            # Verification ambiguity: nwipe exit 0 without explicit success must
            # not become success via fallback. Log for maintainer triage.
            _try_log_diag(
                "nwipe",
                "verification_ambiguous",
                f"exit={code} summary={summary[:80]}",
            )
        with self._lock:
            if self._proc is not proc:
                # cancel() ran concurrently and already recorded its outcome
                # (or a new run superseded this one). Never overwrite it with
                # a stale completion.
                return self.result
            self._release_wipe_lock()
            self.result = WipeResult(
                ok=ok,
                exit_code=code,
                summary=summary,
                reason=reason,
                logfile=request.logfile,
            )
            # Only show 100 on verified success; keep monotonic cap otherwise.
            if ok:
                self.progress = 100.0
            self._proc = None
            self._active_request = None
            # Cleanup was confirmed before publishing the terminal result.
            return self.result

    def _read_log_tail(self, logfile: str, nbytes: int) -> str:
        self._log_read_state.truncated = False
        self._log_read_state.identity = None
        self._log_read_state.head_fragment = False
        try:
            fd = os.open(logfile, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError as exc:
            # Missing log is expected before nwipe creates it; permission/
            # symlink errors are diagnostic for maintainer (log isolation).
            # ENOENT (2) is normal early - no diagnostic. Other errors get
            # structured logging with actionable code and fallback to stderr.
            if getattr(exc, "errno", None) not in (2,):  # not ENOENT
                _try_log_diag(
                    "nwipe",
                    "log_open_failed",
                    f"{type(exc).__name__} errno={exc.errno}",
                )
            return ""
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid():
                _try_log_diag(
                    "nwipe",
                    "log_not_regular",
                    f"mode={oct(st.st_mode)}",
                )
                return ""
            expected = self._active_log_identity
            if (expected is not None and expected[0] == logfile
                    and (st.st_dev, st.st_ino) != expected[1:]):
                # A stable read of a replacement file is still unrelated to
                # the log created for this process. Do not accept its status,
                # readiness or terminal markers, even when it looks complete.
                self._log_read_state.truncated = True
                _try_log_diag("nwipe", "log_identity_changed")
                return ""
            with os.fdopen(fd, "rb") as fh:
                fd = -1
                fh.seek(0, os.SEEK_END)
                size = fh.tell()
                self._log_read_state.truncated = size > nbytes
                self._log_read_state.identity = _log_signature(os.fstat(fh.fileno()))
                start = max(0, size - nbytes)
                if start:
                    # The returned bytes remain exact for display/export, but
                    # parsers must ignore an initial record cut by this seek.
                    fh.seek(start - 1)
                    self._log_read_state.head_fragment = fh.read(1) != b"\n"
                fh.seek(start)
                # nwipe can append after tell(). Keep this read bounded even
                # when the file grows before or during the read.
                tail = fh.read(nbytes).decode("utf-8", errors="replace")
                if _log_signature(os.fstat(fh.fileno())) != self._log_read_state.identity:
                    self._log_read_state.identity = None
                    self._log_read_state.truncated = True
                return tail
        except OSError as exc:
            _try_log_diag(
                "nwipe", "log_read_failed", f"{type(exc).__name__} errno={exc.errno}"
            )
            return ""
        finally:
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError as exc:
                    _try_log_diag("nwipe", "log_close_failed", type(exc).__name__)

    def _complete_log_records(self, text: str) -> str:
        """Discard a cut first record before interpreting bounded log bytes."""
        if getattr(self._log_read_state, "head_fragment", False):
            return text.partition("\n")[2]
        return text

    def _scan_completion_log(
        self, logfile: str, device: str, expected_identity
    ) -> Optional[str]:
        """Project a complete large log into bounded completion and media evidence.

        The regular tail remains available for display/export. The verdict
        and report checks consider early lines outside that tail.
        Returning None means the entire file could not be validated.
        """
        if expected_identity is None:
            return None
        try:
            fd = os.open(logfile, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError as exc:
            _try_log_diag("nwipe", "completion_scan_open_failed", type(exc).__name__)
            return None
        try:
            with os.fdopen(fd, "rb") as fh:
                fd = -1
                st = os.fstat(fh.fileno())
                if (
                    not stat.S_ISREG(st.st_mode)
                    or st.st_uid != os.getuid()
                    or _log_signature(st) != expected_identity
                ):
                    return None
                names = _status_device_names(device)
                target_real = os.path.realpath(device)
                target_name = os.path.basename(target_real)
                target_column = nwipe_status_device_field(device).strip()
                retained: list[str] = []
                retained_bytes = 0
                last_progress = ""
                last_progress_position = 0
                last_progress_retained = False
                progress_totals: set[tuple[int, int]] = set()
                shared_path = ""
                in_error_summary = False
                remaining = st.st_size
                while remaining:
                    raw = fh.readline(
                        min(NWIPE_COMPLETION_SCAN_LINE_BYTES + 1, remaining)
                    )
                    if not raw:
                        return None
                    remaining -= len(raw)
                    if len(raw) > NWIPE_COMPLETION_SCAN_LINE_BYTES:
                        return None
                    if not raw.endswith(b"\n"):
                        return None
                    line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                    for match in _LOG_DEVICE_RE.finditer(line):
                        other = os.path.basename(os.path.realpath(match.group(0)))
                        if (other != target_name
                                and nwipe_status_device_field(match.group(0)).strip()
                                == target_column):
                            shared_path = match.group(0)
                    progress = next(_iter_target_progress(line, device), None)
                    new_totals = False
                    if progress is not None:
                        last_progress = line
                        last_progress_position = len(retained)
                        match = progress[0]
                        if _progress_has_method_counters(match):
                            totals = (int(match.group(4)), int(match.group(6)))
                            if totals not in progress_totals:
                                progress_totals.add(totals)
                                new_totals = True
                    if _is_error_summary_header(line):
                        in_error_summary = True
                    elif in_error_summary and line.lstrip().startswith("***"):
                        in_error_summary = False
                    relevant = (
                        new_totals
                        or in_error_summary
                        or _is_error_summary_header(line)
                        or "Erasure Summary" in line
                        or "HIDDEN SECTORS" in line
                        or "No hidden sectors on" in line
                        or "hpa_dco" in line
                        or "hdparm" in line
                        or "SG_IO bad/missing sense data" in line
                        or line.lstrip().startswith("***")
                        or "Verification mismatch on" in line
                        or any(regex.search(line) for regex in (
                            NWIPE_BUSY_RE, NWIPE_ABORT_RE, NWIPE_OPEN_FAIL_RE,
                            NWIPE_FAILURE_RE, NWIPE_POSSIBLE_ERASURE_STATUS_RE,
                            NWIPE_GEOMETRY_RE,
                        ))
                        or any(_status_column_has_name(line, name) for name in names)
                    )
                    if relevant:
                        retained_bytes += len(raw)
                        if retained_bytes > NWIPE_COMPLETION_EVIDENCE_BYTES:
                            return None
                        retained.append(line)
                    if progress is not None:
                        last_progress_retained = relevant
                if _log_signature(os.fstat(fh.fileno())) != expected_identity:
                    return None
                if last_progress and not last_progress_retained:
                    # Keep the sample in its original table context. Appending
                    # earlier progress after an incomplete Error Summary turns
                    # an explicit error row into a malformed/unavailable check.
                    retained.insert(last_progress_position, last_progress)
                if shared_path:
                    retained.append(f"observed {shared_path}")
                return "\n".join(retained) + "\n"
        except (OSError, ValueError) as exc:
            _try_log_diag("nwipe", "completion_scan_failed", type(exc).__name__)
            return None
        finally:
            if fd >= 0:
                os.close(fd)

    def _refresh_progress(
        self,
        logfile: str,
        device: str,
        *,
        expected_proc: Optional[subprocess.Popen] = None,
    ) -> None:
        with self._lock:
            read_proc = self._proc
            if expected_proc is not None and read_proc is not expected_proc:
                return
            self._progress_read_seq += 1
            read_seq = self._progress_read_seq
        text = self._read_log_tail(logfile, NWIPE_PROGRESS_LOG_BYTES)
        from beamo_wipe.progress import observe

        observation = observe(self._complete_log_records(text), device)
        # An in-flight append can end after a plausible percentage but before
        # nwipe has finished the record. Use the complete-line observation for
        # both the stage and the number shown to the owner.
        percent = observation.percent if observation is not None else None
        with self._lock:
            if self._proc is not read_proc or read_seq != self._progress_read_seq:
                return
            self.progress_observation = observation
            if text:
                self._log_tail = text
                if percent is not None:
                    self._update_progress(percent)

    def _acquire_wipe_lock(self, request: WipeRequest) -> None:
        from beamo_wipe.safety import default_log_dir

        # Approved logs may be in separate subdirectories. All runners must
        # still contend for one lock, including during the pre-exec window
        # before another pinned process is visible in /proc.
        lock_path = os.path.join(default_log_dir(), "wipe.lock")
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        except OSError as exc:
            raise SafetyError(f"Cannot create wipe lock: {exc}") from exc
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                raise SafetyError("Wipe lock is not a regular file.")
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # flock protects an inode, not its pathname. If the name was
            # replaced during acquisition, another runner could lock the
            # replacement and both would believe they own the wipe slot.
            _assert_named_wipe_lock(fd, lock_path)
        except BlockingIOError:
            os.close(fd)
            raise SafetyError("A wipe is already running.")
        except BaseException:
            os.close(fd)
            raise
        self._lock_fd = fd
        self._lock_path = lock_path

    def _release_wipe_lock(self) -> None:
        self._sleep_inhibit.stop()
        if self._cleanup_failed:
            raise SafetyError("Runner cleanup could not be confirmed.")
        fd = self._lock_fd
        if fd is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            except OSError as exc:
                _try_log_diag("nwipe", "unlock_failed", type(exc).__name__)
                raise SafetyError("Runner cleanup could not be confirmed.") from exc
            self._lock_fd = None
            try:
                os.close(fd)
            except OSError as exc:
                # A failed close has platform-dependent ownership. Never close
                # the number again, or publish a clean terminal state.
                self._cleanup_failed = True
                _try_log_diag("nwipe", "lock_close_failed", type(exc).__name__)
                raise SafetyError("Runner cleanup could not be confirmed.") from exc
        log_fd = self._log_fd
        if log_fd is not None:
            # Keep the original inode allocated until cleanup is confirmed,
            # so unlink/recreate cannot reuse its device/inode identity.
            self._log_fd = None
            try:
                os.close(log_fd)
            except OSError as exc:
                self._cleanup_failed = True
                _try_log_diag("nwipe", "log_close_failed", type(exc).__name__)
                raise SafetyError("Runner cleanup could not be confirmed.") from exc

    def cancel(self) -> None:
        # Snapshot under lock but keep _proc registered until the outcome is
        # decided: a concurrent poll() keeps monitoring, and start() keeps
        # refusing while the engine may still hold the disk.
        with self._lock:
            proc = self._proc
            if proc is None or self.result is not None or self._cancelling is proc:
                return
            self._cancelling = proc
            request = self._active_request
        try:
            if request is not None and type(getattr(proc, "returncode", None)) is int:
                # poll()/wait() has already observed exit. A late Stop must
                # classify its terminal log, not rewrite it as cancellation.
                self.poll(request, expected_proc=proc)
            else:
                self._cancel_process(proc, request)
        finally:
            with self._lock:
                if self._cancelling is proc:
                    self._cancelling = None

    def _cancel_process(
        self, proc: subprocess.Popen, request: Optional[WipeRequest]
    ) -> None:
        # Claim a nonblocking status probe only if another poll() has not
        # already claimed it. An observed pre-signal exit belongs to nwipe's
        # terminal evidence, even when the owner clicked Stop afterward.
        with self._lock:
            status_owned = (
                request is not None
                and self._proc is proc
                and self._status_polling is not proc
            )
            if status_owned:
                self._status_polling = proc
        pre_code = None
        no_signal = False
        try:
            if status_owned:
                try:
                    pre_code = proc.poll()
                except (OSError, AttributeError) as exc:
                    _try_log_diag("nwipe", "cancel_status_failed", type(exc).__name__)
            if pre_code is None:
                try:
                    proc.terminate()
                except ProcessLookupError:
                    no_signal = True
                except (OSError, AttributeError) as exc:
                    _try_log_diag(
                        "nwipe", "cancel_terminate_failed", type(exc).__name__
                    )
        finally:
            if status_owned:
                with self._lock:
                    if self._status_polling is proc:
                        self._status_polling = None
        if pre_code is not None and request is not None:
            self.poll(request, expected_proc=proc)
            return
        still_alive = False
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except (OSError, AttributeError) as exc:
                _try_log_diag("nwipe", "cancel_kill_failed", type(exc).__name__)
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired as exc:
                _try_log_diag("nwipe", "cancel_kill_still_alive", type(exc).__name__)
                still_alive = True
        if still_alive:
            # A clean wait() return means the process exited; only a wait
            # timeout leaves liveness in doubt. Confirm via poll() (tolerating
            # minimal test doubles) and fail closed if it may still run:
            # keep _proc and the wipe lock so a retry can target it, and
            # never report a 'cancelled' outcome for a live engine.
            try:
                exited = proc.poll() is not None
            except (OSError, AttributeError):
                exited = False
            if not exited:
                raise SafetyError(
                    "Could not stop nwipe; the disk may still be erasing."
                )
        if no_signal and request is not None:
            self.poll(request, expected_proc=proc)
            return
        if request is not None:
            # Capture the same bounded whole-log assessment for cancellation.
            # A partial erase can still leave warning evidence that must not
            # disappear merely because the owner stopped the process.
            self._log_read_state.truncated = False
            log_text = self._read_log_tail(request.logfile, NWIPE_COMPLETION_LOG_BYTES)
            completion_text: Optional[str] = log_text
            if self._log_read_state.truncated:
                completion_text = self._scan_completion_log(
                    request.logfile, request.device, self._log_read_state.identity
                )
            with self._lock:
                if self._proc is proc:
                    self._assessment_log_text = completion_text
                    self._assessment_ready = True
                    if log_text:
                        self._log_tail = log_text
            # The process can finish naturally between the Stop snapshot and
            # terminate(). If its exact method has complete terminal proof,
            # retain that result. Aborts and ambiguous tails stay cancelled.
            if (proc.returncode == 0 and completion_text is not None
                    and completion_for_method(0, completion_text, request.device, request.method)[0]):
                self.poll(request, expected_proc=proc)
                return
        with self._lock:
            if self._proc is not proc or self.result is not None:
                # poll() or another cancel completed this run while wait()
                # was pending. A subsequent start may already own the runner.
                return
            self._release_wipe_lock()
            self._proc = None
            self._active_request = None
            self.result = WipeResult(
                ok=False,
                exit_code=proc.returncode if proc.returncode is not None else 143,
                summary="cancelled",
                reason="cancelled",
                logfile=getattr(self, "_last_logfile", "") or "",
            )


def _synthetic_observation(
    method, frac: float, pct: float, duration_s: float
) -> Observation:
    """Pretend engine observation spread evenly across the method plan.

    Preview/demo only: the stage locator sees the same shape as real
    SIGUSR1 telemetry (verify holds the last overwrite counters), and
    the estimator sees a shrinking ETA so preview shows estimate states.
    """
    spec = METHODS[method]
    overwrites = max(1, spec.overwrite_passes)
    total = overwrites + (1 if spec.verification_passes else 0)
    seg = min(int(frac * total), total - 1)
    if seg < overwrites:
        phase = "Writing"
        counters = (1, 1, seg + 1, overwrites)
    else:
        phase = "Verifying"
        counters = (1, 1, overwrites, overwrites)
    return Observation(
        record=f"dry-run:{pct:.1f}",
        percent=pct,
        phase=phase,
        counters=counters,
        engine_eta=max(1, int(duration_s * (1.0 - frac))),
        quantum=0.1,
        engine_time=None,
    )


class DryRunRunner:
    """Pretend wipe. Never opens a real disk. Used by tests and --demo."""

    def __init__(
        self,
        duration_s: float = 2.5,
        fail: bool = False,
        clock=None,
        synthesize_stages: bool = False,
    ) -> None:
        self.duration_s = duration_s
        self.fail = fail
        self._clock = clock or time.monotonic
        self.synthesize_stages = synthesize_stages
        self.progress: Optional[float] = None
        self.progress_observation: Optional[Observation] = None
        self.result: Optional[WipeResult] = None
        self._log_tail = ""
        self._started: Optional[float] = None
        self._request: Optional[WipeRequest] = None
        self.started = False
        self.cancelled = False

    def start(self, request: WipeRequest) -> None:
        validate_argv(build_nwipe_argv(request), request)
        self._request = request
        self._started = self._clock()
        self.started = True
        self.cancelled = False
        self.progress = None
        self.progress_observation = None
        self.result = None
        self._log_tail = ""

    def start_not_spawned(self) -> bool:
        return not self.started and self._started is None

    def poll(self, request: WipeRequest) -> Optional[WipeResult]:
        if self._started is None:
            return self.result
        if self.cancelled:
            self.result = WipeResult(
                ok=False,
                exit_code=143,
                summary="cancelled",
                reason="cancelled",
                logfile=request.logfile,
            )
            # Keep last progress, but never show 100 on cancelled/failed
            if self.progress is not None and self.progress >= 100.0:
                self.progress = 99.9
            self._started = None
            return self.result
        elapsed = self._clock() - self._started
        if not math.isfinite(elapsed) or elapsed < 0:
            elapsed = 0.0
        frac = min(1.0, elapsed / max(0.1, self.duration_s))
        if frac < 1.0:
            # Monotonic, clamped, never 100 while working
            pct = round(frac * 100.0, 1)
            if self.progress is None or pct > self.progress:
                self.progress = min(99.9, pct)
            if self.synthesize_stages:
                self.progress_observation = _synthetic_observation(
                    request.method, frac, pct, self.duration_s
                )
            return None
        if self.fail:
            self.result = WipeResult(
                ok=False,
                exit_code=1,
                summary="nwipe exited 1",
                logfile=request.logfile,
            )
            # Do not show 100 on failure - keep at 99.9 to indicate not finished
            if (
                self.progress is None
                or self.progress >= 100.0
                or self.progress == round(frac * 100.0, 1)
            ):
                self.progress = 99.9
        else:
            self.result = WipeResult(
                ok=True,
                exit_code=0,
                summary="finished",
                logfile=request.logfile,
            )
            self.progress = 100.0
            spec = METHODS[request.method]
            passes = spec.overwrite_passes
            phase = "verifying" if spec.verify != "off" else "writing"
            self._log_tail = (
                f"{request.device}: 100.00%, round 1 of 1, pass {passes} of {passes}, "
                f"eta 00:00:00, [{phase}]\n"
            )
        self._started = None
        return self.result

    def cancel(self) -> None:
        self.cancelled = True
        if self._request is not None:
            self.poll(self._request)

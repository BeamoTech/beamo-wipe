"""Verify final local receipts, exact inputs, new regressions and skip scope."""
import collections,hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'src'))
from beamo_wipe.verification_evidence import parse_junit_xml
from beamo_wipe.build_identity import runtime_source_sha256
out=Path('/tmp/pass10-primary')
reports=[out/'final.xml',out/'final.xml.orca.xml']
summary={'baseline_head':'35107a8d1a701093eac876a58ab4efd50e291673','runtime_source_sha256':runtime_source_sha256(),'reports':{}}
ids=[]
for p in reports:
    parsed=parse_junit_xml(p.read_text());summary['reports'][p.name]=parsed
    assert parsed['failed']==parsed['errors']==0
    ids.extend((c.get('classname'),c.get('name')) for c in ET.parse(p).findall('.//testcase'))
summary['combined_passed']=sum(v['passed'] for v in summary['reports'].values())
summary['combined_skipped']=sum(v['skipped'] for v in summary['reports'].values())
summary['combined_xfailed']=sum(v['xfailed'] for v in summary['reports'].values())
summary['duplicate_ids']=[list(k) for k,v in collections.Counter(ids).items() if v>1]
assert summary['combined_passed']==6301 and summary['combined_skipped']==14 and summary['combined_xfailed']==0 and not summary['duplicate_ids']
new_stems={'test_console_inventory_diagnostic_pass10','test_runner_projection_record_endings_pass10','test_sound_output_selection_pass10'}
main=ET.parse(reports[0]).findall('.//testcase')
new_cases=[c for c in main if (c.get('classname') or '').rsplit('.',1)[-1] in new_stems]
assert len(new_cases)==78 and all(not list(c) for c in new_cases)
summary['new_regression_cases_passed']=len(new_cases)
sound=[c for c in main if c.get('name')=='test_slow_sound_discovery_does_not_block_gtk_or_update_closed_dialog']
assert len(sound)==1 and not list(sound[0]);summary['unchanged_sound_timing_case']='passed'
frozen=json.loads((out/'source-freeze.json').read_text())
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in frozen.items())
summary['frozen_input_files_matched']=len(frozen)
status=json.loads((out/'local-gate-status.json').read_text())
assert len(status)==8 and all(p['exit_code']==0 for p in status)
summary['local_phase_exit_codes']={p['phase']:p['exit_code'] for p in status}
assert 'go1.26.8' in (out/'go-version.txt').read_text()
(out/'final-summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='reports'},indent=2))
